<?php
session_start();
require_once 'captcha.php';

$captcha = new PuzzleCaptcha();

// Подключение к базе данных
$host = '134.90.167.42:10306';
$user = 'Trushin';
$password = 'i_8VF1';
$dbname = 'project_Trushin';

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Генерация капчи
if (!isset($_SESSION['captcha_generated'])) {
    $captcha_images = $captcha->generate();
    $_SESSION['captcha_generated'] = true;
} else {
    $captcha_images = $_SESSION['captcha_shuffled'] ?? $captcha->generate();
}

// Обработка формы регистрации
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone_number = trim($_POST['phone_number']);
    $captcha_order = [
        'top_left' => $_POST['top_left'] ?? '',
        'top_right' => $_POST['top_right'] ?? '',
        'bottom_left' => $_POST['bottom_left'] ?? '',
        'bottom_right' => $_POST['bottom_right'] ?? ''
    ];

    // Валидация
    $errors = [];

    if (empty($username) || empty($email) || empty($password)) {
        $errors[] = "Все поля обязательны для заполнения";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Пароли не совпадают";
    }

    if (strlen($password) < 6) {
        $errors[] = "Пароль должен содержать минимум 6 символов";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Некорректный формат email";
    }

    // Проверка уникальности username и email
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        $errors[] = "Пользователь с таким логином или email уже существует";
    }

    // Валидация капчи
    if (!$captcha->validate($captcha_order)) {
        $errors[] = "Неверно собрана капча! Картинки должны быть расположены в правильном порядке.";
        $captcha_images = $captcha->generate();
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Создание пользователя
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $email, $password_hash, $role]);
            $user_id = $pdo->lastInsertId();

            // Создание профиля в зависимости от роли
            if ($role === 'client') {
                $stmt = $pdo->prepare("INSERT INTO client_profiles (user_id, first_name, last_name, phone_number) VALUES (?, ?, ?, ?)");
                $stmt->execute([$user_id, $first_name, $last_name, $phone_number]);
            } elseif ($role === 'driver') {
                $license_number = $_POST['license_number'] ?? '';
                $car_model = $_POST['car_model'] ?? '';
                $car_color = $_POST['car_color'] ?? '';
                $license_plate = $_POST['license_plate'] ?? '';
                
                $stmt = $pdo->prepare("INSERT INTO driver_profiles (user_id, first_name, last_name, phone_number, license_number, car_model, car_color, license_plate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $first_name, $last_name, $phone_number, $license_number, $car_model, $car_color, $license_plate]);
            }

            $pdo->commit();
            
            // Очищаем капчу после успешной регистрации
            $captcha->cleanup();
            unset($_SESSION['captcha_generated']);
            
            $success = "Регистрация успешна! Теперь вы можете войти в систему.";
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Ошибка при регистрации: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="captcha.css">
    <?php include 'favicon.php'; ?>
    
    <style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .form-container h3 {
            color: #333;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin: 20px 0 15px 0;
        }
        
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        .form-container input:focus,
        .form-container select:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.3);
        }
        
        .form-container button {
            width: 100%;
            padding: 15px;
            background: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
            transition: background 0.3s ease;
        }
        
        .form-container button:hover {
            background: #27ae60;
        }
        
        .error {
            background: #ffeaa7;
            color: #d63031;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            border-left: 4px solid #d63031;
        }
        
        .error p {
            margin: 5px 0;
        }
        
        .success {
            background: #55efc4;
            color: #00b894;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            border-left: 4px solid #00b894;
            text-align: center;
        }
        
        .driver-fields {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 4px solid #3498db;
        }
    </style>
</head>
<body>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <defs>
            <clipPath id="clip0">
                <rect width="40" height="34" x="319" y="394" rx="4"/>
            </clipPath>
        </defs>
        <g class="bulb" onclick="toggleBulb(this)">
            <path class="bulb__chord" stroke="#C4C4C4" stroke-width="3" d="M339 411V11"/>
            <g class="bulb__bulb">
                <path stroke="none" stroke-width="3" d="M339 411V11"/>
                <circle class="bulb__glass" cx="339" cy="453" r="29" stroke="#000" stroke-width="2"/>
                <circle class="bulb__flash" cx="339" cy="453" r="30" fill="none"/>
                <path class="bulb__glare"
                      d="M363.977 456.827C364.667 452.176 364.106 447.425 362.352 443.062C360.599 438.699 357.716 434.881 354 432"
                      stroke="white" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                <path class="bulb__filament" stroke="#000" stroke-width="2" d="M339 437v13.5M343 437v13.5M347 420v24M335 437v13.5M331 420v24"/>
                <g clip-path="url(#clip0)">
                    <rect class="bulb__holder" width="40" height="34" x="319" y="394" fill="#C4C4C4" rx="4"/>
                    <rect class="bulb__holder-shine" width="20" height="34" x="346" y="394" fill="#F7F7F7"/>
                </g>
                <rect class="bulb__holder-outline" width="38" height="32" x="320" y="395" stroke="#000"
                      stroke-width="2" rx="3"/>
            </g>
        </g>
    </svg>

    <div class="container">
        <h1>Регистрация в Такси-Сервисе</h1>
        
        <?php if (isset($success)): ?>
            <div class="success">
                <?= $success ?>
                <p style="margin-top: 15px;">
                    <a href="index.php" style="color: #3498db; text-decoration: none; font-weight: bold;">
                        <i class="fas fa-sign-in-alt"></i> Войти в систему
                    </a>
                </p>
            </div>
        <?php else: ?>
            <div class="form-container">
                <form method="POST" id="registerForm">
                    <h3>Основная информация</h3>
                    
                    <input type="text" name="username" placeholder="Логин" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                    <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                    <input type="password" name="password" placeholder="Пароль" required minlength="6">
                    <input type="password" name="confirm_password" placeholder="Подтверждение пароля" required>
                    
                    <select name="role" id="role" required onchange="toggleDriverFields()">
                        <option value="">Выберите роль</option>
                        <option value="client" <?= ($_POST['role'] ?? '') === 'client' ? 'selected' : '' ?>>Клиент</option>
                        <option value="driver" <?= ($_POST['role'] ?? '') === 'driver' ? 'selected' : '' ?>>Водитель</option>
                    </select>

                    <h3>Личная информация</h3>
                    <input type="text" name="first_name" placeholder="Имя" value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
                    <input type="text" name="last_name" placeholder="Фамилия" value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
                    <input type="text" name="phone_number" placeholder="Телефон" value="<?= htmlspecialchars($_POST['phone_number'] ?? '') ?>" required>

                    <!-- Поля для водителя -->
                    <div id="driver_fields" class="driver-fields" style="display: none;">
                        <h3 style="margin-top: 0;">Информация для водителя</h3>
                        <input type="text" name="license_number" placeholder="Номер водительского удостоверения" value="<?= htmlspecialchars($_POST['license_number'] ?? '') ?>">
                        <input type="text" name="car_model" placeholder="Модель автомобиля" value="<?= htmlspecialchars($_POST['car_model'] ?? '') ?>">
                        <input type="text" name="car_color" placeholder="Цвет автомобиля" value="<?= htmlspecialchars($_POST['car_color'] ?? '') ?>">
                        <input type="text" name="license_plate" placeholder="Госномер автомобиля" value="<?= htmlspecialchars($_POST['license_plate'] ?? '') ?>">
                    </div>

                    <!-- Капча с сеткой 2x2 -->
                    <div class="captcha-container">
                        <h3>Соберите картинку в правильном порядке:</h3>
                        <p class="captcha-hint">Перетащите картинки на правильные позиции</p>
                        
                        <div class="captcha-grid">
                            <!-- Верхний ряд -->
                            <div class="grid-row">
                                <div class="grid-cell" data-position="top_left" id="cell_top_left">
                                    <?php if (isset($captcha_images['top_left'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['top_left'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['top_left'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="top_left" value="<?= $captcha_images['top_left'] ?? '' ?>">
                                </div>
                                <div class="grid-cell" data-position="top_right" id="cell_top_right">
                                    <?php if (isset($captcha_images['top_right'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['top_right'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['top_right'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="top_right" value="<?= $captcha_images['top_right'] ?? '' ?>">
                                </div>
                            </div>
                            
                            <!-- Нижний ряд -->
                            <div class="grid-row">
                                <div class="grid-cell" data-position="bottom_left" id="cell_bottom_left">
                                    <?php if (isset($captcha_images['bottom_left'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['bottom_left'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['bottom_left'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="bottom_left" value="<?= $captcha_images['bottom_left'] ?? '' ?>">
                                </div>
                                <div class="grid-cell" data-position="bottom_right" id="cell_bottom_right">
                                    <?php if (isset($captcha_images['bottom_right'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['bottom_right'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['bottom_right'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="bottom_right" value="<?= $captcha_images['bottom_right'] ?? '' ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="captcha-controls">
                            <button type="button" id="resetCaptcha">Новая капча</button>
                        </div>
                    </div>

                    <?php if (!empty($errors)): ?>
                        <div class="error">
                            <?php foreach ($errors as $error): ?>
                                <p><?= $error ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <button type="submit" name="register">
                        <i class="fas fa-user-plus"></i> Зарегистрироваться
                    </button>
                </form>

                <div style="margin-top: 20px; text-align: center;">
                    <p>Уже есть аккаунт? 
                        <a href="index.php" style="color: #3498db; text-decoration: none; font-weight: bold;">
                            <i class="fas fa-sign-in-alt"></i> Войти
                        </a>
                    </p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="captcha.js"></script>
<script>
function toggleDriverFields() {
    const role = document.getElementById('role').value;
    const driverFields = document.getElementById('driver_fields');
    const driverInputs = driverFields.querySelectorAll('input');
    
    if (role === 'driver') {
        driverFields.style.display = 'block';
        // Делаем поля обязательными для водителя
        driverInputs.forEach(input => input.required = true);
    } else {
        driverFields.style.display = 'none';
        // Убираем обязательность полей
        driverInputs.forEach(input => input.required = false);
    }
}

// Валидация формы
document.getElementById('registerForm').addEventListener('submit', function(e) {
    const password = document.querySelector('input[name="password"]');
    const confirmPassword = document.querySelector('input[name="confirm_password"]');
    
    if (password.value !== confirmPassword.value) {
        e.preventDefault();
        alert('Пароли не совпадают!');
        confirmPassword.focus();
        return false;
    }
    
    if (password.value.length < 6) {
        e.preventDefault();
        alert('Пароль должен содержать минимум 6 символов!');
        password.focus();
        return false;
    }
    
    // Проверка капчи (все ли позиции заполнены)
    const captchaInputs = document.querySelectorAll('.captcha-grid input[type="hidden"]');
    let captchaFilled = true;
    
    captchaInputs.forEach(input => {
        if (!input.value) {
            captchaFilled = false;
        }
    });
    
    if (!captchaFilled) {
        e.preventDefault();
        alert('Пожалуйста, соберите капчу полностью!');
        return false;
    }
});

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    toggleDriverFields();
});

// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>