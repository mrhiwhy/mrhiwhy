<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Параметры фильтрации по умолчанию
$date_from = $_GET['date_from'] ?? date('Y-m-01'); // Первый день текущего месяца
$date_to = $_GET['date_to'] ?? date('Y-m-d'); // Сегодня
$report_type = $_GET['report_type'] ?? 'revenue';

// Получение статистики
try {
    // Общая статистика за период
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
            SUM(CASE WHEN status = 'completed' THEN price ELSE 0 END) as total_revenue,
            AVG(CASE WHEN status = 'completed' THEN price ELSE NULL END) as avg_order_price,
            COUNT(DISTINCT client_id) as unique_clients,
            COUNT(DISTINCT driver_id) as active_drivers
        FROM orders 
        WHERE DATE(created_at) BETWEEN ? AND ?
    ");
    $stmt->execute([$date_from, $date_to]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Статистика по дням для графика
    $stmt = $pdo->prepare("
        SELECT 
            DATE(created_at) as date,
            COUNT(*) as orders_count,
            SUM(CASE WHEN status = 'completed' THEN price ELSE 0 END) as daily_revenue
        FROM orders 
        WHERE DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY date
    ");
    $stmt->execute([$date_from, $date_to]);
    $daily_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Топ водителей
    $stmt = $pdo->prepare("
        SELECT 
            dp.first_name,
            dp.last_name,
            COUNT(o.id) as completed_orders,
            SUM(o.price) as total_earnings
        FROM orders o
        JOIN driver_profiles dp ON o.driver_id = dp.user_id
        WHERE o.status = 'completed' AND DATE(o.created_at) BETWEEN ? AND ?
        GROUP BY o.driver_id
        ORDER BY total_earnings DESC
        LIMIT 10
    ");
    $stmt->execute([$date_from, $date_to]);
    $top_drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Статистика по статусам заказов
    $stmt = $pdo->prepare("
        SELECT 
            status,
            COUNT(*) as count
        FROM orders 
        WHERE DATE(created_at) BETWEEN ? AND ?
        GROUP BY status
    ");
    $stmt->execute([$date_from, $date_to]);
    $status_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "Ошибка при получении статистики: " . $e->getMessage();
    $stats = [];
    $daily_stats = [];
    $top_drivers = [];
    $status_stats = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отчеты и аналитика - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="admin_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Отчеты и аналитика</h1>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <!-- Фильтры -->
        <div class="filters-section">
            <h3><i class="fas fa-filter"></i> Параметры отчета</h3>
            <form method="GET" class="filters-form">
                <div class="filter-row">
                    <div class="filter-group">
                        <label for="date_from">Дата с:</label>
                        <input type="date" id="date_from" name="date_from" value="<?= $date_from ?>" required>
                    </div>
                    <div class="filter-group">
                        <label for="date_to">Дата по:</label>
                        <input type="date" id="date_to" name="date_to" value="<?= $date_to ?>" required>
                    </div>
                    <div class="filter-group">
                        <label for="report_type">Тип отчета:</label>
                        <select id="report_type" name="report_type">
                            <option value="revenue" <?= $report_type === 'revenue' ? 'selected' : '' ?>>Выручка</option>
                            <option value="orders" <?= $report_type === 'orders' ? 'selected' : '' ?>>Заказы</option>
                            <option value="drivers" <?= $report_type === 'drivers' ? 'selected' : '' ?>>Водители</option>
                        </select>
                    </div>
                </div>
                <div class="filter-actions">
                    <button type="submit" class="filter-button">
                        <i class="fas fa-chart-bar"></i> Сформировать отчет
                    </button>
                    <button type="button" class="export-button" onclick="exportReport()">
                        <i class="fas fa-download"></i> Экспорт в PDF
                    </button>
                </div>
            </form>
        </div>

        <!-- Основная статистика -->
        <?php if ($stats): ?>
        <div class="stats-overview">
            <h3><i class="fas fa-chart-line"></i> Общая статистика за период</h3>
            <div class="stats-grid">
                <div class="stat-card large">
                    <div class="stat-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-info">
                        <h4>Общая выручка</h4>
                        <p class="stat-number"><?= number_format($stats['total_revenue'] ?? 0, 2) ?> ₽</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-list"></i>
                    </div>
                    <div class="stat-info">
                        <h4>Всего заказов</h4>
                        <p class="stat-number"><?= $stats['total_orders'] ?? 0 ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h4>Завершено</h4>
                        <p class="stat-number"><?= $stats['completed_orders'] ?? 0 ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                    <div class="stat-info">
                        <h4>Средний чек</h4>
                        <p class="stat-number"><?= number_format($stats['avg_order_price'] ?? 0, 2) ?> ₽</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <h4>Уникальные клиенты</h4>
                        <p class="stat-number"><?= $stats['unique_clients'] ?? 0 ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-id-card"></i>
                    </div>
                    <div class="stat-info">
                        <h4>Активные водители</h4>
                        <p class="stat-number"><?= $stats['active_drivers'] ?? 0 ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Графики -->
        <div class="charts-section">
            <div class="chart-container">
                <h3><i class="fas fa-chart-bar"></i> Динамика выручки по дням</h3>
                <canvas id="revenueChart" width="400" height="200"></canvas>
            </div>
            
            <div class="chart-container">
                <h3><i class="fas fa-chart-pie"></i> Распределение заказов по статусам</h3>
                <canvas id="statusChart" width="400" height="200"></canvas>
            </div>
        </div>

        <!-- Топ водителей -->
        <div class="top-drivers">
            <h3><i class="fas fa-trophy"></i> Топ водителей по выручке</h3>
            <?php if (!empty($top_drivers)): ?>
                <div class="drivers-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Место</th>
                                <th>Водитель</th>
                                <th>Завершенные заказы</th>
                                <th>Общая выручка</th>
                                <th>Средний чек</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_drivers as $index => $driver): ?>
                                <tr>
                                    <td class="rank">#<?= $index + 1 ?></td>
                                    <td class="driver-name">
                                        <?= htmlspecialchars($driver['first_name'] . ' ' . $driver['last_name']) ?>
                                    </td>
                                    <td><?= $driver['completed_orders'] ?></td>
                                    <td class="revenue"><?= number_format($driver['total_earnings'], 2) ?> ₽</td>
                                    <td><?= number_format($driver['total_earnings'] / $driver['completed_orders'], 2) ?> ₽</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-info-circle"></i>
                    <p>Нет данных о водителях за выбранный период</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Детальная статистика -->
        <div class="detailed-stats">
            <h3><i class="fas fa-table"></i> Детальная статистика по дням</h3>
            <?php if (!empty($daily_stats)): ?>
                <div class="stats-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Дата</th>
                                <th>Количество заказов</th>
                                <th>Выручка</th>
                                <th>Средний чек</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($daily_stats as $day): ?>
                                <tr>
                                    <td><?= date('d.m.Y', strtotime($day['date'])) ?></td>
                                    <td><?= $day['orders_count'] ?></td>
                                    <td class="revenue"><?= number_format($day['daily_revenue'], 2) ?> ₽</td>
                                    <td><?= number_format($day['daily_revenue'] / $day['orders_count'], 2) ?> ₽</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr class="total-row">
                                <td><strong>Итого:</strong></td>
                                <td><strong><?= $stats['total_orders'] ?? 0 ?></strong></td>
                                <td><strong><?= number_format($stats['total_revenue'] ?? 0, 2) ?> ₽</strong></td>
                                <td><strong><?= number_format($stats['avg_order_price'] ?? 0, 2) ?> ₽</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-info-circle"></i>
                    <p>Нет данных за выбранный период</p>
                </div>
            <?php endif; ?>
        </div>
        <?php else: ?>
            <div class="no-data">
                <i class="fas fa-chart-bar"></i>
                <p>Нет данных для отображения</p>
                <small>Выберите другой период или проверьте параметры фильтрации</small>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.filters-section {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    margin-bottom: 30px;
}

.filters-form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.filter-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
}

.filter-group label {
    margin-bottom: 5px;
    font-weight: bold;
    color: var(--text-color);
}

.filter-group input,
.filter-group select {
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
}

.filter-actions {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.filter-button,
.export-button {
    padding: 12px 25px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.filter-button {
    background: var(--color);
    color: white;
}

.filter-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.export-button {
    background: #27ae60;
    color: white;
}

.export-button:hover {
    background: #219a52;
    transform: translateY(-2px);
}

.stats-overview {
    margin: 30px 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.stat-card {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s ease;
}

.stat-card.large {
    grid-column: span 2;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.stat-icon {
    width: 60px;
    height: 60px;
    background: var(--color);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5em;
    color: white;
}

.stat-info h4 {
    margin: 0 0 5px 0;
    color: var(--text-color);
    font-size: 0.9em;
    opacity: 0.8;
}

.stat-number {
    margin: 0;
    font-size: 1.8em;
    font-weight: bold;
    color: var(--text-color);
}

.charts-section {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 30px;
    margin: 40px 0;
}

.chart-container {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
}

.chart-container h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.top-drivers,
.detailed-stats {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    margin: 30px 0;
}

.drivers-table table,
.stats-table table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.drivers-table th,
.drivers-table td,
.stats-table th,
.stats-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.drivers-table th,
.stats-table th {
    background: var(--table-header-bg);
    font-weight: bold;
}

.rank {
    font-weight: bold;
    color: var(--color);
}

.driver-name {
    font-weight: bold;
}

.revenue {
    font-weight: bold;
    color: #27ae60;
}

.total-row {
    background: var(--main-bg-color);
    font-weight: bold;
}

.total-row td {
    border-top: 2px solid var(--color);
}

.no-data {
    text-align: center;
    padding: 40px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-data i {
    font-size: 3em;
    margin-bottom: 15px;
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

@media (max-width: 768px) {
    .charts-section {
        grid-template-columns: 1fr;
    }
    
    .stat-card.large {
        grid-column: span 1;
    }
    
    .filter-row {
        grid-template-columns: 1fr;
    }
    
    .filter-actions {
        flex-direction: column;
    }
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Инициализация графиков
    initializeCharts();
});

function initializeCharts() {
    <?php if (!empty($daily_stats) && !empty($status_stats)): ?>
    
    // График выручки
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: [
                <?php foreach ($daily_stats as $stat): ?>
                    '<?= date('d.m', strtotime($stat['date'])) ?>',
                <?php endforeach; ?>
            ],
            datasets: [{
                label: 'Выручка (₽)',
                data: [
                    <?php foreach ($daily_stats as $stat): ?>
                        <?= $stat['daily_revenue'] ?>,
                    <?php endforeach; ?>
                ],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '<?= $_SESSION['theme'] === 'light' ? '#111' : '#eee' ?>'
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '<?= $_SESSION['theme'] === 'light' ? '#111' : '#eee' ?>'
                    },
                    grid: {
                        color: '<?= $_SESSION['theme'] === 'light' ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)' ?>'
                    }
                },
                x: {
                    ticks: {
                        color: '<?= $_SESSION['theme'] === 'light' ? '#111' : '#eee' ?>'
                    },
                    grid: {
                        color: '<?= $_SESSION['theme'] === 'light' ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.1)' ?>'
                    }
                }
            }
        }
    });

    // Круговая диаграмма статусов
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    const statusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: [
                <?php foreach ($status_stats as $stat): ?>
                    '<?= $stat['status'] ?>',
                <?php endforeach; ?>
            ],
            datasets: [{
                data: [
                    <?php foreach ($status_stats as $stat): ?>
                        <?= $stat['count'] ?>,
                    <?php endforeach; ?>
                ],
                backgroundColor: [
                    '#f39c12', // pending
                    '#3498db', // accepted
                    '#9b59b6', // in_progress
                    '#27ae60', // completed
                    '#e74c3c'  // cancelled
                ],
                borderWidth: 2,
                borderColor: '<?= $_SESSION['theme'] === 'light' ? '#fff' : '#333' ?>'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '<?= $_SESSION['theme'] === 'light' ? '#111' : '#eee' ?>',
                        padding: 20
                    }
                }
            }
        }
    });
    <?php endif; ?>
}

function exportReport() {
    alert('Функция экспорта в PDF будет реализована в следующей версии');
    // В реальном приложении здесь был бы код для генерации PDF
}
</script>

</body>
</html>