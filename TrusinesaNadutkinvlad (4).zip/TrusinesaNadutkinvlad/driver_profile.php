<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли водителя
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'driver') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Получение данных водителя
try {
    $stmt = $pdo->prepare("
        SELECT 
            u.username, u.email, u.created_at,
            dp.*
        FROM users u
        JOIN driver_profiles dp ON u.id = dp.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $driver = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$driver) {
        die("Профиль водителя не найден");
    }
} catch (PDOException $e) {
    die("Ошибка при получении данных: " . $e->getMessage());
}

// Получение статистики водителя
try {
    // Общая статистика
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
            SUM(CASE WHEN status = 'completed' THEN price ELSE 0 END) as total_earnings,
            AVG(CASE WHEN status = 'completed' THEN price ELSE NULL END) as avg_order_price
        FROM orders 
        WHERE driver_id = ?
    ");
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Статистика за текущий месяц
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as monthly_orders,
            SUM(CASE WHEN status = 'completed' THEN price ELSE 0 END) as monthly_earnings
        FROM orders 
        WHERE driver_id = ? AND MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$user_id]);
    $monthly_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Рейтинг (на основе завершенных заказов)
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as driver_rank
        FROM driver_profiles dp2
        WHERE (
            SELECT COUNT(*) 
            FROM orders 
            WHERE driver_id = dp2.user_id AND status = 'completed'
        ) >= (
            SELECT COUNT(*) 
            FROM orders 
            WHERE driver_id = ? AND status = 'completed'
        )
    ");
    $stmt->execute([$user_id]);
    $rank = $stmt->rowCount();

} catch (PDOException $e) {
    $stats = ['total_orders' => 0, 'completed_orders' => 0, 'total_earnings' => 0, 'avg_order_price' => 0];
    $monthly_stats = ['monthly_orders' => 0, 'monthly_earnings' => 0];
    $rank = 0;
}

// Обработка обновления профиля
$error = '';
$success = '';

if (isset($_POST['update_profile'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone_number = trim($_POST['phone_number']);
    $license_number = trim($_POST['license_number']);
    $car_model = trim($_POST['car_model']);
    $car_color = trim($_POST['car_color']);
    $license_plate = trim($_POST['license_plate']);
    $is_available = isset($_POST['is_available']) ? 1 : 0;

    // Валидация
    $errors = [];

    if (empty($first_name) || empty($last_name) || empty($phone_number)) {
        $errors[] = "Все обязательные поля должны быть заполнены";
    }

    if (empty($license_number) || empty($car_model) || empty($car_color) || empty($license_plate)) {
        $errors[] = "Все поля информации об автомобиле обязательны для заполнения";
    }

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE driver_profiles 
                SET first_name = ?, last_name = ?, phone_number = ?, 
                    license_number = ?, car_model = ?, car_color = ?, license_plate = ?, is_available = ?
                WHERE user_id = ?
            ");
            $stmt->execute([
                $first_name, $last_name, $phone_number,
                $license_number, $car_model, $car_color, $license_plate, $is_available,
                $user_id
            ]);

            $success = "Профиль успешно обновлен!";
            
            // Обновляем данные водителя
            $stmt = $pdo->prepare("
                SELECT 
                    u.username, u.email, u.created_at,
                    dp.*
                FROM users u
                JOIN driver_profiles dp ON u.id = dp.user_id
                WHERE u.id = ?
            ");
            $stmt->execute([$user_id]);
            $driver = $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            $errors[] = "Ошибка при обновлении профиля: " . $e->getMessage();
        }
    }

    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    }
}

// Обработка смены пароля
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    $errors = [];

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $errors[] = "Все поля пароля должны быть заполнены";
    }

    if ($new_password !== $confirm_password) {
        $errors[] = "Новый пароль и подтверждение не совпадают";
    }

    if (strlen($new_password) < 6) {
        $errors[] = "Новый пароль должен содержать минимум 6 символов";
    }

    if (empty($errors)) {
        try {
            // Проверяем текущий пароль
            $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($current_password, $user['password_hash'])) {
                // Обновляем пароль
                $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmt->execute([$new_password_hash, $user_id]);

                $success = "Пароль успешно изменен!";
            } else {
                $errors[] = "Текущий пароль неверен";
            }
        } catch (PDOException $e) {
            $errors[] = "Ошибка при смене пароля: " . $e->getMessage();
        }
    }

    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой профиль - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="index.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Мой профиль</h1>

        <?php if ($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <div class="profile-layout">
            <!-- Левая колонка - Статистика -->
            <div class="profile-sidebar">
                <div class="stats-card">
                    <h3><i class="fas fa-chart-line"></i> Моя статистика</h3>
                    <div class="stats-list">
                        <div class="stat-item">
                            <span class="stat-label">Всего заказов:</span>
                            <span class="stat-value"><?= $stats['total_orders'] ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Завершено:</span>
                            <span class="stat-value"><?= $stats['completed_orders'] ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Общая выручка:</span>
                            <span class="stat-value"><?= number_format($stats['total_earnings'], 2) ?> ₽</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Средний чек:</span>
                            <span class="stat-value"><?= number_format($stats['avg_order_price'], 2) ?> ₽</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Заказов за месяц:</span>
                            <span class="stat-value"><?= $monthly_stats['monthly_orders'] ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Выручка за месяц:</span>
                            <span class="stat-value"><?= number_format($monthly_stats['monthly_earnings'], 2) ?> ₽</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Рейтинг среди водителей:</span>
                            <span class="stat-value">#<?= $rank ?></span>
                        </div>
                    </div>
                </div>

                <div class="quick-actions">
                    <h3><i class="fas fa-bolt"></i> Быстрые действия</h3>
                    <div class="action-buttons">
                        <a href="driver_dashboard.php" class="action-btn">
                            <i class="fas fa-tachometer-alt"></i> Панель управления
                        </a>
                        <a href="available_orders.php" class="action-btn">
                            <i class="fas fa-list"></i> Доступные заказы
                        </a>
                        <a href="my_orders.php" class="action-btn">
                            <i class="fas fa-history"></i> История заказов
                        </a>
                    </div>
                </div>
            </div>

            <!-- Правая колонка - Формы -->
            <div class="profile-content">
                <!-- Основная информация -->
                <div class="profile-section">
                    <h2><i class="fas fa-user-edit"></i> Редактирование профиля</h2>
                    <form method="POST" class="profile-form">
                        <div class="form-section">
                            <h3><i class="fas fa-id-card"></i> Личная информация</h3>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first_name">Имя *</label>
                                    <input type="text" id="first_name" name="first_name" 
                                           value="<?= htmlspecialchars($driver['first_name']) ?>" 
                                           required placeholder="Введите имя">
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Фамилия *</label>
                                    <input type="text" id="last_name" name="last_name" 
                                           value="<?= htmlspecialchars($driver['last_name']) ?>" 
                                           required placeholder="Введите фамилию">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="phone_number">Телефон *</label>
                                <input type="text" id="phone_number" name="phone_number" 
                                       value="<?= htmlspecialchars($driver['phone_number']) ?>" 
                                       required placeholder="+7 (XXX) XXX-XX-XX">
                            </div>
                        </div>

                        <div class="form-section">
                            <h3><i class="fas fa-car"></i> Информация об автомобиле</h3>
                            <div class="form-group">
                                <label for="license_number">Номер водительского удостоверения *</label>
                                <input type="text" id="license_number" name="license_number" 
                                       value="<?= htmlspecialchars($driver['license_number']) ?>" 
                                       required placeholder="Серия и номер">
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="car_model">Модель автомобиля *</label>
                                    <input type="text" id="car_model" name="car_model" 
                                           value="<?= htmlspecialchars($driver['car_model']) ?>" 
                                           required placeholder="Например: Toyota Camry">
                                </div>
                                <div class="form-group">
                                    <label for="car_color">Цвет автомобиля *</label>
                                    <input type="text" id="car_color" name="car_color" 
                                           value="<?= htmlspecialchars($driver['car_color']) ?>" 
                                           required placeholder="Например: Белый">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="license_plate">Государственный номер *</label>
                                <input type="text" id="license_plate" name="license_plate" 
                                       value="<?= htmlspecialchars($driver['license_plate']) ?>" 
                                       required placeholder="Например: А123БВ77">
                            </div>
                        </div>

                        <div class="form-section">
                            <h3><i class="fas fa-toggle-on"></i> Настройки доступности</h3>
                            <div class="availability-setting">
                                <label class="checkbox-label large">
                                    <input type="checkbox" name="is_available" value="1" 
                                           <?= $driver['is_available'] ? 'checked' : '' ?>>
                                    <span class="checkmark"></span>
                                    <div class="availability-info">
                                        <strong>Доступен для заказов</strong>
                                        <small>Когда включено, вы будете получать новые заказы</small>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" name="update_profile" class="submit-button">
                                <i class="fas fa-save"></i> Сохранить изменения
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Смена пароля -->
                <div class="profile-section">
                    <h2><i class="fas fa-lock"></i> Смена пароля</h2>
                    <form method="POST" class="password-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="current_password">Текущий пароль *</label>
                                <input type="password" id="current_password" name="current_password" 
                                       required placeholder="Введите текущий пароль">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="new_password">Новый пароль *</label>
                                <input type="password" id="new_password" name="new_password" 
                                       required placeholder="Минимум 6 символов">
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Подтверждение пароля *</label>
                                <input type="password" id="confirm_password" name="confirm_password" 
                                       required placeholder="Повторите новый пароль">
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" name="change_password" class="submit-button secondary">
                                <i class="fas fa-key"></i> Сменить пароль
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Информация об аккаунте -->
                <div class="profile-section">
                    <h2><i class="fas fa-info-circle"></i> Информация об аккаунте</h2>
                    <div class="account-info">
                        <div class="info-row">
                            <span class="info-label">Логин:</span>
                            <span class="info-value"><?= htmlspecialchars($driver['username']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?= htmlspecialchars($driver['email']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Дата регистрации:</span>
                            <span class="info-value"><?= date('d.m.Y H:i', strtotime($driver['created_at'])) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Статус аккаунта:</span>
                            <span class="info-value status-active">Активен</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.profile-layout {
    display: grid;
    grid-template-columns: 300px 1fr;
    gap: 30px;
    margin-top: 30px;
}

.profile-sidebar {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.stats-card {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    border-left: 4px solid var(--color);
}

.stats-card h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.stats-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-color);
}

.stat-item:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.stat-label {
    font-size: 0.9em;
    color: var(--text-color);
    opacity: 0.8;
}

.stat-value {
    font-weight: bold;
    color: var(--text-color);
}

.quick-actions {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
}

.quick-actions h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.action-buttons {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.action-btn {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 3px;
    background: var(--main-bg-color);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s ease;
    font-size: 0.9em;
    
}

.action-btn:hover {
    background: var(--color);
    color: white;
    transform: translateX(5px);
}

.profile-content {
    display: flex;
    flex-direction: column;
    gap: 30px;
}

.profile-section {
    background: var(--input-bg);
    padding: 30px;
    border-radius: 10px;
}

.profile-section h2 {
    margin-bottom: 25px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.profile-form,
.password-form {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.form-section {
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);
}

.form-section:last-of-type {
    border-bottom: none;
    padding-bottom: 0;
}

.form-section h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 1.1em;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: var(--text-color);
}

.form-group input,
.form-group select {
    
    padding: 12px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
    font-size: 14px;
    transition: border-color 0.3s ease;
}

.form-group input:focus {
    outline: none;
    border-color: var(--color);
}

.availability-setting {
    padding: 20px;
    background: var(--main-bg-color);
    border-radius: 8px;
}

.checkbox-label.large {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    cursor: pointer;
    font-weight: normal;
}

.checkbox-label.large input[type="checkbox"] {
    width: auto;
    margin-top: 5px;
}

.availability-info {
    flex: 1;
}

.availability-info strong {
    display: block;
    margin-bottom: 5px;
    color: var(--text-color);
}

.availability-info small {
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.8em;
}

.form-actions {
    text-align: center;
    margin-top: 20px;
}

.submit-button {
    background: var(--color);
    color: white;
    padding: 15px 30px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.submit-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.submit-button.secondary {
    background: #3498db;
}

.submit-button.secondary:hover {
    background: #2980b9;
}

.account-info {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.info-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid var(--border-color);
}

.info-row:last-child {
    border-bottom: none;
}

.info-label {
    font-weight: bold;
    color: var(--text-color);
}

.info-value {
    color: var(--text-color);
}

.status-active {
    color: #27ae60;
    font-weight: bold;
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

@media (max-width: 1024px) {
    .profile-layout {
        grid-template-columns: 1fr;
    }
    
    .profile-sidebar {
        order: 2;
    }
    
    .profile-content {
        order: 1;
    }
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }
    
    .profile-section {
        padding: 20px;
    }
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Маска для телефона
    const phoneInput = document.getElementById('phone_number');
    phoneInput.addEventListener('input', function(e) {
        let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
        e.target.value = '+7' + (x[2] ? ' (' + x[2] : '') + (x[3] ? ') ' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
    });

    // Валидация паролей
    const newPassword = document.getElementById('new_password');
    const confirmPassword = document.getElementById('confirm_password');
    
    function validatePassword() {
        if (newPassword.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity("Пароли не совпадают");
        } else {
            confirmPassword.setCustomValidity('');
        }
    }
    
    newPassword.addEventListener('change', validatePassword);
    confirmPassword.addEventListener('keyup', validatePassword);
});
</script>

</body>
</html>