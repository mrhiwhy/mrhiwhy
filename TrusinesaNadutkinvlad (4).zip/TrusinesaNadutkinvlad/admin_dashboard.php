<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Получение статистики для дашборда
try {
    // Общее количество пользователей
    $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
    $total_users = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'];

    // Количество заказов по статусам
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM orders GROUP BY status");
    $order_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Выручка за сегодня
    $stmt = $pdo->query("SELECT SUM(price) as today_revenue FROM orders WHERE DATE(created_at) = CURDATE() AND status = 'completed'");
    $today_revenue = $stmt->fetch(PDO::FETCH_ASSOC)['today_revenue'] ?? 0;

    // Активные водители
    $stmt = $pdo->query("SELECT COUNT(*) as active_drivers FROM driver_profiles WHERE is_available = 1");
    $active_drivers = $stmt->fetch(PDO::FETCH_ASSOC)['active_drivers'];

} catch (PDOException $e) {
    $error = "Ошибка при получении статистики: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="index.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <defs>
            <clipPath id="clip0">
                <rect width="40" height="34" x="319" y="394" rx="4"/>
            </clipPath>
        </defs>
        <g class="bulb" onclick="toggleBulb(this)">
            <path class="bulb__chord" stroke="#C4C4C4" stroke-width="3" d="M339 411V11"/>
            <g class="bulb__bulb">
                <path stroke="none" stroke-width="3" d="M339 411V11"/>
                <circle class="bulb__glass" cx="339" cy="453" r="29" stroke="#000" stroke-width="2"/>
                <circle class="bulb__flash" cx="339" cy="453" r="30" fill="none"/>
                <path class="bulb__glare"
                      d="M363.977 456.827C364.667 452.176 364.106 447.425 362.352 443.062C360.599 438.699 357.716 434.881 354 432"
                      stroke="white" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                <path class="bulb__filament" stroke="#000" stroke-width="2" d="M339 437v13.5M343 437v13.5M347 420v24M335 437v13.5M331 420v24"/>
                <g clip-path="url(#clip0)">
                    <rect class="bulb__holder" width="40" height="34" x="319" y="394" fill="#C4C4C4" rx="4"/>
                    <rect class="bulb__holder-shine" width="20" height="34" x="346" y="394" fill="#F7F7F7"/>
                </g>
                <rect class="bulb__holder-outline" width="38" height="32" x="320" y="395" stroke="#000"
                      stroke-width="2" rx="3"/>
            </g>
        </g>
    </svg>

    <div class="container">
        <h1>Панель администратора</h1>
        <p>Добро пожаловать, <?= htmlspecialchars($_SESSION['username']) ?>!</p>

        <?php if (isset($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <!-- Статистика -->
        <div class="stats-container">
            <div class="stat-card">
                <h3>Всего пользователей</h3>
                <p class="stat-number"><?= $total_users ?></p>
            </div>
            <div class="stat-card">
                <h3>Активные водители</h3>
                <p class="stat-number"><?= $active_drivers ?></p>
            </div>
            <div class="stat-card">
                <h3>Выручка за сегодня</h3>
                <p class="stat-number"><?= number_format($today_revenue, 2) ?> ₽</p>
            </div>
        </div>

        <!-- Статусы заказов -->
        <div class="order-stats">
            <h3>Статусы заказов</h3>
            <div class="stats-grid">
                <?php foreach ($order_stats as $stat): ?>
                    <div class="status-stat">
                        <span class="status-label"><?= $stat['status'] ?></span>
                        <span class="status-count"><?= $stat['count'] ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Быстрое меню -->
<li><a href="transfer_simulator.php" class="action-button">
    <i class="fas fa-truck-loading"></i>
    Симулятор перевозок
</a></li>

        <div class="quick-actions">
            <h3>Быстрые действия</h3>
            <li><a href="backup.php" class="action-button">
    <i class="fas fa-database"></i>
    Резервное копирование
</a></li>
            <ul>
                <li><a href="user_management.php" class="action-button">
                    <i class="fas fa-users"></i>
                    Управление пользователями
                </a></li>
                <li><a href="orders_management.php" class="action-button">
                    <i class="fas fa-list"></i>
                    Управление заказами
                </a></li>
                <li><a href="reports.php" class="action-button">
                    <i class="fas fa-chart-bar"></i>
                    Отчеты и аналитика
                </a></li>
            </ul>
        </div>

        <!-- Последние заказы -->
        <div class="recent-orders">
            <h3>Последние заказы</h3>
            <?php
            try {
                $stmt = $pdo->query("
                    SELECT o.*, u.username as client_name, d.first_name as driver_name 
                    FROM orders o 
                    LEFT JOIN users u ON o.client_id = u.id 
                    LEFT JOIN driver_profiles d ON o.driver_id = d.user_id 
                    ORDER BY o.created_at DESC 
                    LIMIT 5
                ");
                $recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                $recent_orders = [];
            }
            ?>

            <?php if (!empty($recent_orders)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Клиент</th>
                            <th>Водитель</th>
                            <th>Статус</th>
                            <th>Стоимость</th>
                            <th>Дата</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= htmlspecialchars($order['client_name']) ?></td>
                                <td><?= htmlspecialchars($order['driver_name'] ?? 'Не назначен') ?></td>
                                <td>
                                    <span class="status-badge status-<?= $order['status'] ?>">
                                        <?= $order['status'] ?>
                                    </span>
                                </td>
                                <td><?= number_format($order['price'], 2) ?> ₽</td>
                                <td><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Нет заказов</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.stats-container {
    display: flex;
    gap: 20px;
    margin: 30px 0;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1;
    min-width: 200px;
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.stat-number {
    font-size: 2em;
    font-weight: bold;
    margin: 10px 0;
    color: var(--text-color);
}

.order-stats {
    margin: 30px 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.status-stat {
    background: var(--input-bg);
    padding: 15px;
    border-radius: 8px;
    text-align: center;
}

.status-label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    text-transform: capitalize;
}

.status-count {
    font-size: 1.5em;
    font-weight: bold;
}

.quick-actions {
    margin: 30px 0;
}

.quick-actions ul {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
    list-style: none;
    padding: 0;
}

.action-button {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 15px;
    background: var(--input-bg);
    border-radius: 8px;
    text-decoration: none;
    color: var(--text-color);
    transition: all 0.3s ease;
}

.action-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.recent-orders {
    margin: 30px 0;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
}

.status-pending { background: #f39c12; color: white; }
.status-accepted { background: #3498db; color: white; }
.status-in_progress { background: #9b59b6; color: white; }
.status-completed { background: #27ae60; color: white; }
.status-cancelled { background: #e74c3c; color: white; }
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>