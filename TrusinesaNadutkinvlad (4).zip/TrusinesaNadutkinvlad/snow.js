 // Функция для создания снега
    function createSnow() {
        const snowContainer = document.getElementById('snowContainer');
        const snowflakes = ['❄', '❅', '❆', '•'];
        const numberOfSnowflakes = 50;

        for (let i = 0; i < numberOfSnowflakes; i++) {
            setTimeout(() => {
                const snowflake = document.createElement('div');
                snowflake.className = 'snowflake';
                snowflake.innerHTML = snowflakes[Math.floor(Math.random() * snowflakes.length)];
                
                // Случайная позиция
                const startPosition = Math.random() * 100;
                const animationDuration = 10 + Math.random() * 20; // 10-30 секунд
                const animationDelay = Math.random() * 5;
                const size = 10 + Math.random() * 15; // 10-25px
                const opacity = 0.3 + Math.random() * 0.7; // 0.3-1.0
                
                snowflake.style.left = startPosition + 'vw';
                snowflake.style.fontSize = size + 'px';
                snowflake.style.opacity = opacity;
                snowflake.style.animation = `fall ${animationDuration}s linear ${animationDelay}s infinite`;
                
                snowContainer.appendChild(snowflake);

                // Удаляем снежинку после завершения анимации
                setTimeout(() => {
                    if (snowflake.parentNode === snowContainer) {
                        snowContainer.removeChild(snowflake);
                    }
                }, (animationDuration + animationDelay) * 1000);
            }, i * 300); // Задержка между созданием снежинок
        }
    }

    // Обновляем снег каждые 30 секунд
    function startSnow() {
        createSnow();
        setInterval(createSnow, 3000);
    }

    // Запускаем снег когда страница загружена
    document.addEventListener('DOMContentLoaded', () => {
        startSnow();
        
        // Восстановление темы
        const savedTheme = localStorage.getItem('theme');
        const bulbElement = document.querySelector('.bulb');
        if (savedTheme === 'light') {
            document.body.classList.add('light-theme');
            if(bulbElement) bulbElement.classList.add('on');
        } else {
            document.body.classList.remove('light-theme');
            if(bulbElement) bulbElement.classList.remove('on');
        }
    });
