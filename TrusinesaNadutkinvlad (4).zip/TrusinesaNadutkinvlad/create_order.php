<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли клиента
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'client') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Обработка создания заказа
if (isset($_POST['create_order'])) {
    $pickup_address = trim($_POST['pickup_address']);
    $destination_address = trim($_POST['destination_address']);
    $notes = trim($_POST['notes'] ?? '');

    // Валидация
    if (empty($pickup_address) || empty($destination_address)) {
        $error = "Пожалуйста, заполните адреса подачи и назначения";
    } else {
        try {
            // Автоматический расчет стоимости (упрощенный)
            $base_price = 100.00; // Базовая стоимость
            $distance_price = rand(50, 500); // Случайная дополнительная стоимость
            $total_price = $base_price + $distance_price;

            // Создание заказа
            $stmt = $pdo->prepare("
                INSERT INTO orders (client_id, pickup_address, destination_address, price, status) 
                VALUES (?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$user_id, $pickup_address, $destination_address, $total_price]);
            
            $success = "Заказ успешно создан! Ожидайте назначения водителя.";
            
            // Очистка формы после успешного создания
            $_POST = array();
            
        } catch (PDOException $e) {
            $error = "Ошибка при создании заказа: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать заказ - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="client_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <defs>
            <clipPath id="clip0">
                <rect width="40" height="34" x="319" y="394" rx="4"/>
            </clipPath>
        </defs>
        <g class="bulb" onclick="toggleBulb(this)">
            <path class="bulb__chord" stroke="#C4C4C4" stroke-width="3" d="M339 411V11"/>
            <g class="bulb__bulb">
                <path stroke="none" stroke-width="3" d="M339 411V11"/>
                <circle class="bulb__glass" cx="339" cy="453" r="29" stroke="#000" stroke-width="2"/>
                <circle class="bulb__flash" cx="339" cy="453" r="30" fill="none"/>
                <path class="bulb__glare"
                      d="M363.977 456.827C364.667 452.176 364.106 447.425 362.352 443.062C360.599 438.699 357.716 434.881 354 432"
                      stroke="white" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                <path class="bulb__filament" stroke="#000" stroke-width="2" d="M339 437v13.5M343 437v13.5M347 420v24M335 437v13.5M331 420v24"/>
                <g clip-path="url(#clip0)">
                    <rect class="bulb__holder" width="40" height="34" x="319" y="394" fill="#C4C4C4" rx="4"/>
                    <rect class="bulb__holder-shine" width="20" height="34" x="346" y="394" fill="#F7F7F7"/>
                </g>
                <rect class="bulb__holder-outline" width="38" height="32" x="320" y="395" stroke="#000"
                      stroke-width="2" rx="3"/>
            </g>
        </g>
    </svg>

    <div class="container">
        <h1>Создать новый заказ такси</h1>

        <?php if ($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
                <div style="margin-top: 15px;">
                    <a href="client_dashboard.php" class="action-button">Вернуться в панель</a>
                    <a href="create_order.php" class="action-button secondary">Создать еще заказ</a>
                </div>
            </div>
        <?php else: ?>
            <div class="order-form-container">
                <form method="POST" class="order-form">
                    <div class="form-section">
                        <h3><i class="fas fa-map-marker-alt"></i> Адреса поездки</h3>
                        
                        <div class="form-group">
                            <label for="pickup_address">Адрес подачи такси *</label>
                            <input type="text" id="pickup_address" name="pickup_address" 
                                   value="<?= htmlspecialchars($_POST['pickup_address'] ?? '') ?>" 
                                   required placeholder="Улица, дом, подъезд">
                            <small>Укажите точный адрес, где вас заберут</small>
                        </div>

                        <div class="form-group">
                            <label for="destination_address">Адрес назначения *</label>
                            <input type="text" id="destination_address" name="destination_address" 
                                   value="<?= htmlspecialchars($_POST['destination_address'] ?? '') ?>" 
                                   required placeholder="Улица, дом">
                            <small>Куда вы хотите поехать</small>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3><i class="fas fa-sticky-note"></i> Дополнительная информация</h3>
                        
                        <div class="form-group">
                            <label for="notes">Примечания для водителя</label>
                            <textarea id="notes" name="notes" rows="3" 
                                      placeholder="Например: нужен детское кресло, большой багаж, etc."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                            <small>Любая дополнительная информация, которая поможет водителю</small>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3><i class="fas fa-receipt"></i> Информация о стоимости</h3>
                        <div class="price-info">
                            <div class="price-item">
                                <span>Базовая стоимость:</span>
                                <span>100.00 ₽</span>
                            </div>
                            <div class="price-item">
                                <span>Дополнительно (расстояние):</span>
                                <span>~ 50-500 ₽</span>
                            </div>
                            <div class="price-total">
                                <span>Итоговая стоимость:</span>
                                <span>~ 150-600 ₽</span>
                            </div>
                            <small>Точная стоимость будет рассчитана после создания заказа</small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="create_order" class="submit-button">
                            <i class="fas fa-taxi"></i> Заказать такси
                        </button>
                        <a href="client_dashboard.php" class="cancel-button">Отмена</a>
                    </div>
                </form>
            </div>

            <!-- Быстрые адреса -->
            <div class="quick-addresses">
                <h3>Быстрые адреса</h3>
                <div class="address-buttons">
                    <button type="button" class="address-btn" data-address="ул. Ленина, 1">
                        <i class="fas fa-building"></i> Центр города
                    </button>
                    <button type="button" class="address-btn" data-address="ул. Гагарина, 25">
                        <i class="fas fa-shopping-cart"></i> Торговый центр
                    </button>
                    <button type="button" class="address-btn" data-address="ул. Железнодорожная, 8">
                        <i class="fas fa-train"></i> Железнодорожный вокзал
                    </button>
                    <button type="button" class="address-btn" data-address="ул. Аэропортская, 15">
                        <i class="fas fa-plane"></i> Аэропорт
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.order-form-container {
    max-width: 600px;
    margin: 0 auto;
}

.form-section {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
}

.form-section h3 {
    margin-bottom: 15px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: var(--text-color);
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
    font-size: 14px;
}

.form-group small {
    display: block;
    margin-top: 5px;
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.8em;
}

.price-info {
    background: var(--main-bg-color);
    padding: 15px;
    border-radius: 5px;
}

.price-item, .price-total {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--border-color);
}

.price-total {
    font-weight: bold;
    font-size: 1.1em;
    border-bottom: none;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 2px solid var(--color);
}

.form-actions {
    text-align: center;
    margin-top: 30px;
}

.submit-button {
    background: var(--color);
    color: white;
    padding: 15px 30px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.submit-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.cancel-button {
    display: inline-block;
    padding: 15px 30px;
    margin-left: 15px;
    background: var(--input-bg);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.cancel-button:hover {
    background: var(--border-color);
    transform: translateY(-2px);
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
}

.quick-addresses {
    margin-top: 30px;
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
}

.address-buttons {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-top: 15px;
}

.address-btn {
    background: var(--main-bg-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9em;
}

.address-btn:hover {
    background: var(--color);
    color: white;
    transform: translateY(-2px);
}

.action-button {
    display: inline-block;
    padding: 10px 20px;
    margin: 0 5px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.action-button.secondary {
    background: var(--input-bg);
    color: var(--text-color);
}

.action-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Быстрые адреса
    document.querySelectorAll('.address-btn').forEach(button => {
        button.addEventListener('click', function() {
            const address = this.getAttribute('data-address');
            document.getElementById('pickup_address').value = address;
        });
    });
});
</script>

</body>
</html>