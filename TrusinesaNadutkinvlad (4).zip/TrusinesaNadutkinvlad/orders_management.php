<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Получение списка заказов с фильтрацией
$where_conditions = [];
$params = [];

// Фильтр по статусу
if (isset($_GET['status']) && $_GET['status'] !== '') {
    $where_conditions[] = "o.status = ?";
    $params[] = $_GET['status'];
}

// Фильтр по дате
if (isset($_GET['date_from']) && $_GET['date_from'] !== '') {
    $where_conditions[] = "DATE(o.created_at) >= ?";
    $params[] = $_GET['date_from'];
}

if (isset($_GET['date_to']) && $_GET['date_to'] !== '') {
    $where_conditions[] = "DATE(o.created_at) <= ?";
    $params[] = $_GET['date_to'];
}

$where_sql = '';
if (!empty($where_conditions)) {
    $where_sql = "WHERE " . implode(" AND ", $where_conditions);
}

try {
    $stmt = $pdo->prepare("
        SELECT o.*, 
               u.username as client_username,
               cp.first_name as client_first_name,
               cp.last_name as client_last_name,
               dp.first_name as driver_first_name,
               dp.last_name as driver_last_name
        FROM orders o
        LEFT JOIN users u ON o.client_id = u.id
        LEFT JOIN client_profiles cp ON o.client_id = cp.user_id
        LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id
        $where_sql
        ORDER BY o.created_at DESC
    ");
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $orders = [];
    $error = "Ошибка при получении заказов: " . $e->getMessage();
}

// Статистика по заказам
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN status = 'completed' THEN price ELSE 0 END) as total_revenue,
            AVG(CASE WHEN status = 'completed' THEN price ELSE NULL END) as avg_order_price
        FROM orders
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $stats = ['total_orders' => 0, 'total_revenue' => 0, 'avg_order_price' => 0];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление заказами - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="admin_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Управление заказами</h1>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <!-- Статистика -->
        <div class="stats-container">
            <div class="stat-card">
                <h3>Всего заказов</h3>
                <p class="stat-number"><?= $stats['total_orders'] ?></p>
            </div>
            <div class="stat-card">
                <h3>Общая выручка</h3>
                <p class="stat-number"><?= number_format($stats['total_revenue'], 2) ?> ₽</p>
            </div>
            <div class="stat-card">
                <h3>Средний чек</h3>
                <p class="stat-number"><?= number_format($stats['avg_order_price'], 2) ?> ₽</p>
            </div>
            <div class="stat-card">
                <h3>Активные заказы</h3>
                <p class="stat-number">
                    <?= count(array_filter($orders, function($order) { 
                        return in_array($order['status'], ['pending', 'accepted', 'in_progress']); 
                    })) ?>
                </p>
            </div>
        </div>

        <!-- Фильтры -->
        <div class="filters-section">
            <h3>Фильтры заказов</h3>
            <form method="GET" class="filters-form">
                <div class="filter-group">
                    <label>Статус заказа:</label>
                    <select name="status">
                        <option value="">Все статусы</option>
                        <option value="pending" <?= ($_GET['status'] ?? '') == 'pending' ? 'selected' : '' ?>>Ожидание</option>
                        <option value="accepted" <?= ($_GET['status'] ?? '') == 'accepted' ? 'selected' : '' ?>>Принят</option>
                        <option value="in_progress" <?= ($_GET['status'] ?? '') == 'in_progress' ? 'selected' : '' ?>>В процессе</option>
                        <option value="completed" <?= ($_GET['status'] ?? '') == 'completed' ? 'selected' : '' ?>>Завершен</option>
                        <option value="cancelled" <?= ($_GET['status'] ?? '') == 'cancelled' ? 'selected' : '' ?>>Отменен</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Дата с:</label>
                    <input type="date" name="date_from" value="<?= $_GET['date_from'] ?? '' ?>">
                </div>
                <div class="filter-group">
                    <label>Дата по:</label>
                    <input type="date" name="date_to" value="<?= $_GET['date_to'] ?? '' ?>">
                </div>
                <div class="filter-actions">
                    <button type="submit" class="filter-button">
                        <i class="fas fa-filter"></i> Применить фильтры
                    </button>
                    <a href="orders_management.php" class="reset-button">Сбросить</a>
                </div>
            </form>
        </div>

        <!-- Таблица заказов -->
        <div class="orders-table-container">
            <div class="table-header">
                <h3>Список заказов</h3>
                <div class="table-actions">
                    <span class="orders-count">Найдено заказов: <?= count($orders) ?></span>
                </div>
            </div>

            <?php if (!empty($orders)): ?>
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Клиент</th>
                            <th>Водитель</th>
                            <th>Маршрут</th>
                            <th>Статус</th>
                            <th>Стоимость</th>
                            <th>Дата создания</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td>
                                    <div class="user-info">
                                        <strong><?= htmlspecialchars($order['client_username']) ?></strong>
                                        <small><?= htmlspecialchars($order['client_first_name'] . ' ' . $order['client_last_name']) ?></small>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($order['driver_first_name']): ?>
                                        <div class="user-info">
                                            <strong><?= htmlspecialchars($order['driver_first_name'] . ' ' . $order['driver_last_name']) ?></strong>
                                        </div>
                                    <?php else: ?>
                                        <span class="no-driver">Не назначен</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="route-info">
                                        <div class="route-from">
                                            <i class="fas fa-map-marker-alt"></i>
                                            <?= htmlspecialchars($order['pickup_address']) ?>
                                        </div>
                                        <div class="route-to">
                                            <i class="fas fa-flag-checkered"></i>
                                            <?= htmlspecialchars($order['destination_address']) ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge status-<?= $order['status'] ?>">
                                        <?= $order['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($order['price']): ?>
                                        <strong><?= number_format($order['price'], 2) ?> ₽</strong>
                                    <?php else: ?>
                                        <span class="no-price">—</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="order_details.php?id=<?= $order['id'] ?>" class="action-btn view-btn" title="Просмотреть">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="edit_order.php?id=<?= $order['id'] ?>" class="action-btn edit-btn" title="Редактировать">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if ($order['status'] === 'pending'): ?>
                                            <a href="assign_driver.php?order_id=<?= $order['id'] ?>" class="action-btn assign-btn" title="Назначить водителя">
                                                <i class="fas fa-user-plus"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-list"></i>
                    <p>Заказы не найдены</p>
                    <?php if (!empty($where_conditions)): ?>
                        <p>Попробуйте изменить параметры фильтрации</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.stats-container {
    display: flex;
    gap: 20px;
    margin: 30px 0;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1;
    min-width: 150px;
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.stat-number {
    font-size: 2em;
    font-weight: bold;
    margin: 10px 0;
    color: var(--text-color);
}

.filters-section {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin: 30px 0;
}

.filters-form {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    align-items: end;
}

.filter-group {
    display: flex;
    flex-direction: column;
}

.filter-group label {
    margin-bottom: 5px;
    font-weight: bold;
    color: var(--text-color);
}

.filter-group input,
.filter-group select {
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
}

.filter-actions {
    display: flex ;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
    align-content: flex-end;
}

.filter-button {
    background: var(--color);
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.filter-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.reset-button {
    padding: 10px 46px;
    background: var(--input-bg);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.reset-button:hover {
    background: var(--border-color);
}

.orders-table-container {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin: 30px 0;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.orders-count {
    color: var(--text-color);
    font-weight: bold;
}

.orders-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.orders-table th,
.orders-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.orders-table th {
    background: var(--table-header-bg);
    font-weight: bold;
}

.user-info {
    display: flex;
    flex-direction: column;
}

.user-info small {
    font-size: 0.8em;
    opacity: 0.7;
}

.no-driver, .no-price {
    color: var(--text-color);
    opacity: 0.5;
    font-style: italic;
}

.route-info {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.route-from, .route-to {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 0.9em;
}

.route-from i {
    color: #e74c3c;
}

.route-to i {
    color: #27ae60;
}

.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
    display: inline-block;
    text-align: center;
    min-width: 100px;
}

.status-pending { background: #f39c12; color: white; }
.status-accepted { background: #3498db; color: white; }
.status-in_progress { background: #9b59b6; color: white; }
.status-completed { background: #27ae60; color: white; }
.status-cancelled { background: #e74c3c; color: white; }

.action-buttons {
    display: flex;
    gap: 5px;
    justify-content: center;
}

.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    border-radius: 4px;
    text-decoration: none;
    transition: all 0.3s ease;
}

.view-btn {
    background: #3498db;
    color: white;
}

.view-btn:hover {
    background: #2980b9;
    transform: scale(1.1);
}

.edit-btn {
    background: #f39c12;
    color: white;
}

.edit-btn:hover {
    background: #e67e22;
    transform: scale(1.1);
}

.assign-btn {
    background: #27ae60;
    color: white;
}

.assign-btn:hover {
    background: #219a52;
    transform: scale(1.1);
}

.no-data {
    text-align: center;
    padding: 40px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-data i {
    font-size: 3em;
    margin-bottom: 15px;
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Автоматическая установка дат для фильтра
    const urlParams = new URLSearchParams(window.location.search);
    if (!urlParams.has('date_from') && !urlParams.has('date_to')) {
        const today = new Date().toISOString().split('T')[0];
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        const weekAgoStr = weekAgo.toISOString().split('T')[0];
        
        document.querySelector('input[name="date_from"]').value = weekAgoStr;
        document.querySelector('input[name="date_to"]').value = today;
    }
});
</script>

</body>
</html>