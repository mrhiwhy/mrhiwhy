<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Получение списка пользователей
try {
    $stmt = $pdo->query("
        SELECT u.*, 
               COALESCE(cp.first_name, dp.first_name) as first_name,
               COALESCE(cp.last_name, dp.last_name) as last_name,
               COALESCE(cp.phone_number, dp.phone_number) as phone_number
        FROM users u
        LEFT JOIN client_profiles cp ON u.id = cp.user_id
        LEFT JOIN driver_profiles dp ON u.id = dp.user_id
        ORDER BY u.created_at DESC
    ");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $users = [];
    $error = "Ошибка при получении пользователей: " . $e->getMessage();
}

// Блокировка/разблокировка пользователя
if (isset($_GET['toggle_block'])) {
    $user_id = $_GET['toggle_block'];
    try {
        // Здесь должна быть логика блокировки (добавить поле is_blocked в таблицу users)
        $success = "Функция блокировки будет реализована в следующей версии";
    } catch (PDOException $e) {
        $error = "Ошибка при изменении статуса: " . $e->getMessage();
    }
}

// Удаление пользователя
if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];
    try {
        $pdo->beginTransaction();
        
        // Удаление связанных записей
        $stmt = $pdo->prepare("DELETE FROM client_profiles WHERE user_id = ?");
        $stmt->execute([$user_id]);
        
        $stmt = $pdo->prepare("DELETE FROM driver_profiles WHERE user_id = ?");
        $stmt->execute([$user_id]);
        
        // Удаление пользователя
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        
        $pdo->commit();
        $success = "Пользователь успешно удален";
        header('Location: user_management.php');
        exit;
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Ошибка при удалении пользователя: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление пользователями - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="admin_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Управление пользователями</h1>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <!-- Статистика -->
        <div class="stats-container">
            <?php
            $clients_count = 0;
            $drivers_count = 0;
            $admins_count = 0;
            
            foreach ($users as $user) {
                switch ($user['role']) {
                    case 'client': $clients_count++; break;
                    case 'driver': $drivers_count++; break;
                    case 'admin': $admins_count++; break;
                }
            }
            ?>
            <div class="stat-card">
                <h3>Всего пользователей</h3>
                <p class="stat-number"><?= count($users) ?></p>
            </div>
            <div class="stat-card">
                <h3>Клиенты</h3>
                <p class="stat-number"><?= $clients_count ?></p>
            </div>
            <div class="stat-card">
                <h3>Водители</h3>
                <p class="stat-number"><?= $drivers_count ?></p>
            </div>
            <div class="stat-card">
                <h3>Администраторы</h3>
                <p class="stat-number"><?= $admins_count ?></p>
            </div>
        </div>

        <!-- Таблица пользователей -->
        <div class="users-table-container">
            <div class="table-header">
                <h3>Список пользователей</h3>
                <a href="add_user.php" class="add-button">
                    <i class="fas fa-plus"></i> Добавить пользователя
                </a>
            </div>

            <?php if (!empty($users)): ?>
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Логин</th>
                            <th>Email</th>
                            <th>Имя</th>
                            <th>Фамилия</th>
                            <th>Телефон</th>
                            <th>Роль</th>
                            <th>Дата регистрации</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td><?= htmlspecialchars($user['first_name'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($user['last_name'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($user['phone_number'] ?? '—') ?></td>
                                <td>
                                    <span class="role-badge role-<?= $user['role'] ?>">
                                        <?= $user['role'] ?>
                                    </span>
                                </td>
                                <td><?= date('d.m.Y H:i', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="edit_user.php?id=<?= $user['id'] ?>" class="action-btn edit-btn" title="Редактировать">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <a href="?toggle_block=<?= $user['id'] ?>" class="action-btn block-btn" title="Блокировать" onclick="return confirm('Блокировать пользователя?')">
                                                <i class="fas fa-ban"></i>
                                            </a>
                                            <a href="?delete=<?= $user['id'] ?>" class="action-btn delete-btn" title="Удалить" onclick="return confirm('Вы уверены, что хотите удалить этого пользователя?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        <?php else: ?>
                                            <span class="action-btn disabled-btn" title="Нельзя редактировать себя">
                                                <i class="fas fa-user"></i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-users"></i>
                    <p>Пользователи не найдены</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Поиск и фильтры -->
        <div class="filters-section">
            <h3>Поиск и фильтрация</h3>
            <form method="GET" class="filters-form">
                <div class="filter-group">
                    <input type="text" name="search" placeholder="Поиск по имени, email или телефону" value="<?= $_GET['search'] ?? '' ?>">
                </div>
                <div class="filter-group">
                    <select name="role">
                        <option value="">Все роли</option>
                        <option value="client" <?= ($_GET['role'] ?? '') == 'client' ? 'selected' : '' ?>>Клиент</option>
                        <option value="driver" <?= ($_GET['role'] ?? '') == 'driver' ? 'selected' : '' ?>>Водитель</option>
                        <option value="admin" <?= ($_GET['role'] ?? '') == 'admin' ? 'selected' : '' ?>>Администратор</option>
                    </select>
                </div>
                <button type="submit" class="filter-button">
                    <i class="fas fa-search"></i> Поиск
                </button>
                <a href="user_management.php" class="reset-button">Сбросить</a>
            </form>
        </div>
    </div>
</div>

<style>
.stats-container {
    display: flex;
    gap: 20px;
    margin: 30px 0;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1;
    min-width: 150px;
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.stat-number {
    font-size: 2em;
    font-weight: bold;
    margin: 10px 0;
    color: var(--text-color);
}

.users-table-container {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin: 30px 0;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.add-button {
    background: var(--color);
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.add-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.users-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.users-table th,
.users-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.users-table th {
    background: var(--table-header-bg);
    font-weight: bold;
}

.role-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
}

.role-client { background: #3498db; color: white; }
.role-driver { background: #f39c12; color: white; }
.role-admin { background: #e74c3c; color: white; }

.action-buttons {
    display: flex;
    gap: 5px;
    justify-content: center;
}

.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    border-radius: 4px;
    text-decoration: none;
    transition: all 0.3s ease;
}

.edit-btn {
    background: #3498db;
    color: white;
}

.edit-btn:hover {
    background: #2980b9;
    transform: scale(1.1);
}

.block-btn {
    background: #f39c12;
    color: white;
}

.block-btn:hover {
    background: #e67e22;
    transform: scale(1.1);
}

.delete-btn {
    background: #e74c3c;
    color: white;
}

.delete-btn:hover {
    background: #c0392b;
    transform: scale(1.1);
}

.disabled-btn {
    background: #95a5a6;
    color: white;
    cursor: not-allowed;
}

.no-data {
    text-align: center;
    padding: 40px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-data i {
    font-size: 3em;
    margin-bottom: 15px;
}

.filters-section {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin: 30px 0;
}

.filters-form {
    display: flex;
    gap: 15px;
    align-items: end;
    flex-wrap: wrap;
}

.filter-group {
    flex: 1;
    min-width: 200px;
}

.filter-group input,
.filter-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
}

.filter-button {
    background: var(--color);
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.filter-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.reset-button {
    padding: 10px 20px;
    background: var(--input-bg);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.reset-button:hover {
    background: var(--border-color);
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>