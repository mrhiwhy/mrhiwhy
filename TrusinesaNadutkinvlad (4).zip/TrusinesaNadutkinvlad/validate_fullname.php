<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Доступ запрещен']);
    exit;
}

// Функция для проверки ФИО на спецсимволы
function validateFullName($fullname) {
    // Убираем лишние пробелы
    $fullname = trim($fullname);
    
    // Проверяем на пустоту
    if (empty($fullname)) {
        return [
            'valid' => false,
            'message' => 'ФИО не может быть пустым',
            'type' => 'error'
        ];
    }
    
    // Проверяем длину
    if (strlen($fullname) < 2 || strlen($fullname) > 100) {
        return [
            'valid' => false,
            'message' => 'ФИО должно содержать от 2 до 100 символов',
            'type' => 'error'
        ];
    }
    
    // Разрешенные символы: русские и английские буквы, пробелы, дефисы, апострофы
    $pattern = '/^[a-zA-Zа-яА-ЯёЁ\s\-\.\']+$/u';
    
    if (!preg_match($pattern, $fullname)) {
        return [
            'valid' => false,
            'message' => 'Обнаружены запрещенные символы. Разрешены только буквы, пробелы, дефисы и точки',
            'type' => 'error'
        ];
    }
    
    // Проверяем на наличие цифр
    if (preg_match('/\d/', $fullname)) {
        return [
            'valid' => false,
            'message' => 'Цифры в ФИО не допускаются',
            'type' => 'error'
        ];
    }
    
    // Проверяем на множественные пробелы
    if (preg_match('/\s{2,}/', $fullname)) {
        return [
            'valid' => false,
            'message' => 'Уберите лишние пробелы в ФИО',
            'type' => 'warning'
        ];
    }
    
    // Проверяем формат (должно быть минимум 2 слова)
    $words = array_filter(explode(' ', $fullname));
    if (count($words) < 2) {
        return [
            'valid' => false,
            'message' => 'Введите фамилию и имя (минимум 2 слова)',
            'type' => 'error'
        ];
    }
    
    // Проверяем каждое слово на минимальную длину
    foreach ($words as $word) {
        if (strlen($word) < 2) {
            return [
                'valid' => false,
                'message' => 'Каждое слово в ФИО должно содержать минимум 2 символа',
                'type' => 'error'
            ];
        }
    }
    
    // Если все проверки пройдены
    return [
        'valid' => true,
        'message' => '✅ Данные готовы для внесения в систему',
        'type' => 'success',
        'cleaned_name' => normalizeFullName($fullname)
    ];
}

// Функция для нормализации ФИО
function normalizeFullName($fullname) {
    // Убираем лишние пробелы
    $fullname = preg_replace('/\s+/', ' ', trim($fullname));
    
    // Приводим к правильному регистру (каждое слово с заглавной буквы)
    $fullname = mb_convert_case($fullname, MB_CASE_TITLE, "UTF-8");
    
    return $fullname;
}

// Обработка AJAX запроса
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $fullname = $input['fullname'] ?? '';
    
    $validation_result = validateFullName($fullname);
    
    header('Content-Type: application/json');
    echo json_encode($validation_result);
    exit;
}

// Если запрос не POST, возвращаем ошибку
header('Content-Type: application/json');
echo json_encode([
    'valid' => false,
    'message' => 'Неверный метод запроса',
    'type' => 'error'
]);
?>