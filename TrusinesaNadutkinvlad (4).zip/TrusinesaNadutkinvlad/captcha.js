class CaptchaManager {
    constructor() {
        this.draggedItem = null;
        this.dragSourceCell = null;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.makeDraggable();
    }
    
    setupEventListeners() {
        const resetBtn = document.getElementById('resetCaptcha');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => this.reset());
        }
    }
    
    makeDraggable() {
        // Обработчики для перетаскиваемых элементов
        document.querySelectorAll('.captcha-item').forEach(item => {
            item.addEventListener('dragstart', (e) => this.handleDragStart(e));
            item.addEventListener('dragend', (e) => this.handleDragEnd(e));
        });
        
        // Обработчики для ячеек
        document.querySelectorAll('.grid-cell').forEach(cell => {
            cell.addEventListener('dragover', (e) => this.handleDragOver(e));
            cell.addEventListener('dragenter', (e) => this.handleDragEnter(e));
            cell.addEventListener('dragleave', (e) => this.handleDragLeave(e));
            cell.addEventListener('drop', (e) => this.handleDrop(e));
        });
    }
    
    handleDragStart(e) {
        this.draggedItem = e.target;
        this.dragSourceCell = e.target.parentElement;
        
        e.target.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', e.target.innerHTML);
        
        // Добавляем класс ко всем ячейкам для визуальной обратной связи
        document.querySelectorAll('.grid-cell').forEach(cell => {
            if (!cell.querySelector('.captcha-item')) {
                cell.classList.add('empty');
            }
        });
    }
    
    handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }
    
    handleDragEnter(e) {
        e.preventDefault();
        if (e.target.classList.contains('grid-cell')) {
            e.target.classList.add('drag-over');
        }
    }
    
    handleDragLeave(e) {
        if (e.target.classList.contains('grid-cell')) {
            e.target.classList.remove('drag-over');
        }
    }
    
    handleDrop(e) {
        e.preventDefault();
        
        const targetCell = e.target.classList.contains('grid-cell') 
            ? e.target 
            : e.target.closest('.grid-cell');
            
        if (!targetCell || !this.draggedItem) return;
        
        // Если в целевой ячейке уже есть элемент - меняем их местами
        const existingItem = targetCell.querySelector('.captcha-item');
        
        if (existingItem && existingItem !== this.draggedItem) {
            // Перемещаем существующий элемент в исходную ячейку
            this.dragSourceCell.appendChild(existingItem);
            this.updateHiddenInput(this.dragSourceCell);
        }
        
        // Перемещаем перетаскиваемый элемент в целевую ячейку
        targetCell.appendChild(this.draggedItem);
        this.updateHiddenInput(targetCell);
        
        // Обновляем исходную ячейку
        this.updateHiddenInput(this.dragSourceCell);
        
        this.cleanupDrag();
    }
    
    handleDragEnd(e) {
        this.cleanupDrag();
    }
    
    cleanupDrag() {
        // Убираем все временные стили
        document.querySelectorAll('.grid-cell').forEach(cell => {
            cell.classList.remove('drag-over', 'empty');
        });
        
        if (this.draggedItem) {
            this.draggedItem.classList.remove('dragging');
            this.draggedItem = null;
        }
        
        this.dragSourceCell = null;
    }
    
    updateHiddenInput(cell) {
        const position = cell.getAttribute('data-position');
        const hiddenInput = cell.querySelector('input[type="hidden"]');
        const item = cell.querySelector('.captcha-item');
        
        if (hiddenInput && item) {
            const imageName = item.getAttribute('data-image');
            hiddenInput.value = imageName;
        } else if (hiddenInput) {
            hiddenInput.value = '';
        }
    }
    
    reset() {
        // Перезагрузка страницы для новой капчи
        window.location.reload();
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    new CaptchaManager();
});