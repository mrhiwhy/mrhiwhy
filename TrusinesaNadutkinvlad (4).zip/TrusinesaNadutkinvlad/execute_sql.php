<?php
session_start();

// Проверка авторизации и прав администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'Доступ запрещен']);
    exit;
}

// Подключение к базе данных
$host = '134.90.167.42:10306';
$user = 'Trushin';
$password = 'i_8VF1';
$dbname = 'project_Trushin';

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Ошибка подключения к базе данных: ' . $e->getMessage()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sql_query = $_POST['sql_query'] ?? '';
    
    if (empty($sql_query)) {
        echo json_encode(['error' => 'SQL запрос не может быть пустым']);
        exit;
    }
    
    // Запрещаем опасные операции
    $dangerous_keywords = ['DROP', 'DELETE', 'TRUNCATE', 'ALTER', 'CREATE', 'INSERT', 'UPDATE', 'GRANT', 'REVOKE'];
    $upper_query = strtoupper($sql_query);
    
    foreach ($dangerous_keywords as $keyword) {
        if (strpos($upper_query, $keyword) !== false) {
            echo json_encode(['error' => 'Опасные операции запрещены. Разрешены только SELECT запросы.']);
            exit;
        }
    }
    
    try {
        $stmt = $pdo->prepare($sql_query);
        $stmt->execute();
        
        // Если это SELECT запрос
        if (stripos($sql_query, 'SELECT') === 0) {
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($results);
        } else {
            echo json_encode(['message' => 'Запрос выполнен успешно']);
        }
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка выполнения запроса: ' . $e->getMessage()]);
    }
}
?>