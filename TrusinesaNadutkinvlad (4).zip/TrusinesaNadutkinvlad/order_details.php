<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$order_id = $_GET['id'] ?? null;

if (!$order_id) {
    header('Location: orders_management.php');
    exit;
}

// Получение детальной информации о заказе
try {
    $stmt = $pdo->prepare("
        SELECT o.*, 
               u_c.username as client_username, u_c.email as client_email,
               u_d.username as driver_username, u_d.email as driver_email,
               cp.first_name as client_first_name, cp.last_name as client_last_name, cp.phone_number as client_phone,
               dp.first_name as driver_first_name, dp.last_name as driver_last_name, dp.phone_number as driver_phone,
               dp.license_number, dp.car_model, dp.car_color, dp.license_plate
        FROM orders o
        JOIN users u_c ON o.client_id = u_c.id
        LEFT JOIN users u_d ON o.driver_id = u_d.id
        LEFT JOIN client_profiles cp ON o.client_id = cp.user_id
        LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id
        WHERE o.id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        header('Location: orders_management.php');
        exit;
    }
} catch (PDOException $e) {
    die("Ошибка при получении данных заказа: " . $e->getMessage());
}

// Получение сообщений чата
try {
    $stmt = $pdo->prepare("
        SELECT m.*, u.username, u.role
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.order_id = ?
        ORDER BY m.sent_at ASC
    ");
    $stmt->execute([$order_id]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $messages = [];
}

// Обновление статуса заказа
if (isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$new_status, $order_id]);
        
        // Обновляем данные заказа
        $stmt = $pdo->prepare("
            SELECT o.*, 
                   u_c.username as client_username, u_c.email as client_email,
                   u_d.username as driver_username, u_d.email as driver_email,
                   cp.first_name as client_first_name, cp.last_name as client_last_name, cp.phone_number as client_phone,
                   dp.first_name as driver_first_name, dp.last_name as driver_last_name, dp.phone_number as driver_phone,
                   dp.license_number, dp.car_model, dp.car_color, dp.license_plate
            FROM orders o
            JOIN users u_c ON o.client_id = u_c.id
            LEFT JOIN users u_d ON o.driver_id = u_d.id
            LEFT JOIN client_profiles cp ON o.client_id = cp.user_id
            LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id
            WHERE o.id = ?
        ");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $success = "Статус заказа успешно обновлен";
    } catch (PDOException $e) {
        $error = "Ошибка при обновлении статуса: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Детали заказа #<?= $order_id ?> - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="orders_management.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <div class="order-header">
            <h1>Детали заказа #<?= $order_id ?></h1>
            <div class="order-actions">
                <a href="orders_management.php" class="action-button">
                    <i class="fas fa-list"></i> К списку заказов
                </a>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <div class="order-details-grid">
            <!-- Основная информация -->
            <div class="detail-card">
                <h3><i class="fas fa-info-circle"></i> Основная информация</h3>
                <div class="detail-content">
                    <div class="detail-row">
                        <span class="detail-label">Статус:</span>
                        <span class="status-badge status-<?= $order['status'] ?>">
                            <?= $order['status'] ?>
                        </span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Стоимость:</span>
                        <span class="detail-value"><?= number_format($order['price'], 2) ?> ₽</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Дата создания:</span>
                        <span class="detail-value"><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></span>
                    </div>
                    <?php if ($order['updated_at'] && $order['updated_at'] != $order['created_at']): ?>
                    <div class="detail-row">
                        <span class="detail-label">Дата обновления:</span>
                        <span class="detail-value"><?= date('d.m.Y H:i', strtotime($order['updated_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Форма изменения статуса -->
                <form method="POST" class="status-form">
                    <div class="form-group">
                        <label for="status">Изменить статус:</label>
                        <div class="status-controls">
                            <select id="status" name="status" required>
                                <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Ожидание</option>
                                <option value="accepted" <?= $order['status'] === 'accepted' ? 'selected' : '' ?>>Принят</option>
                                <option value="in_progress" <?= $order['status'] === 'in_progress' ? 'selected' : '' ?>>В процессе</option>
                                <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>Завершен</option>
                                <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Отменен</option>
                            </select>
                            <button type="submit" name="update_status" class="update-button">
                                <i class="fas fa-sync"></i> Обновить
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Информация о маршруте -->
            <div class="detail-card">
                <h3><i class="fas fa-route"></i> Маршрут</h3>
                <div class="detail-content">
                    <div class="route-point">
                        <i class="fas fa-map-marker-alt pickup-icon"></i>
                        <div>
                            <strong>Адрес подачи:</strong>
                            <p><?= htmlspecialchars($order['pickup_address']) ?></p>
                        </div>
                    </div>
                    <div class="route-point">
                        <i class="fas fa-flag-checkered destination-icon"></i>
                        <div>
                            <strong>Адрес назначения:</strong>
                            <p><?= htmlspecialchars($order['destination_address']) ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Информация о клиенте -->
            <div class="detail-card">
                <h3><i class="fas fa-user"></i> Клиент</h3>
                <div class="detail-content">
                    <div class="detail-row">
                        <span class="detail-label">Имя:</span>
                        <span class="detail-value"><?= htmlspecialchars($order['client_first_name'] . ' ' . $order['client_last_name']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Логин:</span>
                        <span class="detail-value"><?= htmlspecialchars($order['client_username']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Email:</span>
                        <span class="detail-value"><?= htmlspecialchars($order['client_email']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Телефон:</span>
                        <span class="detail-value"><?= htmlspecialchars($order['client_phone']) ?></span>
                    </div>
                </div>
            </div>

            <!-- Информация о водителе -->
            <div class="detail-card">
                <h3><i class="fas fa-id-card"></i> Водитель</h3>
                <div class="detail-content">
                    <?php if ($order['driver_first_name']): ?>
                        <div class="detail-row">
                            <span class="detail-label">Имя:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['driver_first_name'] . ' ' . $order['driver_last_name']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Логин:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['driver_username']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Email:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['driver_email']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Телефон:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['driver_phone']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Автомобиль:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['car_model'] . ' (' . $order['car_color'] . ')') ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">Госномер:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['license_plate']) ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="detail-label">В/у:</span>
                            <span class="detail-value"><?= htmlspecialchars($order['license_number']) ?></span>
                        </div>
                    <?php else: ?>
                        <div class="no-driver">
                            <i class="fas fa-user-slash"></i>
                            <p>Водитель не назначен</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- История чата -->
        <div class="chat-history">
            <h3><i class="fas fa-comments"></i> История чата</h3>
            <div class="messages-container">
                <?php if (empty($messages)): ?>
                    <div class="no-messages">
                        <i class="fas fa-comments"></i>
                        <p>Сообщений нет</p>
                        <small>Клиент и водитель еще не общались</small>
                    </div>
                <?php else: ?>
                    <?php foreach ($messages as $message): ?>
                        <div class="message <?= $message['role'] === 'admin' ? 'admin-message' : ($message['role'] === 'driver' ? 'driver-message' : 'client-message') ?>">
                            <div class="message-header">
                                <span class="sender-name">
                                    <?= htmlspecialchars($message['username']) ?> 
                                    <small>(<?= $message['role'] ?>)</small>
                                </span>
                                <span class="message-time">
                                    <?= date('d.m.Y H:i', strtotime($message['sent_at'])) ?>
                                </span>
                            </div>
                            <div class="message-text">
                                <?= nl2br(htmlspecialchars($message['message_text'])) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    flex-wrap: wrap;
    gap: 15px;
}

.order-details-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.detail-card {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    border-left: 4px solid var(--color);
}

.detail-card h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.detail-content {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-color);
}

.detail-row:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.detail-label {
    font-weight: bold;
    color: var(--text-color);
}

.detail-value {
    color: var(--text-color);
    text-align: right;
}

.route-point {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 10px 0;
}

.route-point:first-child {
    border-bottom: 1px solid var(--border-color);
}

.pickup-icon {
    color: #e74c3c;
    margin-top: 2px;
}

.destination-icon {
    color: #27ae60;
    margin-top: 2px;
}

.no-driver {
    text-align: center;
    padding: 20px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-driver i {
    font-size: 2em;
    margin-bottom: 10px;
}

.status-form {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid var(--border-color);
}

.status-controls {
    display: flex;
    gap: 10px;
    align-items: end;
}

.status-controls select {
    flex: 1;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
}

.update-button {
    background: var(--color);
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 5px;
}

.update-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.chat-history {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    margin-bottom: 30px;
}

.chat-history h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.messages-container {
    max-height: 400px;
    overflow-y: auto;
    padding: 15px;
    background: var(--main-bg-color);
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.message {
    padding: 12px 16px;
    border-radius: 10px;
    max-width: 80%;
}

.client-message {
    align-self: flex-start;
    background: #3498db;
    color: white;
    border-bottom-left-radius: 2px;
}

.driver-message {
    align-self: flex-end;
    background: #f39c12;
    color: white;
    border-bottom-right-radius: 2px;
}

.admin-message {
    align-self: center;
    background: #e74c3c;
    color: white;
    border-radius: 15px;
    max-width: 60%;
}

.message-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 5px;
    font-size: 0.8em;
    opacity: 0.9;
}

.sender-name small {
    font-size: 0.7em;
    opacity: 0.8;
}

.message-time {
    font-size: 0.7em;
}

.message-text {
    word-wrap: break-word;
    line-height: 1.4;
}

.no-messages {
    text-align: center;
    padding: 40px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-messages i {
    font-size: 3em;
    margin-bottom: 15px;
}

.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
    display: inline-block;
    text-align: center;
    min-width: 100px;
}

.status-pending { background: #f39c12; color: white; }
.status-accepted { background: #3498db; color: white; }
.status-in_progress { background: #9b59b6; color: white; }
.status-completed { background: #27ae60; color: white; }
.status-cancelled { background: #e74c3c; color: white; }

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.action-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.action-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

/* Стили для скроллбара */
.messages-container::-webkit-scrollbar {
    width: 6px;
}

.messages-container::-webkit-scrollbar-track {
    background: transparent;
}

.messages-container::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
    background: var(--color);
}

@media (max-width: 768px) {
    .order-details-grid {
        grid-template-columns: 1fr;
    }
    
    .order-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .status-controls {
        flex-direction: column;
    }
    
    .message {
        max-width: 90%;
    }
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Автопрокрутка к последнему сообщению в чате
    const messagesContainer = document.querySelector('.messages-container');
    if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
});
</script>

</body>
</html>