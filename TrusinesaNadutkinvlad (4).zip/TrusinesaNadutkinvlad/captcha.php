<?php
session_start();

class PuzzleCaptcha {
    private $images = [];
    
    public function __construct() {
        // Список доступных изображений
        $this->images = [
            'captcha1.jpg',
            'captcha2.jpg', 
            'captcha3.jpg',
            'captcha4.jpg'
        ];
    }
    
    public function generate() {
        // Правильный порядок для сетки 2x2
        $correct_order = [
            'top_left' => $this->images[0],
            'top_right' => $this->images[1],
            'bottom_left' => $this->images[2],
            'bottom_right' => $this->images[3]
        ];
        
        // Перемешиваем позиции
        $positions = array_keys($correct_order);
        shuffle($positions);
        
        $shuffled_order = [];
        foreach ($positions as $index => $position) {
            $shuffled_order[$position] = $this->images[$index];
        }
        
        // Сохраняем правильный порядок в сессии
        $_SESSION['captcha_answer'] = $correct_order;
        $_SESSION['captcha_shuffled'] = $shuffled_order;
        $_SESSION['captcha_time'] = time();
        
        return $shuffled_order;
    }
    
    public function validate($user_order) {
        // Проверяем время (капча действительна 10 минут)
        if (!isset($_SESSION['captcha_time']) || (time() - $_SESSION['captcha_time']) > 600) {
            return false;
        }
        
        // Проверяем правильность порядка
        if (!isset($_SESSION['captcha_answer']) || empty($user_order)) {
            return false;
        }
        
        $correct = $_SESSION['captcha_answer'];
        
        // Сравниваем порядок
        return $user_order == $correct;
    }
    
    public function cleanup() {
        unset($_SESSION['captcha_answer']);
        unset($_SESSION['captcha_shuffled']);
        unset($_SESSION['captcha_time']);
    }
    
    public function getCorrectOrder() {
        return $_SESSION['captcha_answer'] ?? [];
    }
}
?>