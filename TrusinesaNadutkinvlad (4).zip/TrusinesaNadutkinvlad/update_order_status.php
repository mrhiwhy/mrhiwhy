<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли водителя
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'driver') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Проверка, что запрос POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: driver_dashboard.php');
    exit;
}

$order_id = $_POST['order_id'] ?? null;
$new_status = $_POST['status'] ?? null;

if (!$order_id || !$new_status) {
    $_SESSION['error'] = "Неверные параметры запроса";
    header('Location: driver_dashboard.php');
    exit;
}

// Проверяем, принадлежит ли заказ этому водителю
try {
    $stmt = $pdo->prepare("SELECT driver_id FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order || $order['driver_id'] != $user_id) {
        $_SESSION['error'] = "Заказ не найден или не принадлежит вам";
        header('Location: driver_dashboard.php');
        exit;
    }

    // Обновляем статус заказа
    $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);

    // Если заказ завершен, добавляем сообщение в чат
    if ($new_status === 'completed') {
        $completion_message = "Поездка завершена. Спасибо за использование нашего сервиса!";
        $stmt = $pdo->prepare("INSERT INTO messages (order_id, sender_id, message_text) VALUES (?, ?, ?)");
        $stmt->execute([$order_id, $user_id, $completion_message]);
    }

    $_SESSION['success'] = "Статус заказа успешно обновлен";
    
} catch (PDOException $e) {
    $_SESSION['error'] = "Ошибка при обновлении статуса: " . $e->getMessage();
}

header('Location: driver_dashboard.php');
exit;
?>