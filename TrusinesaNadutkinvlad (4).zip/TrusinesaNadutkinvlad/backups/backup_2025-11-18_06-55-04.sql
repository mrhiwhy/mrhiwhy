-- Backup created: 2025-11-18 06:55:04
-- Database: project_Trushin
-- PHP Version: 8.1.32

SET FOREIGN_KEY_CHECKS=0;

--
-- Table structure for table `client_profiles`
--
DROP TABLE IF EXISTS `client_profiles`;
CREATE TABLE `client_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `client_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `client_profiles`
--
INSERT INTO `client_profiles` VALUES 
('3', '6', 'Владислав', 'Надуткин', '12345678910');

--
-- Table structure for table `driver_profiles`
--
DROP TABLE IF EXISTS `driver_profiles`;
CREATE TABLE `driver_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `license_number` varchar(50) NOT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 0,
  `car_model` varchar(50) DEFAULT NULL,
  `car_color` varchar(30) DEFAULT NULL,
  `license_plate` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_availability` (`is_available`),
  CONSTRAINT `driver_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver_profiles`
--
INSERT INTO `driver_profiles` VALUES 
('3', '5', 'Иешуа', 'Трушин', '12345678910', '1', '1', '1', '1', '1');

--
-- Table structure for table `messages`
--
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message_text` text NOT NULL,
  `sent_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_sent_at` (`sent_at`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--
INSERT INTO `messages` VALUES 
('9', '6', '5', 'fbnfb', '2025-10-29 11:40:12'),
('10', '6', '5', 'Поездка завершена. Спасибо за использование нашего сервиса!', '2025-10-29 11:40:18'),
('11', '9', '5', 'Поездка завершена. Спасибо за использование нашего сервиса!', '2025-11-17 14:00:06');

--
-- Table structure for table `orders`
--
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `pickup_address` text NOT NULL,
  `destination_address` text NOT NULL,
  `status` enum('pending','accepted','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
  `price` decimal(10,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_driver_id` (`driver_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--
INSERT INTO `orders` VALUES 
('6', '6', '5', '4, Черёмуховая улица, Инской', 'улица Энгельса, Бабанаково, Белово, Беловский городской округ, Кемеровская область, Сибирский федеральный округ, 652616, Россия', 'completed', '494.00', '2025-10-27 14:01:57', '2025-10-29 11:40:18'),
('7', '6', NULL, '4, Черёмуховая улица, Инской, Беловский городской округ, Кемеровская область, Сибирский федеральный округ, 652644, Россия', 'улица Энгельса, Бабанаково, Белово, Беловский городской округ, Кемеровская область, Сибирский федеральный округ, 652616, Россия', 'pending', '461.00', '2025-11-17 13:02:10', NULL),
('8', '6', NULL, '1', '1', 'pending', '269.00', '2025-11-17 13:09:02', NULL),
('9', '6', '5', '1', '1', 'completed', '201.00', '2025-11-17 13:59:07', '2025-11-17 14:00:06'),
('10', '6', NULL, 'ул. Аэропортская, 15', '1', 'pending', '579.00', '2025-11-18 13:01:14', NULL);

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('client','driver','admin') NOT NULL DEFAULT 'client',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--
INSERT INTO `users` VALUES 
('5', 'esha', 'trysinesa@gmail.com', '$2y$10$d7e/eTZBVEPz1a566EaXDO4IcGl9oww83ZyAN4rA2dFVEIMw0NQQe', 'driver', '2025-10-23 09:49:35'),
('6', 'vlad', 'trysines@gmail.com', '$2y$10$6ud4e2KBp1jS7amRt59/ue0Z3V.NCw7iJejJIdbC8.8oM2ZSHeQ1u', 'client', '2025-10-23 10:06:37'),
('7', 'admin', 'admin@taxi.ru', '$2y$10$ejWKIoeNoG4twASzHORNb.J7TtRrAJqw3b.QXngvKV6gGgn6arX2G', 'admin', '2025-11-18 13:25:16');

SET FOREIGN_KEY_CHECKS=1;
