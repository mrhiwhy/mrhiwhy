<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

// Обработка формы добавления пользователя
if (isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone_number = trim($_POST['phone_number']);

    // Валидация
    $errors = [];

    if (empty($username) || empty($email) || empty($password)) {
        $errors[] = "Все обязательные поля должны быть заполнены";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Пароли не совпадают";
    }

    if (strlen($password) < 6) {
        $errors[] = "Пароль должен содержать минимум 6 символов";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Некорректный формат email";
    }

    // Проверка уникальности username и email
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) {
        $errors[] = "Пользователь с таким логином или email уже существует";
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Создание пользователя
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $email, $password_hash, $role]);
            $user_id = $pdo->lastInsertId();

            // Создание профиля в зависимости от роли
            if ($role === 'client') {
                $stmt = $pdo->prepare("INSERT INTO client_profiles (user_id, first_name, last_name, phone_number) VALUES (?, ?, ?, ?)");
                $stmt->execute([$user_id, $first_name, $last_name, $phone_number]);
            } elseif ($role === 'driver') {
                $license_number = $_POST['license_number'] ?? '';
                $car_model = $_POST['car_model'] ?? '';
                $car_color = $_POST['car_color'] ?? '';
                $license_plate = $_POST['license_plate'] ?? '';
                
                $stmt = $pdo->prepare("INSERT INTO driver_profiles (user_id, first_name, last_name, phone_number, license_number, car_model, car_color, license_plate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $first_name, $last_name, $phone_number, $license_number, $car_model, $car_color, $license_plate]);
            }

            $pdo->commit();
            $success = "Пользователь успешно добавлен!";
            
            // Очистка формы после успешного добавления
            $_POST = array();
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Ошибка при добавлении пользователя: " . $e->getMessage();
        }
    }

    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить пользователя - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>

<!-- Кнопка "Назад" -->
<a href="user_management.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Добавить нового пользователя</h1>

        <?php if ($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
                <div style="margin-top: 15px;">
                    <a href="user_management.php" class="action-button">Вернуться к списку пользователей</a>
                    <a href="add_user.php" class="action-button secondary">Добавить еще пользователя</a>
                </div>
            </div>
        <?php else: ?>
            <div class="form-container">
                <form method="POST" class="user-form">
                    <div class="form-section">
                        <h3><i class="fas fa-user-circle"></i> Основная информация</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="username">Логин *</label>
                                <input type="text" id="username" name="username" 
                                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" 
                                       required placeholder="Введите логин">
                                <small>Уникальный идентификатор пользователя</small>
                            </div>

                            <div class="form-group">
                                <label for="email">Email *</label>
                                <input type="email" id="email" name="email" 
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                                       required placeholder="email@example.com">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="password">Пароль *</label>
                                <input type="password" id="password" name="password" required 
                                       placeholder="Минимум 6 символов">
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Подтверждение пароля *</label>
                                <input type="password" id="confirm_password" name="confirm_password" required 
                                       placeholder="Повторите пароль">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="role">Роль пользователя *</label>
                            <select id="role" name="role" required onchange="toggleDriverFields()">
                                <option value="">Выберите роль</option>
                                <option value="client" <?= ($_POST['role'] ?? '') === 'client' ? 'selected' : '' ?>>Клиент</option>
                                <option value="driver" <?= ($_POST['role'] ?? '') === 'driver' ? 'selected' : '' ?>>Водитель</option>
                                <option value="admin" <?= ($_POST['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Администратор</option>
                            </select>
                            <small>Определяет права доступа пользователя в системе</small>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3><i class="fas fa-id-card"></i> Личная информация</h3>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">Имя *</label>
                                <input type="text" id="first_name" name="first_name" 
                                       value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" 
                                       required placeholder="Введите имя">
                            </div>

                            <div class="form-group">
                                <label for="last_name">Фамилия *</label>
                                <input type="text" id="last_name" name="last_name" 
                                       value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" 
                                       required placeholder="Введите фамилию">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="phone_number">Телефон *</label>
                            <input type="text" id="phone_number" name="phone_number" 
                                   value="<?= htmlspecialchars($_POST['phone_number'] ?? '') ?>" 
                                   required placeholder="+7 (XXX) XXX-XX-XX">
                            <small>Формат: +7 (XXX) XXX-XX-XX</small>
                        </div>
                    </div>

                    <!-- Поля для водителя -->
                    <div id="driver_fields" class="form-section" style="display: none;">
                        <h3><i class="fas fa-car"></i> Информация для водителя</h3>
                        
                        <div class="form-group">
                            <label for="license_number">Номер водительского удостоверения *</label>
                            <input type="text" id="license_number" name="license_number" 
                                   value="<?= htmlspecialchars($_POST['license_number'] ?? '') ?>" 
                                   placeholder="Серия и номер">
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="car_model">Модель автомобиля *</label>
                                <input type="text" id="car_model" name="car_model" 
                                       value="<?= htmlspecialchars($_POST['car_model'] ?? '') ?>" 
                                       placeholder="Например: Toyota Camry">
                            </div>

                            <div class="form-group">
                                <label for="car_color">Цвет автомобиля *</label>
                                <input type="text" id="car_color" name="car_color" 
                                       value="<?= htmlspecialchars($_POST['car_color'] ?? '') ?>" 
                                       placeholder="Например: Белый">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="license_plate">Государственный номер *</label>
                            <input type="text" id="license_plate" name="license_plate" 
                                   value="<?= htmlspecialchars($_POST['license_plate'] ?? '') ?>" 
                                   placeholder="Например: А123БВ77">
                            <small>Формат: буквы и цифры без пробелов</small>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" name="add_user" class="submit-button">
                            <i class="fas fa-user-plus"></i> Добавить пользователя
                        </button>
                        <a href="user_management.php" class="cancel-button">Отмена</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.form-container {
    max-width: 800px;
    margin: 0 auto;
}

.user-form {
    background: var(--input-bg);
    padding: 30px;
    border-radius: 10px;
}

.form-section {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);
}

.form-section:last-of-type {
    border-bottom: none;
}

.form-section h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: var(--text-color);
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
    font-size: 14px;
    transition: border-color 0.3s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--color);
}

.form-group small {
    display: block;
    margin-top: 5px;
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.8em;
}

.form-actions {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid var(--border-color);
}

.submit-button {
    background: var(--color);
    color: white;
    padding: 15px 30px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.submit-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.cancel-button {
    display: inline-block;
    padding: 15px 30px;
    margin-left: 15px;
    background: var(--main-bg-color);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.cancel-button:hover {
    background: var(--border-color);
    transform: translateY(-2px);
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
}

.action-button {
    display: inline-block;
    padding: 10px 20px;
    margin: 0 5px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.action-button.secondary {
    background: var(--input-bg);
    color: var(--text-color);
}

.action-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }
    
    .form-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    
    .cancel-button {
        margin-left: 0;
    }
}
</style>
<script src="snow.js"></script>
<script>
function toggleDriverFields() {
    const role = document.getElementById('role').value;
    const driverFields = document.getElementById('driver_fields');
    const driverInputs = driverFields.querySelectorAll('input');
    
    if (role === 'driver') {
        driverFields.style.display = 'block';
        // Делаем поля обязательными для водителя
        driverInputs.forEach(input => input.required = true);
    } else {
        driverFields.style.display = 'none';
        // Убираем обязательность полей
        driverInputs.forEach(input => input.required = false);
    }
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    toggleDriverFields();
    
    // Маска для телефона
    const phoneInput = document.getElementById('phone_number');
    phoneInput.addEventListener('input', function(e) {
        let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
        e.target.value = '+7' + (x[2] ? ' (' + x[2] : '') + (x[3] ? ') ' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
    });

    // Валидация паролей
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm_password');
    
    function validatePassword() {
        if (password.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity("Пароли не совпадают");
        } else {
            confirmPassword.setCustomValidity('');
        }
    }
    
    password.addEventListener('change', validatePassword);
    confirmPassword.addEventListener('keyup', validatePassword);
});

// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>