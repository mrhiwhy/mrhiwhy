<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Настройки
$backup_dir = 'backups/';
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0755, true);
}

$error = '';
$success = '';

// Создание бэкапа
if (isset($_POST['create_backup'])) {
    try {
        $backup_file = $backup_dir . 'backup_' . date('Y-m-d_H-i-s') . '.sql';
        
        // Получаем все таблицы
        $tables = [];
        $stmt = $pdo->query("SHOW TABLES");
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }
        
        $backup_content = "";
        
        // Добавляем заголовок
        $backup_content .= "-- Backup created: " . date('Y-m-d H:i:s') . "\n";
        $backup_content .= "-- Database: project_Trushin\n";
        $backup_content .= "-- PHP Version: " . PHP_VERSION . "\n\n";
        $backup_content .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
        
        foreach ($tables as $table) {
            // Структура таблицы
            $backup_content .= "--\n-- Table structure for table `$table`\n--\n";
            $backup_content .= "DROP TABLE IF EXISTS `$table`;\n";
            
            $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
            $create_table = $stmt->fetch(PDO::FETCH_NUM);
            $backup_content .= $create_table[1] . ";\n\n";
            
            // Данные таблицы
            $backup_content .= "--\n-- Dumping data for table `$table`\n--\n";
            
            $stmt = $pdo->query("SELECT * FROM `$table`");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($rows) > 0) {
                $backup_content .= "INSERT INTO `$table` VALUES \n";
                $values = [];
                foreach ($rows as $row) {
                    $row_values = [];
                    foreach ($row as $value) {
                        if ($value === null) {
                            $row_values[] = "NULL";
                        } else {
                            $row_values[] = "'" . addslashes($value) . "'";
                        }
                    }
                    $values[] = "(" . implode(", ", $row_values) . ")";
                }
                $backup_content .= implode(",\n", $values) . ";\n\n";
            }
        }
        
        $backup_content .= "SET FOREIGN_KEY_CHECKS=1;\n";
        
        // Сохраняем файл
        if (file_put_contents($backup_file, $backup_content)) {
            $success = "Бэкап успешно создан: " . basename($backup_file);
        } else {
            $error = "Ошибка при сохранении файла бэкапа";
        }
        
    } catch (PDOException $e) {
        $error = "Ошибка при создании бэкапа: " . $e->getMessage();
    }
}

// Восстановление из бэкапа
if (isset($_POST['restore_backup']) && isset($_POST['backup_file'])) {
    $backup_file = $backup_dir . $_POST['backup_file'];
    
    if (file_exists($backup_file)) {
        try {
            $pdo->beginTransaction();
            
            // Читаем файл бэкапа
            $sql = file_get_contents($backup_file);
            
            // Выполняем SQL запросы
            $pdo->exec($sql);
            
            $pdo->commit();
            $success = "База данных успешно восстановлена из бэкапа: " . $_POST['backup_file'];
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Ошибка при восстановлении бэкапа: " . $e->getMessage();
        }
    } else {
        $error = "Файл бэкапа не найден";
    }
}

// Удаление бэкапа
if (isset($_GET['delete'])) {
    $backup_file = $backup_dir . $_GET['delete'];
    if (file_exists($backup_file) && unlink($backup_file)) {
        $success = "Бэкап успешно удален";
    } else {
        $error = "Ошибка при удалении бэкапа";
    }
    header('Location: backup.php');
    exit;
}

// Получение списка бэкапов
$backups = [];
if (is_dir($backup_dir)) {
    $files = scandir($backup_dir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
            $file_path = $backup_dir . $file;
            $backups[] = [
                'name' => $file,
                'size' => filesize($file_path),
                'modified' => filemtime($file_path)
            ];
        }
    }
    
    // Сортируем по дате изменения (новые сверху)
    usort($backups, function($a, $b) {
        return $b['modified'] - $a['modified'];
    });
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Резервное копирование - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="admin_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Резервное копирование базы данных</h1>

        <?php if ($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <!-- Статистика -->
        <div class="backup-stats">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="stat-info">
                    <h3>Всего бэкапов</h3>
                    <p class="stat-number"><?= count($backups) ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-hdd"></i>
                </div>
                <div class="stat-info">
                    <h3>Общий размер</h3>
                    <p class="stat-number"><?= format_bytes(array_sum(array_column($backups, 'size'))) ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <h3>Последний бэкап</h3>
                    <p class="stat-number">
                        <?= !empty($backups) ? date('d.m.Y H:i', $backups[0]['modified']) : 'Нет' ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Быстрые действия -->
        <div class="quick-actions-section">
            <h2><i class="fas fa-bolt"></i> Быстрые действия</h2>
            <div class="action-buttons-grid">
                <form method="POST" class="backup-form">
                    <button type="submit" name="create_backup" class="action-button primary" onclick="return confirm('Создать новый бэкап базы данных?')">
                        <i class="fas fa-plus-circle"></i>
                        <span>Создать бэкап</span>
                        <small>Создать резервную копию всей БД</small>
                    </button>
                </form>
                
                
                </a>
            </div>
        </div>

        <!-- Список бэкапов -->
        <div class="backups-list">
            <div class="section-header">
                <h2><i class="fas fa-history"></i> Список бэкапов</h2>
                <div class="section-actions">
                    <span class="backups-count">Найдено бэкапов: <?= count($backups) ?></span>
                </div>
            </div>

            <?php if (!empty($backups)): ?>
                <div class="backups-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Имя файла</th>
                                <th>Размер</th>
                                <th>Дата создания</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backups as $backup): ?>
                                <tr>
                                    <td class="file-name">
                                        <i class="fas fa-file-code"></i>
                                        <?= htmlspecialchars($backup['name']) ?>
                                    </td>
                                    <td class="file-size"><?= format_bytes($backup['size']) ?></td>
                                    <td class="file-date"><?= date('d.m.Y H:i', $backup['modified']) ?></td>
                                    <td class="file-actions">
                                        <div class="action-buttons">
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="backup_file" value="<?= htmlspecialchars($backup['name']) ?>">
                                                <button type="submit" name="restore_backup" class="action-btn restore-btn" 
                                                        onclick="return confirm('ВНИМАНИЕ! Это перезапишет текущую базу данных. Продолжить?')"
                                                        title="Восстановить из этого бэкапа">
                                                    <i class="fas fa-undo"></i>
                                                </button>
                                            </form>
                                            
                                            <a href="<?= $backup_dir . htmlspecialchars($backup['name']) ?>" 
                                               download 
                                               class="action-btn download-btn"
                                               title="Скачать бэкап">
                                                <i class="fas fa-download"></i>
                                            </a>
                                            
                                            <a href="?delete=<?= htmlspecialchars($backup['name']) ?>" 
                                               class="action-btn delete-btn"
                                               onclick="return confirm('Удалить этот бэкап?')"
                                               title="Удалить бэкап">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-backups">
                    <i class="fas fa-database"></i>
                    <h3>Бэкапы не найдены</h3>
                    <p>Создайте первый бэкап базы данных</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Восстановление из бэкапа -->
        <div class="restore-section">
            <h2><i class="fas fa-undo"></i> Восстановление из бэкапа</h2>
            <div class="restore-form">
                <form method="POST">
                    <div class="form-group">
                        <label for="backup_file">Выберите бэкап для восстановления:</label>
                        <select id="backup_file" name="backup_file" required>
                            <option value="">-- Выберите файл бэкапа --</option>
                            <?php foreach ($backups as $backup): ?>
                                <option value="<?= htmlspecialchars($backup['name']) ?>">
                                    <?= htmlspecialchars($backup['name']) ?> (<?= date('d.m.Y H:i', $backup['modified']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" name="restore_backup" class="restore-button" 
                            onclick="return confirm('ВНИМАНИЕ! Это действие перезапишет текущую базу данных. Убедитесь, что у вас есть актуальный бэкап. Продолжить?')">
                        <i class="fas fa-undo"></i> Восстановить базу данных
                    </button>
                </form>
            </div>
            <div class="warning-message">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>Внимание!</strong> Восстановление из бэкапа полностью перезапишет текущую базу данных. 
                Убедитесь, что у вас есть актуальная резервная копия перед выполнением этой операции.
            </div>
        </div>

        <!-- Информация о бэкапах -->
        <div class="info-section">
            <h2><i class="fas fa-info-circle"></i> Информация о бэкапах</h2>
            <div class="info-cards">
                <div class="info-card">
                    <h3><i class="fas fa-shield-alt"></i> Безопасность</h3>
                    <p>Бэкапы хранятся в папке <code>backups/</code> и содержат полную структуру и данные базы данных.</p>
                </div>
                <div class="info-card">
                    <h3><i class="fas fa-history"></i> Рекомендации</h3>
                    <p>Создавайте бэкапы регулярно, особенно перед обновлением системы или внесением major изменений.</p>
                </div>
                <div class="info-card">
                    <h3><i class="fas fa-cloud-download-alt"></i> Хранение</h3>
                    <p>Рекомендуется скачивать важные бэкапы и хранить их в безопасном месте вне сервера.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Функция для форматирования размера файла
function format_bytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>

<style>
.backup-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.stat-card {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.stat-icon {
    width: 60px;
    height: 60px;
    background: var(--color);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5em;
    color: white;
}

.stat-info h3 {
    margin: 0 0 5px 0;
    color: var(--text-color);
    font-size: 0.9em;
    opacity: 0.8;
}

.stat-number {
    margin: 0;
    font-size: 1.8em;
    font-weight: bold;
    color: var(--text-color);
}

.quick-actions-section {
    background: var(--input-bg);
    padding: 30px;
    border-radius: 10px;
    margin: 30px 0;
}

.action-buttons-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.backup-form {
    margin: 0;
}

.action-button {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: 25px;
    background: var(--main-bg-color);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 10px;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
    width: 100%;
}

.action-button.primary {
    background: var(--color);
    color: white;
}

.action-button:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.action-button i {
    font-size: 2em;
    margin-bottom: 10px;
}

.action-button span {
    font-weight: bold;
    font-size: 1.1em;
    margin-bottom: 5px;
}

.action-button small {
    opacity: 0.8;
    font-size: 0.8em;
}

.backups-list {
    background: var(--input-bg);
    padding: 30px;
    border-radius: 10px;
    margin: 30px 0;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.section-header h2 {
    margin: 0;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.backups-count {
    color: var(--text-color);
    font-weight: bold;
}

.backups-table {
    overflow-x: auto;
}

.backups-table table {
    width: 100%;
    border-collapse: collapse;
}

.backups-table th,
.backups-table td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.backups-table th {
    background: var(--table-header-bg);
    font-weight: bold;
}

.file-name {
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: 500;
}

.file-name i {
    color: var(--color);
}

.file-size,
.file-date {
    color: var(--text-color);
    opacity: 0.8;
}

.action-buttons {
    display: flex;
    gap: 8px;
    justify-content: center;
}

.action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    border-radius: 5px;
    text-decoration: none;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
}

.restore-btn {
    background: #3498db;
    color: white;
}

.restore-btn:hover {
    background: #2980b9;
    transform: scale(1.1);
}

.download-btn {
    background: #27ae60;
    color: white;
}

.download-btn:hover {
    background: #219a52;
    transform: scale(1.1);
}

.delete-btn {
    background: #e74c3c;
    color: white;
}

.delete-btn:hover {
    background: #c0392b;
    transform: scale(1.1);
}

.no-backups {
    text-align: center;
    padding: 60px 40px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-backups i {
    font-size: 4em;
    margin-bottom: 20px;
}

.restore-section {
    background: var(--input-bg);
    padding: 30px;
    border-radius: 10px;
    margin: 30px 0;
}

.restore-form {
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: var(--text-color);
}

.form-group select {
    width: 100%;
    padding: 12px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
}

.restore-button {
    background: #e74c3c;
    color: white;
    padding: 15px 30px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.restore-button:hover {
    background: #c0392b;
    transform: translateY(-2px);
}

.warning-message {
    background: #f39c12;
    color: white;
    padding: 15px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-section {
    margin: 30px 0;
}

.info-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.info-card {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
}

.info-card h3 {
    margin-bottom: 15px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-card p {
    margin: 0;
    color: var(--text-color);
    opacity: 0.8;
    line-height: 1.5;
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

@media (max-width: 768px) {
    .backup-stats {
        grid-template-columns: 1fr;
    }
    
    .action-buttons-grid {
        grid-template-columns: 1fr;
    }
    
    .section-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .info-cards {
        grid-template-columns: 1fr;
    }
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>