<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Получение заказов в зависимости от роли
try {
    if ($role === 'client') {
        $stmt = $pdo->prepare("
            SELECT o.*, 
                   dp.first_name as driver_first_name,
                   dp.last_name as driver_last_name,
                   dp.phone_number as driver_phone
            FROM orders o
            LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id
            WHERE o.client_id = ?
            ORDER BY o.created_at DESC
        ");
        $stmt->execute([$user_id]);
    } elseif ($role === 'driver') {
        $stmt = $pdo->prepare("
            SELECT o.*, 
                   cp.first_name as client_first_name,
                   cp.last_name as client_last_name,
                   cp.phone_number as client_phone
            FROM orders o
            JOIN client_profiles cp ON o.client_id = cp.user_id
            WHERE o.driver_id = ?
            ORDER BY o.created_at DESC
        ");
        $stmt->execute([$user_id]);
    } else {
        // Администратор видит все заказы
        $stmt = $pdo->prepare("
            SELECT o.*, 
                   u_c.username as client_username,
                   u_d.username as driver_username,
                   cp.first_name as client_first_name,
                   cp.last_name as client_last_name,
                   dp.first_name as driver_first_name,
                   dp.last_name as driver_last_name
            FROM orders o
            JOIN users u_c ON o.client_id = u_c.id
            LEFT JOIN users u_d ON o.driver_id = u_d.id
            LEFT JOIN client_profiles cp ON o.client_id = cp.user_id
            LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id
            ORDER BY o.created_at DESC
        ");
        $stmt->execute();
    }
    
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $orders = [];
    $error = "Ошибка при получении заказов: " . $e->getMessage();
}

// Статистика
$total_orders = count($orders);
$completed_orders = count(array_filter($orders, function($order) { 
    return $order['status'] === 'completed'; 
}));
$total_revenue = array_sum(array_map(function($order) { 
    return $order['status'] === 'completed' ? $order['price'] : 0; 
}, $orders));
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заказы - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="<?= $role === 'client' ? 'index.php' : ($role === 'driver' ? 'index.php' : 'admin_dashboard.php') ?>" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1><?= $role === 'client' ? 'Мои заказы' : ($role === 'driver' ? 'История заказов' : 'Все заказы') ?></h1>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <!-- Статистика -->
        <div class="stats-container">
            <div class="stat-card">
                <h3>Всего заказов</h3>
                <p class="stat-number"><?= $total_orders ?></p>
            </div>
            <div class="stat-card">
                <h3>Завершено</h3>
                <p class="stat-number"><?= $completed_orders ?></p>
            </div>
            <?php if ($role !== 'client'): ?>
            <div class="stat-card">
                <h3>Общая выручка</h3>
                <p class="stat-number"><?= number_format($total_revenue, 2) ?> ₽</p>
            </div>
            <?php endif; ?>
            <div class="stat-card">
                <h3>Активные</h3>
                <p class="stat-number">
                    <?= count(array_filter($orders, function($order) { 
                        return in_array($order['status'], ['pending', 'accepted', 'in_progress']); 
                    })) ?>
                </p>
            </div>
        </div>

        <!-- Фильтры -->
        <div class="filters-section">
            <h3>Фильтры</h3>
            <div class="filter-buttons">
                <button class="filter-btn active" data-status="">Все</button>
                <button class="filter-btn" data-status="pending">Ожидание</button>
                <button class="filter-btn" data-status="accepted">Принятые</button>
                <button class="filter-btn" data-status="in_progress">В процессе</button>
                <button class="filter-btn" data-status="completed">Завершенные</button>
                <button class="filter-btn" data-status="cancelled">Отмененные</button>
            </div>
        </div>

        <!-- Список заказов -->
        <div class="orders-list">
            <?php if (!empty($orders)): ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-item" data-status="<?= $order['status'] ?>">
                        <div class="order-header">
                            <div class="order-title">
                                <h3>Заказ #<?= $order['id'] ?></h3>
                                <span class="order-price"><?= number_format($order['price'], 2) ?> ₽</span>
                            </div>
                            <div class="order-meta">
                                <span class="status-badge status-<?= $order['status'] ?>">
                                    <?= $order['status'] ?>
                                </span>
                                <span class="order-date"><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></span>
                            </div>
                        </div>

                        <div class="order-content">
                            <div class="route-section">
                                <h4><i class="fas fa-route"></i> Маршрут</h4>
                                <div class="route-details">
                                    <div class="route-point">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <div>
                                            <strong>Откуда:</strong>
                                            <p><?= htmlspecialchars($order['pickup_address']) ?></p>
                                        </div>
                                    </div>
                                    <div class="route-point">
                                        <i class="fas fa-flag-checkered"></i>
                                        <div>
                                            <strong>Куда:</strong>
                                            <p><?= htmlspecialchars($order['destination_address']) ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="participants-section">
                                <?php if ($role === 'client' && $order['driver_first_name']): ?>
                                    <div class="participant">
                                        <h4><i class="fas fa-id-card"></i> Водитель</h4>
                                        <p><?= htmlspecialchars($order['driver_first_name'] . ' ' . $order['driver_last_name']) ?></p>
                                        <?php if ($order['driver_phone']): ?>
                                            <p><small>Телефон: <?= htmlspecialchars($order['driver_phone']) ?></small></p>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($role === 'driver'): ?>
                                    <div class="participant">
                                        <h4><i class="fas fa-user"></i> Клиент</h4>
                                        <p><?= htmlspecialchars($order['client_first_name'] . ' ' . $order['client_last_name']) ?></p>
                                        <?php if ($order['client_phone']): ?>
                                            <p><small>Телефон: <?= htmlspecialchars($order['client_phone']) ?></small></p>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif ($role === 'admin'): ?>
                                    <div class="participants-grid">
                                        <div class="participant">
                                            <h4><i class="fas fa-user"></i> Клиент</h4>
                                            <p><?= htmlspecialchars($order['client_first_name'] . ' ' . $order['client_last_name']) ?></p>
                                            <p><small>Логин: <?= htmlspecialchars($order['client_username']) ?></small></p>
                                        </div>
                                        <?php if ($order['driver_first_name']): ?>
                                        <div class="participant">
                                            <h4><i class="fas fa-id-card"></i> Водитель</h4>
                                            <p><?= htmlspecialchars($order['driver_first_name'] . ' ' . $order['driver_last_name']) ?></p>
                                            <p><small>Логин: <?= htmlspecialchars($order['driver_username']) ?></small></p>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ($order['updated_at'] && $order['updated_at'] != $order['created_at']): ?>
                                <div class="order-updated">
                                    <small><i class="fas fa-sync"></i> Обновлен: <?= date('d.m.Y H:i', strtotime($order['updated_at'])) ?></small>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="order-actions">
                            <?php if (in_array($order['status'], ['accepted', 'in_progress']) && $order['driver_id']): ?>
                                <a href="chat.php?order_id=<?= $order['id'] ?>" class="action-button chat-button">
                                    <i class="fas fa-comments"></i> Чат
                                </a>
                            <?php endif; ?>
                            
                            <?php if ($role === 'admin'): ?>
                                <a href="order_details.php?id=<?= $order['id'] ?>" class="action-button view-button">
                                    <i class="fas fa-eye"></i> Подробнее
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-orders">
                    <i class="fas fa-list"></i>
                    <h3>Заказы не найдены</h3>
                    <p>У вас пока нет заказов.</p>
                    <?php if ($role === 'client'): ?>
                        <a href="create_order.php" class="action-button">
                            <i class="fas fa-taxi"></i> Создать первый заказ
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.stats-container {
    display: flex;
    gap: 20px;
    margin: 30px 0;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1;
    min-width: 150px;
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.stat-number {
    font-size: 2em;
    font-weight: bold;
    margin: 10px 0;
    color: var(--text-color);
}

.filters-section {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin: 30px 0;
}

.filter-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 8px 16px;
    background: var(--main-bg-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.filter-btn.active,
.filter-btn:hover {
    background: var(--color);
    color: white;
    border-color: var(--color);
}

.orders-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin: 30px 0;
}

.order-item {
    background: var(--input-bg);
    border-radius: 10px;
    padding: 25px;
    border-left: 4px solid var(--color);
    transition: all 0.3s ease;
}

.order-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.order-title {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.order-title h3 {
    margin: 0;
    color: var(--text-color);
}

.order-price {
    background: var(--color);
    color: white;
    padding: 6px 12px;
    border-radius: 15px;
    font-weight: bold;
    font-size: 0.9em;
}

.order-meta {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.order-date {
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.9em;
}

.order-content {
    margin-bottom: 20px;
}

.route-section,
.participants-section {
    margin-bottom: 20px;
}

.route-section h4,
.participants-section h4 {
    margin-bottom: 10px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 8px;
}

.route-details {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.route-point {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 10px;
    background: var(--main-bg-color);
    border-radius: 5px;
}

.route-point i {
    margin-top: 2px;
    color: var(--color);
}

.route-point:first-child i {
    color: #e74c3c;
}

.route-point:last-child i {
    color: #27ae60;
}

.participants-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.participant {
    padding: 15px;
    background: var(--main-bg-color);
    border-radius: 5px;
}

.participant h4 {
    margin-bottom: 8px;
}

.order-updated {
    text-align: right;
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid var(--border-color);
}

.order-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.action-button {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 0.9em;
    transition: all 0.3s ease;
}

.action-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.chat-button {
    background: #3498db;
}

.chat-button:hover {
    background: #2980b9;
}

.view-button {
    background: #f39c12;
}

.view-button:hover {
    background: #e67e22;
}

.no-orders {
    text-align: center;
    padding: 60px 40px;
    background: var(--input-bg);
    border-radius: 10px;
}

.no-orders i {
    font-size: 4em;
    margin-bottom: 20px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-orders h3 {
    margin-bottom: 10px;
    color: var(--text-color);
}

.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
    display: inline-block;
    text-align: center;
    min-width: 100px;
}

.status-pending { background: #f39c12; color: white; }
.status-accepted { background: #3498db; color: white; }
.status-in_progress { background: #9b59b6; color: white; }
.status-completed { background: #27ae60; color: white; }
.status-cancelled { background: #e74c3c; color: white; }

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Фильтрация заказов
    const filterButtons = document.querySelectorAll('.filter-btn');
    const orderItems = document.querySelectorAll('.order-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Убираем активный класс у всех кнопок
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Добавляем активный класс текущей кнопке
            this.classList.add('active');

            const status = this.getAttribute('data-status');

            orderItems.forEach(item => {
                if (status === '' || item.getAttribute('data-status') === status) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
});
</script>

</body>
</html>