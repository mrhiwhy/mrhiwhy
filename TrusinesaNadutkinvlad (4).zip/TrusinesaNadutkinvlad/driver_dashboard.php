<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'driver') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Получение профиля водителя
try {
    $stmt = $pdo->prepare("
        SELECT dp.*, u.email 
        FROM driver_profiles dp 
        JOIN users u ON dp.user_id = u.id 
        WHERE dp.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $driver_profile = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $driver_profile = [];
}

// Переключение статуса доступности
if (isset($_POST['toggle_availability'])) {
    try {
        $new_status = $driver_profile['is_available'] ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE driver_profiles SET is_available = ? WHERE user_id = ?");
        $stmt->execute([$new_status, $user_id]);
        header('Location: driver_dashboard.php');
        exit;
    } catch (PDOException $e) {
        $error = "Ошибка при изменении статуса: " . $e->getMessage();
    }
}

// Получение активных заказов водителя
try {
    $stmt = $pdo->prepare("
        SELECT o.*, cp.first_name as client_name, cp.phone_number as client_phone
        FROM orders o 
        JOIN client_profiles cp ON o.client_id = cp.user_id 
        WHERE o.driver_id = ? AND o.status IN ('accepted', 'in_progress')
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $active_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $active_orders = [];
}

// Получение истории заказов
try {
    $stmt = $pdo->prepare("
        SELECT o.*, cp.first_name as client_name
        FROM orders o 
        JOIN client_profiles cp ON o.client_id = cp.user_id 
        WHERE o.driver_id = ? AND o.status IN ('completed', 'cancelled')
        ORDER BY o.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $order_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $order_history = [];
}

// Статистика водителя
try {
    // Общее количество выполненных заказов
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_orders FROM orders WHERE driver_id = ? AND status = 'completed'");
    $stmt->execute([$user_id]);
    $total_orders = $stmt->fetch(PDO::FETCH_ASSOC)['total_orders'];

    // Общая выручка
    $stmt = $pdo->prepare("SELECT SUM(price) as total_earnings FROM orders WHERE driver_id = ? AND status = 'completed'");
    $stmt->execute([$user_id]);
    $total_earnings = $stmt->fetch(PDO::FETCH_ASSOC)['total_earnings'] ?? 0;

    // Выручка за сегодня
    $stmt = $pdo->prepare("SELECT SUM(price) as today_earnings FROM orders WHERE driver_id = ? AND status = 'completed' AND DATE(created_at) = CURDATE()");
    $stmt->execute([$user_id]);
    $today_earnings = $stmt->fetch(PDO::FETCH_ASSOC)['today_earnings'] ?? 0;
} catch (PDOException $e) {
    $total_orders = 0;
    $total_earnings = 0;
    $today_earnings = 0;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель водителя - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="index.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Панель водителя</h1>
        
        <?php if (isset($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <?php if ($driver_profile): ?>
            <div class="profile-info">
                <h2>Добро пожаловать, <?= htmlspecialchars($driver_profile['first_name']) ?>!</h2>
                <div class="profile-details">
                    <div class="profile-column">
                        <p><strong>Имя:</strong> <?= htmlspecialchars($driver_profile['first_name']) ?></p>
                        <p><strong>Фамилия:</strong> <?= htmlspecialchars($driver_profile['last_name']) ?></p>
                        <p><strong>Телефон:</strong> <?= htmlspecialchars($driver_profile['phone_number']) ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($driver_profile['email']) ?></p>
                    </div>
                    <div class="profile-column">
                        <p><strong>Автомобиль:</strong> <?= htmlspecialchars($driver_profile['car_model']) ?> (<?= htmlspecialchars($driver_profile['car_color']) ?>)</p>
                        <p><strong>Госномер:</strong> <?= htmlspecialchars($driver_profile['license_plate']) ?></p>
                        <p><strong>Водительское удостоверение:</strong> <?= htmlspecialchars($driver_profile['license_number']) ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Статус доступности -->
        <div class="availability-section">
            <form method="POST" class="availability-form">
                <h3>Статус доступности</h3>
                <div class="availability-status">
                    <span class="status-indicator <?= $driver_profile['is_available'] ? 'available' : 'unavailable' ?>">
                        <?= $driver_profile['is_available'] ? 'Доступен' : 'Не доступен' ?>
                    </span>
                    <button type="submit" name="toggle_availability" class="toggle-button">
                        <?= $driver_profile['is_available'] ? 'Стать недоступным' : 'Стать доступным' ?>
                    </button>
                </div>
                <p class="availability-note">
                    <?= $driver_profile['is_available'] ? 
                        'Вы получаете новые заказы. Для остановки приема заказов нажмите кнопку выше.' : 
                        'Вы не получаете новые заказы. Для начала работы нажмите кнопку выше.' ?>
                </p>
            </form>
        </div>

        <!-- Статистика -->
        <div class="stats-container">
            <div class="stat-card">
                <h3>Выполнено заказов</h3>
                <p class="stat-number"><?= $total_orders ?></p>
            </div>
            <div class="stat-card">
                <h3>Общая выручка</h3>
                <p class="stat-number"><?= number_format($total_earnings, 2) ?> ₽</p>
            </div>
            <div class="stat-card">
                <h3>Выручка за сегодня</h3>
                <p class="stat-number"><?= number_format($today_earnings, 2) ?> ₽</p>
            </div>
        </div>

        <!-- Активные заказы -->
        <div class="active-orders">
            <h3>Текущие заказы</h3>
            <?php if (!empty($active_orders)): ?>
                <div class="orders-list">
                    <?php foreach ($active_orders as $order): ?>
                        <div class="order-card">
                            <div class="order-header">
                                <h4>Заказ #<?= $order['id'] ?></h4>
                                <span class="status-badge status-<?= $order['status'] ?>">
                                    <?= $order['status'] ?>
                                </span>
                            </div>
                            <div class="order-details">
                                <p><strong>Клиент:</strong> <?= htmlspecialchars($order['client_name']) ?></p>
                                <p><strong>Телефон клиента:</strong> <?= htmlspecialchars($order['client_phone']) ?></p>
                                <p><strong>От:</strong> <?= htmlspecialchars($order['pickup_address']) ?></p>
                                <p><strong>До:</strong> <?= htmlspecialchars($order['destination_address']) ?></p>
                                <p><strong>Стоимость:</strong> <?= number_format($order['price'], 2) ?> ₽</p>
                                <p><strong>Создан:</strong> <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></p>
                            </div>
                            <div class="order-actions">
                                <?php if ($order['status'] === 'accepted'): ?>
                                    <form action="update_order_status.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <input type="hidden" name="status" value="in_progress">
                                        <button type="submit" class="action-button start-ride">
                                            <i class="fas fa-play"></i> Начать поездку
                                        </button>
                                    </form>
                                <?php elseif ($order['status'] === 'in_progress'): ?>
                                    <form action="update_order_status.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <input type="hidden" name="status" value="completed">
                                        <button type="submit" class="action-button complete-ride">
                                            <i class="fas fa-check"></i> Завершить поездку
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <a href="chat.php?order_id=<?= $order['id'] ?>" class="chat-button">
                                    <i class="fas fa-comments"></i> Чат с клиентом
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>У вас нет активных заказов</p>
                <?php if ($driver_profile['is_available']): ?>
                    <p>Ожидайте новых заказов...</p>
                <?php else: ?>
                    <p>Для получения заказов станьте доступным</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- История заказов -->
        <div class="order-history">
            <h3>История заказов</h3>
            <?php if (!empty($order_history)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Клиент</th>
                            <th>Маршрут</th>
                            <th>Статус</th>
                            <th>Стоимость</th>
                            <th>Дата</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_history as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= htmlspecialchars($order['client_name']) ?></td>
                                <td>
                                    <small><?= htmlspecialchars($order['pickup_address']) ?></small><br>
                                    <small>→ <?= htmlspecialchars($order['destination_address']) ?></small>
                                </td>
                                <td>
                                    <span class="status-badge status-<?= $order['status'] ?>">
                                        <?= $order['status'] ?>
                                    </span>
                                </td>
                                <td><?= number_format($order['price'], 2) ?> ₽</td>
                                <td><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="my_orders.php" class="view-all-button">Посмотреть все заказы</a>
                </div>
            <?php else: ?>
                <p>История заказов пуста</p>
            <?php endif; ?>
        </div>

        <!-- Быстрые действия -->
        <div class="quick-actions">
            <h3>Быстрые действия</h3>
            <div class="actions-grid">
                <a href="available_orders.php" class="action-button">
                    <i class="fas fa-list"></i>
                    Доступные заказы
                </a>
                <a href="my_orders.php" class="action-button">
                    <i class="fas fa-history"></i>
                    Мои заказы
                </a>
                <a href="driver_profile.php" class="action-button">
                    <i class="fas fa-user-edit"></i>
                    Редактировать профиль
                </a>
            </div>
        </div>
    </div>
</div>

<style>
.profile-info {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 30px;
}

.profile-details {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.profile-column p {
    margin: 8px 0;
}

.availability-section {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 30px;
    text-align: center;
}

.availability-status {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 20px;
    margin: 15px 0;
    flex-wrap: wrap;
}

.status-indicator {
    padding: 10px 20px;
    border-radius: 25px;
    font-weight: bold;
    font-size: 1.1em;
}

.status-indicator.available {
    background: #27ae60;
    color: white;
}

.status-indicator.unavailable {
    background: #e74c3c;
    color: white;
}

.toggle-button {
    padding: 10px 20px;
    background: var(--color);
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1em;
    transition: all 0.3s ease;
}

.toggle-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.availability-note {
    margin-top: 10px;
    font-style: italic;
    color: var(--text-color);
    opacity: 0.8;
}

.stats-container {
    display: flex;
    gap: 20px;
    margin: 30px 0;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1;
    min-width: 200px;
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.stat-number {
    font-size: 2em;
    font-weight: bold;
    margin: 10px 0;
    color: var(--text-color);
}

.active-orders, .order-history {
    margin: 30px 0;
}

.orders-list {
    display: grid;
    gap: 15px;
}

.order-card {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    border-left: 4px solid var(--color);
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    flex-wrap: wrap;
    gap: 10px;
}

.order-details p {
    margin: 5px 0;
}

.order-actions {
    margin-top: 15px;
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.action-button {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 8px 15px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease;
    font-size: 0.9em;
}

.action-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.start-ride {
    background: #27ae60;
}

.start-ride:hover {
    background: #219a52;
}

.complete-ride {
    background: #3498db;
}

.complete-ride:hover {
    background: #2980b9;
}

.chat-button {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 8px 15px;
    background: #9b59b6;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background 0.3s ease;
}

.chat-button:hover {
    background: #8e44ad;
}

.view-all-button {
    display: inline-block;
    padding: 10px 20px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.view-all-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.quick-actions {
    margin: 30px 0;
}

.actions-grid {
    display: grid;
    gap: 15px;
}

.actions-grid .action-button {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
    text-align: center;
    gap: 10px;
    font-size: 1em;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
}

.status-pending { background: #f39c12; color: white; }
.status-accepted { background: #3498db; color: white; }
.status-in_progress { background: #9b59b6; color: white; }
.status-completed { background: #27ae60; color: white; }
.status-cancelled { background: #e74c3c; color: white; }
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>