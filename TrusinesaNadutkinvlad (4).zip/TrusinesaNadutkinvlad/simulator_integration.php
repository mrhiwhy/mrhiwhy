<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Получение статистики для интеграции
try {
    // Статистика по заказам
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_orders,
            AVG(price) as avg_price,
            SUM(price) as total_revenue
        FROM orders 
        WHERE status = 'completed'
        AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $order_stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Популярные маршруты
    $stmt = $pdo->query("
        SELECT 
            pickup_address,
            destination_address,
            COUNT(*) as trip_count,
            AVG(price) as avg_price
        FROM orders 
        WHERE status = 'completed'
        GROUP BY pickup_address, destination_address
        ORDER BY trip_count DESC
        LIMIT 10
    ");
    $popular_routes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $order_stats = [];
    $popular_routes = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Интеграция с симулятором - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <style>
        .integration-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .stat-card {
            background: var(--input-bg);
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            border-left: 4px solid var(--color);
        }
        
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: var(--text-color);
            margin: 10px 0;
        }
        
        .routes-table {
            background: var(--input-bg);
            padding: 25px;
            border-radius: 10px;
            margin: 30px 0;
        }
        
        .export-buttons {
            display: flex;
            gap: 15px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        
        .export-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: var(--color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .export-btn:hover {
            background: var(--color);
            transform: translateY(-2px);
        }
    </style>
    <?php include 'favicon.php'; ?>
</head>
<body>

<a href="admin_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Интеграция с симулятором перевозок</h1>
        
        <div class="integration-stats">
            <div class="stat-card">
                <h3>Заказов за 30 дней</h3>
                <div class="stat-number"><?= $order_stats['total_orders'] ?? 0 ?></div>
                <p>для анализа в симуляторе</p>
            </div>
            <div class="stat-card">
                <h3>Средний чек</h3>
                <div class="stat-number"><?= number_format($order_stats['avg_price'] ?? 0, 2) ?> ₽</div>
                <p>реальная стоимость перевозок</p>
            </div>
            <div class="stat-card">
                <h3>Общая выручка</h3>
                <div class="stat-number"><?= number_format($order_stats['total_revenue'] ?? 0, 2) ?> ₽</div>
                <p>за 30 дней</p>
            </div>
        </div>

        <div class="export-buttons">
            <a href="transfer_simulator.php" class="export-btn">
                <i class="fas fa-external-link-alt"></i> Перейти к симулятору
            </a>
            <button onclick="exportData()" class="export-btn" style="background: #27ae60;">
                <i class="fas fa-download"></i> Экспорт данных для симулятора
            </button>
            <button onclick="showIntegrationGuide()" class="export-btn" style="background: #3498db;">
                <i class="fas fa-book"></i> Руководство по интеграции
            </button>
        </div>

        <?php if (!empty($popular_routes)): ?>
        <div class="routes-table">
            <h2><i class="fas fa-route"></i> Популярные маршруты для симуляции</h2>
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <thead>
                    <tr>
                        <th style="padding: 12px; text-align: left; border-bottom: 1px solid var(--border-color);">Откуда</th>
                        <th style="padding: 12px; text-align: left; border-bottom: 1px solid var(--border-color);">Куда</th>
                        <th style="padding: 12px; text-align: center; border-bottom: 1px solid var(--border-color);">Количество поездок</th>
                        <th style="padding: 12px; text-align: center; border-bottom: 1px solid var(--border-color);">Средняя стоимость</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($popular_routes as $route): ?>
                    <tr>
                        <td style="padding: 12px; border-bottom: 1px solid var(--border-color);"><?= htmlspecialchars($route['pickup_address']) ?></td>
                        <td style="padding: 12px; border-bottom: 1px solid var(--border-color);"><?= htmlspecialchars($route['destination_address']) ?></td>
                        <td style="padding: 12px; text-align: center; border-bottom: 1px solid var(--border-color);"><?= $route['trip_count'] ?></td>
                        <td style="padding: 12px; text-align: center; border-bottom: 1px solid var(--border-color);"><?= number_format($route['avg_price'], 2) ?> ₽</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function exportData() {
    // Здесь можно реализовать экспорт данных в формате для симулятора
    alert('Функция экспорта данных будет реализована в следующей версии');
}

function showIntegrationGuide() {
    alert(`Руководство по интеграции с симулятором перевозок:

1. Используйте реальные данные о заказах для калибровки симулятора
2. Анализируйте популярные маршруты для оптимизации логистики
3. Сравнивайте результаты симуляции с реальными показателями
4. Используйте симулятор для тестирования новых тарифных планов

Для начала работы перейдите в раздел "Симулятор перевозок".`);
}

// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>