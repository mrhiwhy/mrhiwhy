<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = $_GET['order_id'] ?? null;

if (!$order_id) {
    header('Location: ' . ($_SESSION['role'] === 'client' ? 'client_dashboard.php' : 'driver_dashboard.php'));
    exit;
}

// Проверка доступа к чату
try {
    $stmt = $pdo->prepare("
        SELECT o.*, 
               o.client_id,
               o.driver_id
        FROM orders o
        WHERE o.id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        die("Заказ не найден");
    }

    // Проверяем, имеет ли пользователь доступ к этому чату
    $has_access = false;
    if ($_SESSION['role'] === 'client' && $order['client_id'] == $user_id) {
        $has_access = true;
    } elseif ($_SESSION['role'] === 'driver' && $order['driver_id'] == $user_id) {
        $has_access = true;
    } elseif ($_SESSION['role'] === 'admin') {
        $has_access = true;
    }

    if (!$has_access) {
        die("Доступ к чату запрещен");
    }

} catch (PDOException $e) {
    die("Ошибка при проверке доступа: " . $e->getMessage());
}

// Получение сообщений
try {
    $stmt = $pdo->prepare("
        SELECT m.*, u.username, u.role
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.order_id = ?
        ORDER BY m.sent_at ASC
    ");
    $stmt->execute([$order_id]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $messages = [];
}

// Отправка сообщения
if (isset($_POST['send_message']) && !empty(trim($_POST['message_text']))) {
    $message_text = trim($_POST['message_text']);
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO messages (order_id, sender_id, message_text) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$order_id, $user_id, $message_text]);
        
        // Перенаправление чтобы избежать повторной отправки
        header("Location: chat.php?order_id=" . $order_id);
        exit;
    } catch (PDOException $e) {
        $error = "Ошибка при отправке сообщения: " . $e->getMessage();
    }
}

// Получение информации о собеседнике
try {
    if ($_SESSION['role'] === 'client' && $order['driver_id']) {
        $stmt = $pdo->prepare("
            SELECT u.username, dp.first_name, dp.last_name, dp.phone_number
            FROM users u
            JOIN driver_profiles dp ON u.id = dp.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$order['driver_id']]);
        $companion = $stmt->fetch(PDO::FETCH_ASSOC);
        $companion_name = $companion ? $companion['first_name'] . ' ' . $companion['last_name'] : 'Водитель';
    } elseif ($_SESSION['role'] === 'driver' && $order['client_id']) {
        $stmt = $pdo->prepare("
            SELECT u.username, cp.first_name, cp.last_name, cp.phone_number
            FROM users u
            JOIN client_profiles cp ON u.id = cp.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$order['client_id']]);
        $companion = $stmt->fetch(PDO::FETCH_ASSOC);
        $companion_name = $companion ? $companion['first_name'] . ' ' . $companion['last_name'] : 'Клиент';
    } else {
        $companion_name = 'Собеседник';
    }
} catch (PDOException $e) {
    $companion_name = 'Собеседник';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Чат - Заказ #<?= $order_id ?> - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="<?= $_SESSION['role'] === 'client' ? 'client_dashboard.php' : 'driver_dashboard.php' ?>" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <div class="chat-header">
            <h1>Чат по заказу #<?= $order_id ?></h1>
            <div class="order-info">
                <p><strong>Маршрут:</strong> <?= htmlspecialchars($order['pickup_address']) ?> → <?= htmlspecialchars($order['destination_address']) ?></p>
                <p><strong>Собеседник:</strong> <?= htmlspecialchars($companion_name) ?></p>
                <?php if (isset($companion) && $companion['phone_number']): ?>
                    <p><strong>Телефон:</strong> <?= htmlspecialchars($companion['phone_number']) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <div class="chat-container">
            <div class="messages-container" id="messagesContainer">
                <?php if (empty($messages)): ?>
                    <div class="no-messages">
                        <i class="fas fa-comments"></i>
                        <p>Нет сообщений</p>
                        <small>Начните общение первым</small>
                    </div>
                <?php else: ?>
                    <?php foreach ($messages as $message): ?>
                        <div class="message <?= $message['sender_id'] == $user_id ? 'own-message' : 'other-message' ?>">
                            <div class="message-header">
                                <span class="sender-name">
                                    <?= $message['sender_id'] == $user_id ? 'Вы' : htmlspecialchars($message['username']) ?>
                                </span>
                                <span class="message-time">
                                    <?= date('H:i', strtotime($message['sent_at'])) ?>
                                </span>
                            </div>
                            <div class="message-text">
                                <?= nl2br(htmlspecialchars($message['message_text'])) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <form method="POST" class="message-form" id="messageForm">
                <div class="input-group">
                    <textarea name="message_text" placeholder="Введите сообщение..." required rows="1"></textarea>
                    <button type="submit" name="send_message" class="send-button">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.chat-header {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
}

.order-info {
    margin-top: 15px;
}

.order-info p {
    margin: 5px 0;
    font-size: 0.9em;
}

.chat-container {
    background: var(--input-bg);
    border-radius: 10px;
    overflow: hidden;
    height: 70vh;
    display: flex;
    flex-direction: column;
}

.messages-container {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.no-messages {
    text-align: center;
    padding: 40px;
    color: var(--text-color);
    opacity: 0.7;
}

.no-messages i {
    font-size: 3em;
    margin-bottom: 15px;
}

.message {
    max-width: 70%;
    padding: 12px 16px;
    border-radius: 15px;
    position: relative;
}

.own-message {
    align-self: flex-end;
    background: var(--color);
    color: white;
    border-bottom-right-radius: 5px;
}

.other-message {
    align-self: flex-start;
    background: var(--main-bg-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
    border-bottom-left-radius: 5px;
}

.message-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 5px;
    font-size: 0.8em;
    opacity: 0.8;
}

.sender-name {
    font-weight: bold;
}

.message-time {
    font-size: 0.7em;
}

.message-text {
    word-wrap: break-word;
    line-height: 1.4;
}

.message-form {
    padding: 20px;
    border-top: 1px solid var(--border-color);
    background: var(--input-bg);
}

.input-group {
    display: flex;
    gap: 10px;
    align-items: end;
}

.input-group textarea {
    flex: 1;
    padding: 12px;
    border: 1px solid var(--border-color);
    border-radius: 20px;
    background: var(--main-bg-color);
    color: var(--text-color);
    resize: none;
    min-height: 40px;
    max-height: 120px;
    font-family: inherit;
}

.input-group textarea:focus {
    outline: none;
    border-color: var(--color);
}

.send-button {
    background: var(--color);
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.send-button:hover {
    background: var(--color);
    transform: scale(1.1);
}

.send-button:disabled {
    background: var(--border-color);
    cursor: not-allowed;
    transform: none;
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Стили для скроллбара */
.messages-container::-webkit-scrollbar {
    width: 6px;
}

.messages-container::-webkit-scrollbar-track {
    background: transparent;
}

.messages-container::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
    background: var(--color);
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Автопрокрутка к последнему сообщению
    const messagesContainer = document.getElementById('messagesContainer');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    // Автоматическое увеличение высоты textarea
    const textarea = document.querySelector('textarea[name="message_text"]');
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // Фокус на поле ввода при загрузке
    textarea.focus();
});

// Автообновление чата каждые 5 секунд
setInterval(function() {
    const messagesContainer = document.getElementById('messagesContainer');
    const scrollPos = messagesContainer.scrollTop;
    const isScrolledToBottom = messagesContainer.scrollHeight - messagesContainer.clientHeight <= scrollPos + 10;

    fetch('get_messages.php?order_id=<?= $order_id ?>')
        .then(response => response.text())
        .then(html => {
            messagesContainer.innerHTML = html;
            if (isScrolledToBottom) {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }
        })
        .catch(error => console.error('Ошибка обновления чата:', error));
}, 5000);
</script>

</body>
</html>