<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'client') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Получение профиля клиента
try {
    $stmt = $pdo->prepare("
        SELECT cp.*, u.email 
        FROM client_profiles cp 
        JOIN users u ON cp.user_id = u.id 
        WHERE cp.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $client_profile = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $client_profile = [];
}

// Получение активных заказов клиента
try {
    $stmt = $pdo->prepare("
        SELECT o.*, dp.first_name as driver_name, dp.phone_number as driver_phone
        FROM orders o 
        LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id 
        WHERE o.client_id = ? AND o.status IN ('pending', 'accepted', 'in_progress')
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $active_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $active_orders = [];
}

// Получение истории заказов
try {
    $stmt = $pdo->prepare("
        SELECT o.*, dp.first_name as driver_name
        FROM orders o 
        LEFT JOIN driver_profiles dp ON o.driver_id = dp.user_id 
        WHERE o.client_id = ? AND o.status IN ('completed', 'cancelled')
        ORDER BY o.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $order_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $order_history = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель клиента - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="index.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Панель клиента</h1>
        
        <?php if ($client_profile): ?>
            <div class="profile-info">
                <h2>Добро пожаловать, <?= htmlspecialchars($client_profile['first_name']) ?>!</h2>
                <div class="profile-details">
                    <p><strong>Имя:</strong> <?= htmlspecialchars($client_profile['first_name']) ?></p>
                    <p><strong>Фамилия:</strong> <?= htmlspecialchars($client_profile['last_name']) ?></p>
                    <p><strong>Телефон:</strong> <?= htmlspecialchars($client_profile['phone_number']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($client_profile['email']) ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Быстрое создание заказа -->
        <div class="quick-order">
            <h3>Быстрый заказ такси</h3>
            <form action="create_order.php" method="POST" class="order-form">
                <div class="form-group">
                    <label for="pickup_address">Адрес подачи:</label>
                    <input type="text" id="pickup_address" name="pickup_address" required placeholder="Улица, дом">
                </div>
                <div class="form-group">
                    <label for="destination_address">Адрес назначения:</label>
                    <input type="text" id="destination_address" name="destination_address" required placeholder="Улица, дом">
                </div>
                <button type="submit" class="order-button">
                    <i class="fas fa-taxi"></i> Заказать такси
                </button>
            </form>
        </div>

        <!-- Активные заказы -->
        <div class="active-orders">
            <h3>Активные заказы</h3>
            <?php if (!empty($active_orders)): ?>
                <div class="orders-list">
                    <?php foreach ($active_orders as $order): ?>
                        <div class="order-card">
                            <div class="order-header">
                                <h4>Заказ #<?= $order['id'] ?></h4>
                                <span class="status-badge status-<?= $order['status'] ?>">
                                    <?= $order['status'] ?>
                                </span>
                            </div>
                            <div class="order-details">
                                <p><strong>От:</strong> <?= htmlspecialchars($order['pickup_address']) ?></p>
                                <p><strong>До:</strong> <?= htmlspecialchars($order['destination_address']) ?></p>
                                <?php if ($order['driver_name']): ?>
                                    <p><strong>Водитель:</strong> <?= htmlspecialchars($order['driver_name']) ?></p>
                                    <p><strong>Телефон водителя:</strong> <?= htmlspecialchars($order['driver_phone']) ?></p>
                                <?php else: ?>
                                    <p><strong>Водитель:</strong> Ожидание назначения</p>
                                <?php endif; ?>
                                <?php if ($order['price']): ?>
                                    <p><strong>Стоимость:</strong> <?= number_format($order['price'], 2) ?> ₽</p>
                                <?php endif; ?>
                                <p><strong>Создан:</strong> <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></p>
                            </div>
                            <?php if ($order['driver_id']): ?>
                                <div class="order-actions">
                                    <a href="chat.php?order_id=<?= $order['id'] ?>" class="chat-button">
                                        <i class="fas fa-comments"></i> Чат с водителем
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>У вас нет активных заказов</p>
            <?php endif; ?>
        </div>

        <!-- История заказов -->
        <div class="order-history">
            <h3>История заказов</h3>
            <?php if (!empty($order_history)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Маршрут</th>
                            <th>Водитель</th>
                            <th>Статус</th>
                            <th>Стоимость</th>
                            <th>Дата</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_history as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td>
                                    <small><?= htmlspecialchars($order['pickup_address']) ?></small><br>
                                    <small>→ <?= htmlspecialchars($order['destination_address']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($order['driver_name'] ?? 'Не назначен') ?></td>
                                <td>
                                    <span class="status-badge status-<?= $order['status'] ?>">
                                        <?= $order['status'] ?>
                                    </span>
                                </td>
                                <td><?= number_format($order['price'], 2) ?> ₽</td>
                                <td><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="my_orders.php" class="view-all-button">Посмотреть все заказы</a>
                </div>
            <?php else: ?>
                <p>История заказов пуста</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.profile-info {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 30px;
}

.profile-details {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-top: 15px;
}

.quick-order {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 30px;
}

.order-form {
    display: grid;
    gap: 15px;
    max-width: 500px;
}

.form-group {
    display: flex;
    flex-direction: column;
}

.form-group label {
    margin-bottom: 5px;
    font-weight: bold;
}

.order-button {
    background: var(--color);
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.3s ease;
}

.order-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.active-orders, .order-history {
    margin: 30px 0;
}

.orders-list {
    display: grid;
    gap: 15px;
}

.order-card {
    background: var(--input-bg);
    padding: 20px;
    border-radius: 10px;
    border-left: 4px solid var(--color);
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.order-details p {
    margin: 5px 0;
}

.order-actions {
    margin-top: 15px;
}

.chat-button {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 8px 15px;
    background: #3498db;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: background 0.3s ease;
}

.chat-button:hover {
    background: #2980b9;
}

.view-all-button {
    display: inline-block;
    padding: 10px 20px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.view-all-button:hover {
    background: var(--color);
    transform: translateY(-2px);
}

.status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.8em;
    font-weight: bold;
    text-transform: capitalize;
}

.status-pending { background: #f39c12; color: white; }
.status-accepted { background: #3498db; color: white; }
.status-in_progress { background: #9b59b6; color: white; }
.status-completed { background: #27ae60; color: white; }
.status-cancelled { background: #e74c3c; color: white; }
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>