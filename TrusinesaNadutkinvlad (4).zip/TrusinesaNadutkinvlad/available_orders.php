<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли водителя
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'driver') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Проверка, доступен ли водитель
try {
    $stmt = $pdo->prepare("SELECT is_available FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $driver = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$driver || !$driver['is_available']) {
        $not_available = true;
    }
} catch (PDOException $e) {
    $not_available = true;
}

// Получение доступных заказов
if (!isset($not_available)) {
    try {
        $stmt = $pdo->prepare("
            SELECT o.*, 
                   u.username as client_username,
                   cp.first_name as client_first_name,
                   cp.last_name as client_last_name,
                   cp.phone_number as client_phone
            FROM orders o
            JOIN users u ON o.client_id = u.id
            JOIN client_profiles cp ON o.client_id = cp.user_id
            WHERE o.status = 'pending' AND o.driver_id IS NULL
            ORDER BY o.created_at DESC
        ");
        $stmt->execute();
        $available_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $available_orders = [];
        $error = "Ошибка при получении заказов: " . $e->getMessage();
    }
}

// Принятие заказа
if (isset($_POST['accept_order'])) {
    $order_id = $_POST['order_id'];
    
    try {
        $pdo->beginTransaction();
        
        // Проверяем, не принят ли заказ другим водителем
        $stmt = $pdo->prepare("SELECT status, driver_id FROM orders WHERE id = ? FOR UPDATE");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($order && $order['status'] === 'pending' && !$order['driver_id']) {
            // Принимаем заказ
            $stmt = $pdo->prepare("UPDATE orders SET driver_id = ?, status = 'accepted' WHERE id = ?");
            $stmt->execute([$user_id, $order_id]);
            
            $pdo->commit();
            $success = "Заказ успешно принят!";
            header('Location: driver_dashboard.php');
            exit;
        } else {
            $pdo->rollBack();
            $error = "Этот заказ уже был принят другим водителем";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Ошибка при принятии заказа: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Доступные заказы - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="index.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Доступные заказы</h1>

        <?php if (isset($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <?php if (isset($not_available)): ?>
            <div class="not-available-message">
                <i class="fas fa-user-slash"></i>
                <h2>Вы не доступны для принятия заказов</h2>
                <p>Для просмотра и принятия заказов необходимо стать доступным в панели водителя.</p>
                <a href="driver_dashboard.php" class="action-button">
                    <i class="fas fa-tachometer-alt"></i> Перейти в панель водителя
                </a>
            </div>
        <?php elseif (empty($available_orders)): ?>
            <div class="no-orders-message">
                <i class="fas fa-list"></i>
                <h2>Нет доступных заказов</h2>
                <p>В данный момент нет новых заказов. Ожидайте поступления новых заказов.</p>
                <div class="refresh-info">
                    <i class="fas fa-sync"></i>
                    <span>Страница автоматически обновляется каждые 30 секунд</span>
                </div>
            </div>
        <?php else: ?>
            <div class="orders-grid">
                <?php foreach ($available_orders as $order): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <h3>Заказ #<?= $order['id'] ?></h3>
                            <span class="order-price"><?= number_format($order['price'], 2) ?> ₽</span>
                        </div>
                        
                        <div class="client-info">
                            <h4><i class="fas fa-user"></i> Информация о клиенте</h4>
                            <p><strong>Имя:</strong> <?= htmlspecialchars($order['client_first_name'] . ' ' . $order['client_last_name']) ?></p>
                            <p><strong>Телефон:</strong> <?= htmlspecialchars($order['client_phone']) ?></p>
                        </div>

                        <div class="route-info">
                            <h4><i class="fas fa-route"></i> Маршрут</h4>
                            <div class="route-point">
                                <i class="fas fa-map-marker-alt pickup-icon"></i>
                                <span><?= htmlspecialchars($order['pickup_address']) ?></span>
                            </div>
                            <div class="route-point">
                                <i class="fas fa-flag-checkered destination-icon"></i>
                                <span><?= htmlspecialchars($order['destination_address']) ?></span>
                            </div>
                        </div>

                        <div class="order-meta">
                            <p><i class="far fa-clock"></i> Создан: <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></p>
                            <p><i class="fas fa-hourglass-half"></i> Ожидает: <?= time_elapsed_string($order['created_at']) ?></p>
                        </div>

                        <form method="POST" class="accept-form">
                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                            <button type="submit" name="accept_order" class="accept-button" onclick="return confirm('Принять этот заказ?')">
                                <i class="fas fa-check"></i> Принять заказ
                            </button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="auto-refresh-notice">
                <i class="fas fa-info-circle"></i>
                <span>Список заказов обновляется автоматически. Новые заказы появляются в реальном времени.</span>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Простая версия функции
function time_elapsed_string($datetime) {
    $now = time();
    $ago = strtotime($datetime);
    $diff = $now - $ago;

    if ($diff < 60) {
        return 'только что';
    } elseif ($diff < 3600) {
        $min = floor($diff / 60);
        return $min . ' ' . get_plural($min, 'минута', 'минуты', 'минут') . ' назад';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' ' . get_plural($hours, 'час', 'часа', 'часов') . ' назад';
    } elseif ($diff < 2592000) {
        $days = floor($diff / 86400);
        return $days . ' ' . get_plural($days, 'день', 'дня', 'дней') . ' назад';
    } else {
        $months = floor($diff / 2592000);
        return $months . ' ' . get_plural($months, 'месяц', 'месяца', 'месяцев') . ' назад';
    }
}

function get_plural($number, $one, $two, $five) {
    $number = abs($number);
    $number %= 100;
    if ($number >= 5 && $number <= 20) {
        return $five;
    }
    $number %= 10;
    if ($number == 1) {
        return $one;
    }
    if ($number >= 2 && $number <= 4) {
        return $two;
    }
    return $five;
}
?>

<style>
.not-available-message,
.no-orders-message {
    text-align: center;
    padding: 40px;
    background: var(--input-bg);
    border-radius: 10px;
    margin: 30px 0;
}

.not-available-message i,
.no-orders-message i {
    font-size: 4em;
    margin-bottom: 20px;
    color: var(--text-color);
    opacity: 0.7;
}

.not-available-message h2,
.no-orders-message h2 {
    margin-bottom: 15px;
    color: var(--text-color);
}

.refresh-info {
    margin-top: 20px;
    padding: 10px;
    background: var(--main-bg-color);
    border-radius: 5px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.orders-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.order-card {
    background: var(--input-bg);
    padding: 25px;
    border-radius: 10px;
    border-left: 4px solid var(--color);
    transition: all 0.3s ease;
}

.order-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid var(--border-color);
}

.order-header h3 {
    margin: 0;
    color: var(--text-color);
}

.order-price {
    background: var(--color);
    color: white;
    padding: 8px 15px;
    border-radius: 20px;
    font-weight: bold;
    font-size: 1.1em;
}

.client-info,
.route-info,
.order-meta {
    margin-bottom: 20px;
}

.client-info h4,
.route-info h4 {
    margin-bottom: 10px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 8px;
}

.route-point {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 8px 0;
    padding: 8px;
    background: var(--main-bg-color);
    border-radius: 5px;
}

.pickup-icon {
    color: #e74c3c;
}

.destination-icon {
    color: #27ae60;
}

.order-meta p {
    margin: 5px 0;
    font-size: 0.9em;
    color: var(--text-color);
    opacity: 0.8;
    display: flex;
    align-items: center;
    gap: 8px;
}

.accept-form {
    margin-top: 20px;
}

.accept-button {
    width: 100%;
    background: var(--color);
    color: white;
    padding: 15px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.accept-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.auto-refresh-notice {
    background: var(--main-bg-color);
    padding: 15px;
    border-radius: 8px;
    text-align: center;
    margin-top: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.action-button {
    display: inline-block;
    padding: 12px 25px;
    background: var(--color);
    color: white;
    text-decoration: none;
    border-radius: 8px;
    margin-top: 15px;
    transition: all 0.3s ease;
}

.action-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
</style>
<script src="snow.js"></script>
<script>
// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }

    // Автообновление страницы каждые 30 секунд
    <?php if (!isset($not_available) && !empty($available_orders)): ?>
    setInterval(function() {
        window.location.reload();
    }, 30000);
    <?php endif; ?>
});
</script>

</body>
</html>