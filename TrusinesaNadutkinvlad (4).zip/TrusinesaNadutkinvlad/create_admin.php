<?php
// create_admin.php - Скрипт для создания администратора
require_once 'db_connect.php';

echo "<!DOCTYPE html>
<html lang='ru'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Создание администратора</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .form-container { background: #f5f5f5; padding: 30px; border-radius: 10px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type='text'], input[type='password'], input[type='email'] { 
            width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; 
        }
        button { 
            background: #3498db; color: white; padding: 12px 30px; 
            border: none; border-radius: 5px; cursor: pointer; font-size: 16px;
        }
        button:hover { background: #2980b9; }
        .success { background: #27ae60; color: white; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .error { background: #e74c3c; color: white; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .info { background: #3498db; color: white; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class='form-container'>
        <h1>Создание администратора</h1>";

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    $errors = [];
    
    if (empty($username) || empty($email) || empty($password)) {
        $errors[] = "Все поля обязательны для заполнения";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Пароли не совпадают";
    }
    
    if (strlen($password) < 6) {
        $errors[] = "Пароль должен содержать минимум 6 символов";
    }
    
    if (empty($errors)) {
        try {
            // Проверяем, нет ли уже пользователя с таким логином или email
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            
            if ($stmt->fetch()) {
                echo "<div class='error'>Пользователь с таким логином или email уже существует</div>";
            } else {
                // Создаем администратора
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'admin')");
                $stmt->execute([$username, $email, $password_hash]);
                
                echo "<div class='success'>
                    <h3>✅ Администратор успешно создан!</h3>
                    <p><strong>Логин:</strong> $username</p>
                    <p><strong>Email:</strong> $email</p>
                    <p><strong>Пароль:</strong> $password</p>
                    <p><strong>Роль:</strong> Администратор</p>
                    <br>
                    <a href='index.php' style='color: white; text-decoration: underline;'>Перейти к входу в систему</a>
                </div>";
            }
            
        } catch (PDOException $e) {
            echo "<div class='error'>Ошибка при создании администратора: " . $e->getMessage() . "</div>";
        }
    } else {
        echo "<div class='error'>" . implode('<br>', $errors) . "</div>";
    }
}

// Показываем форму
echo "
        <div class='info'>
            <strong>Внимание!</strong> Этот скрипт создает администратора в системе. 
            После создания удалите этот файл для безопасности.
        </div>

        <form method='POST'>
            <div class='form-group'>
                <label for='username'>Логин администратора:</label>
                <input type='text' id='username' name='username' value='admin' required>
            </div>
            
            <div class='form-group'>
                <label for='email'>Email администратора:</label>
                <input type='email' id='email' name='email' value='admin@taxi.ru' required>
            </div>
            
            <div class='form-group'>
                <label for='password'>Пароль:</label>
                <input type='password' id='password' name='password' placeholder='Минимум 6 символов' required>
            </div>
            
            <div class='form-group'>
                <label for='confirm_password'>Подтверждение пароля:</label>
                <input type='password' id='confirm_password' name='confirm_password' placeholder='Повторите пароль' required>
            </div>
            
            <button type='submit'>Создать администратора</button>
        </form>
        
        <div style='margin-top: 30px; padding: 15px; background: #f8f9fa; border-radius: 5px;'>
            <h3>Альтернативные способы:</h3>
            <p>1. Выполнить SQL запрос в базе данных:</p>
            <code style='background: #2c3e50; color: white; padding: 10px; display: block; border-radius: 3px;'>
                INSERT INTO users (username, email, password_hash, role) VALUES ('admin', 'admin@taxi.ru', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
            </code>
            <p style='margin-top: 10px;'><small>Пароль: password</small></p>
        </div>
    </div>
</body>
</html>";
?>