<?php
session_start();
require_once 'captcha.php';

$captcha = new PuzzleCaptcha();

// Подключение к базе данных
$host = '134.90.167.42:10306';
$user = 'Trushin';
$password = 'i_8VF1';
$dbname = 'project_Trushin';

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Генерация капчи при загрузке страницы
if (!isset($_SESSION['captcha_generated'])) {
    $captcha_images = $captcha->generate();
    $_SESSION['captcha_generated'] = true;
} else {
    $captcha_images = $_SESSION['captcha_shuffled'] ?? $captcha->generate();
}

// Обработка формы входа
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $captcha_order = [
        'top_left' => $_POST['top_left'] ?? '',
        'top_right' => $_POST['top_right'] ?? '',
        'bottom_left' => $_POST['bottom_left'] ?? '',
        'bottom_right' => $_POST['bottom_right'] ?? ''
    ];

    // Валидация капчи
    if (!$captcha->validate($captcha_order)) {
        $error = "Неверно собрана капча! Картинки должны быть расположены в правильном порядке.";
        // Перегенерируем капчу
        $captcha_images = $captcha->generate();
    } else {
        try {
            // Поиск пользователя в базе
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['logged_in'] = true;
                
                // Очищаем капчу после успешного входа
                $captcha->cleanup();
                unset($_SESSION['captcha_generated']);

                // Перенаправление в зависимости от роли
                switch ($user['role']) {
                    case 'admin':
                        header('Location: admin_dashboard.php');
                        break;
                    case 'driver':
                        header('Location: driver_dashboard.php');
                        break;
                    case 'client':
                        header('Location: client_dashboard.php');
                        break;
                    default:
                        header('Location: index.php');
                }
                exit;
            } else {
                $error = "Неверный логин или пароль!";
                // Перегенерируем капчу при ошибке
                $captcha_images = $captcha->generate();
            }
        } catch (PDOException $e) {
            $error = "Ошибка при авторизации: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Такси-Сервис ООО "Вектор"</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="modal.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="taxi.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="sql.css">
    <link rel="stylesheet" href="captcha.css">
    <?php include 'favicon.php'; ?>
    
    <style>
    
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .form-container input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        .form-container input:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.3);
        }
        
        .form-container button {
            width: 100%;
            padding: 15px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
            transition: background 0.3s ease;
        }
        
        .form-container button:hover {
            background: #2980b9;
        }
        
        .error {
            background: #ffeaa7;
            color: #d63031;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            border-left: 4px solid #d63031;
            text-align: center;
        }
        
        .user-panel {
            background: #3333;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .user-panel h2 {
            color: #ffffffff;
            margin-bottom: 10px;
        }
        
        .user-panel ul {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        
        .user-panel li {
            margin: 10px 0;
        }
        
        .user-panel a {
            display: block;
            padding: 12px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease;
        }
        
        .user-panel a:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }
        
        .info-box {
           
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 4px solid #3498db;
        }
        
        .sql-container {
            background: #34495e;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .sql-container textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #2c3e50;
            border-radius: 5px;
            background: #2c3e50;
            color: white;
            font-family: monospace;
            resize: vertical;
        }
        
        .sql-container button {
            background: #e74c3c;
            color: white;
            border: none;
            padding: 10px 2px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        
        .sql-container button:hover {
            background: #c0392b;
        }
        
        h1 {
            text-align: center;
            color: #ffffffff;
            margin-bottom: 30px;
            font-size: 2.5em;
        }
    </style>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>

<div id="container">
    <!-- Лампочка для переключения темы -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <defs>
            <clipPath id="clip0">
                <rect width="40" height="34" x="319" y="394" rx="4"/>
            </clipPath>
        </defs>
        <g class="bulb" onclick="toggleBulb(this)">
            <path class="bulb__chord" stroke="#C4C4C4" stroke-width="3" d="M339 411V11"/>
            <g class="bulb__bulb">
                <path stroke="none" stroke-width="3" d="M339 411V11"/>
                <circle class="bulb__glass" cx="339" cy="453" r="29" stroke="#000" stroke-width="2"/>
                <circle class="bulb__flash" cx="339" cy="453" r="30" fill="none"/>
                <path class="bulb__glare"
                      d="M363.977 456.827C364.667 452.176 364.106 447.425 362.352 443.062C360.599 438.699 357.716 434.881 354 432"
                      stroke="white" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                <path class="bulb__filament" stroke="#000" stroke-width="2" d="M339 437v13.5M343 437v13.5M347 420v24M335 437v13.5M331 420v24"/>
                <g clip-path="url(#clip0)">
                    <rect class="bulb__holder" width="40" height="34" x="319" y="394" fill="#C4C4C4" rx="4"/>
                    <rect class="bulb__holder-shine" width="20" height="34" x="346" y="394" fill="#F7F7F7"/>
                </g>
                <rect class="bulb__holder-outline" width="38" height="32" x="320" y="395" stroke="#000"
                      stroke-width="2" rx="3"/>
            </g>
        </g>
    </svg>

    <!-- Изображение разбитой лампочки -->
    <img id="brokenBulb" src="broken_bulb.jpg" alt="Разбитая лампочка" style="display: none; position: absolute; top: 0px; left: -3px; width: 123px; height: 200;">
    
    <!-- Свечение лампочки -->
    <div class="bulb-light"></div>

    <div class="container">
        <h1>Такси-Сервис ООО "Вектор"</h1>
        
        <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
            <!-- Форма входа -->
            <div class="form-container">
                <form method="POST" id="loginForm">
                    <input type="text" name="username" placeholder="Логин или Email" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                    <input type="password" name="password" placeholder="Пароль" required>
                    
                    <!-- Капча с сеткой 2x2 -->
                    <div class="captcha-container">
                        <h3>Соберите картинку в правильном порядке:</h3>
                        <p class="captcha-hint">Перетащите картинки на правильные позиции</p>
                        
                        <div class="captcha-grid">
                            <!-- Верхний ряд -->
                            <div class="grid-row">
                                <div class="grid-cell" data-position="top_left" id="cell_top_left">
                                    <?php if (isset($captcha_images['top_left'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['top_left'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['top_left'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="top_left" value="<?= $captcha_images['top_left'] ?? '' ?>">
                                </div>
                                <div class="grid-cell" data-position="top_right" id="cell_top_right">
                                    <?php if (isset($captcha_images['top_right'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['top_right'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['top_right'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="top_right" value="<?= $captcha_images['top_right'] ?? '' ?>">
                                </div>
                            </div>
                            
                            <!-- Нижний ряд -->
                            <div class="grid-row">
                                <div class="grid-cell" data-position="bottom_left" id="cell_bottom_left">
                                    <?php if (isset($captcha_images['bottom_left'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['bottom_left'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['bottom_left'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="bottom_left" value="<?= $captcha_images['bottom_left'] ?? '' ?>">
                                </div>
                                <div class="grid-cell" data-position="bottom_right" id="cell_bottom_right">
                                    <?php if (isset($captcha_images['bottom_right'])): ?>
                                        <div class="captcha-item" draggable="true" data-image="<?= $captcha_images['bottom_right'] ?>">
                                            <img src="captcha_images/<?= $captcha_images['bottom_right'] ?>" alt="Капча">
                                        </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="bottom_right" value="<?= $captcha_images['bottom_right'] ?? '' ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="captcha-controls">
                            <button type="button" id="resetCaptcha">Новая капча</button>
                        </div>
                    </div>

                    <button type="submit" name="submit">
                        <i class="fas fa-sign-in-alt"></i> Войти
                    </button>
                </form>
                
                <?php if (isset($error)): ?>
                    <div class="error"><?= $error ?></div>
                <?php endif; ?>
                
                <div style="margin-top: 20px; text-align: center;">
                    <p>Нет аккаунта? 
                        <a href="register.php" style="color: #3498db; text-decoration: none; font-weight: bold;">
                            <i class="fas fa-user-plus"></i> Зарегистрироваться
                        </a>
                    </p>
                </div>
            </div>
        <?php else: ?>
            <!-- Панель пользователя -->
            <div class="user-panel">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h2>Добро пожаловать, <?= htmlspecialchars($_SESSION['username']) ?>!</h2>
                    <p style="font-size: 1.2em; color: #7f8c8d;">Ваша роль: <strong style="color: #e74c3c;"><?= htmlspecialchars($_SESSION['role']) ?></strong></p>
                </div>

                <!-- Навигация в зависимости от роли -->
                <ul>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li><a href="admin_dashboard.php"><i class="fas fa-tachometer-alt"></i> Панель администратора</a></li>
                        <li><a href="user_management.php"><i class="fas fa-users"></i> Управление пользователями</a></li>
                        <li><a href="orders_management.php"><i class="fas fa-list"></i> Управление заказами</a></li>
                        <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Отчеты</a></li>
                    <?php elseif ($_SESSION['role'] === 'driver'): ?>
                        <li><a href="driver_dashboard.php"><i class="fas fa-tachometer-alt"></i> Панель водителя</a></li>
                        <li><a href="available_orders.php"><i class="fas fa-car"></i> Доступные заказы</a></li>
                        <li><a href="my_orders.php"><i class="fas fa-list"></i> Мои заказы</a></li>
                        <li><a href="driver_profile.php"><i class="fas fa-user"></i> Мой профиль</a></li>
                    <?php elseif ($_SESSION['role'] === 'client'): ?>
                        <li><a href="client_dashboard.php"><i class="fas fa-tachometer-alt"></i> Панель клиента</a></li>
                       
                        <li><a href="my_orders.php"><i class="fas fa-history"></i> Мои заказы</a></li>
                    <?php endif; ?>
                    
                    <li><a href="logout.php" style="background: #e74c3c;"><i class="fas fa-sign-out-alt"></i> Выход</a></li>
                </ul>
            </div>
            <?php if ($_SESSION['role'] !== 'admin'): ?>
            <!-- Информационный блок -->
            <div class="info-box">
                <h2><i class="fas fa-info-circle"></i> Добро пожаловать в Такси-Сервис!</h2>
                <p>Ваш надежный партнер в городских поездках.</p>
                <p><strong>Быстро, безопасно, комфортно.</strong></p>
                <p style="margin-top: 15px; font-style: italic;">© 2025 Такси-Сервис ООО "Вектор". Все права защищены.</p>
            </div>
                <?php endif; ?>
            <!-- SQL-запросы (только для админа) -->
            <?php if ($_SESSION['role'] === 'admin'): ?>
            <div class="sql-container">
                <h3 style="color: white; margin-top: 0;"><i class="fas fa-database"></i> SQL Запросы</h3>
                <form id="sqlForm">
                    <textarea name="sql_query" id="sql_query" placeholder="Введите SQL-запрос (только SELECT)" rows="5" required></textarea>
                    <button type="submit" name="execute_sql"><i class="fas fa-play"></i> Выполнить</button>
                </form>
                <div id="sqlError" class="error" style="display: none;"></div>
            </div>

            <!-- Модальное окно для результатов SQL -->
            <div id="sqlModal" class="modal1">
                <div class="modal-content1">
                    <span class="close" onclick="closeModal()">&times;</span>
                    <h2><i class="fas fa-table"></i> Результаты SQL-запроса</h2>
                    <div id="modalResults"></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Анимированные такси -->
            <div class="road">
                <div class="taxi">
                    <div class="light_beam"></div>
                    <span>
                        <strong></strong>
                        <em></em>
                    </span>
                </div>
                <div class="taxi">
                    <div class="light_beam"></div>
                    <span>
                        <strong></strong>
                        <em></em>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="captcha.js"></script>
<script src="snow.js"></script>
<script>

    // Скрипт лампочки
    let clickCount = 0;
    const maxClicks = 10;

    function toggleBulb(bulb) {
        clickCount++;
        if (clickCount >= maxClicks) {
            const svgBulb = document.querySelector('.bulbs');
            svgBulb.style.display = 'none';
            const brokenBulb = document.getElementById('brokenBulb');
            brokenBulb.style.display = 'block';
            document.body.classList.remove('light-theme');
            bulb.classList.remove('on');
            localStorage.setItem('theme', 'dark');
            bulb.style.pointerEvents = 'none';
            return;
        }

        bulb.classList.toggle('on');
        document.body.classList.toggle('light-theme');
        const isLight = document.body.classList.contains('light-theme');
        localStorage.setItem('theme', isLight ? 'light' : 'dark');
    }

    // Восстановление темы
    document.addEventListener('DOMContentLoaded', () => {
        const savedTheme = localStorage.getItem('theme');
        const bulbElement = document.querySelector('.bulb');
        if (savedTheme === 'light') {
            document.body.classList.add('light-theme');
            if(bulbElement) bulbElement.classList.add('on');
        } else {
            document.body.classList.remove('light-theme');
            if(bulbElement) bulbElement.classList.remove('on');
        }
    });

    // SQL-запросы (только для админа)
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
    document.getElementById('sqlForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const sqlQuery = document.getElementById('sql_query').value;
        const sqlError = document.getElementById('sqlError');
        const modalResults = document.getElementById('modalResults');

        modalResults.innerHTML = '';
        sqlError.style.display = 'none';

        // Проверка на опасные операции
        const dangerousKeywords = ['DROP', 'DELETE', 'TRUNCATE', 'ALTER', 'CREATE', 'INSERT', 'UPDATE', 'GRANT', 'REVOKE'];
        const upperQuery = sqlQuery.toUpperCase();
        
        for (let keyword of dangerousKeywords) {
            if (upperQuery.includes(keyword)) {
                sqlError.textContent = 'Опасные операции запрещены. Разрешены только SELECT запросы.';
                sqlError.style.display = 'block';
                return;
            }
        }

        fetch('execute_sql.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `sql_query=${encodeURIComponent(sqlQuery)}`,
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                sqlError.textContent = data.error;
                sqlError.style.display = 'block';
            } else {
                const table = document.createElement('table');
                table.style.width = '100%';
                table.style.borderCollapse = 'collapse';
                table.style.marginTop = '10px';
                
                const thead = document.createElement('thead');
                const tbody = document.createElement('tbody');

                if (data.length > 0) {
                    const headerRow = document.createElement('tr');
                    Object.keys(data[0]).forEach(column => {
                        const th = document.createElement('th');
                        th.textContent = column;
                        th.style.border = '1px solid #ddd';
                        th.style.padding = '8px';
                        th.style.backgroundColor = '#f2f2f2';
                        headerRow.appendChild(th);
                    });
                    thead.appendChild(headerRow);
                    table.appendChild(thead);

                    data.forEach(row => {
                        const tr = document.createElement('tr');
                        Object.values(row).forEach(value => {
                            const td = document.createElement('td');
                            td.textContent = value;
                            td.style.border = '1px solid #ddd';
                            td.style.padding = '8px';
                            tr.appendChild(td);
                        });
                        tbody.appendChild(tr);
                    });
                } else {
                    const tr = document.createElement('tr');
                    const td = document.createElement('td');
                    td.textContent = 'Нет данных';
                    td.style.padding = '10px';
                    td.style.textAlign = 'center';
                    td.colSpan = 1;
                    tr.appendChild(td);
                    tbody.appendChild(tr);
                }
                
                table.appendChild(tbody);
                modalResults.appendChild(table);
                openModal();
            }
        })
        .catch(error => {
            console.error('Ошибка:', error);
            sqlError.textContent = 'Произошла ошибка при выполнении запроса.';
            sqlError.style.display = 'block';
        });
    });

    function openModal() {
        document.getElementById('sqlModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('sqlModal').style.display = 'none';
    }

    window.onclick = function (event) {
        const modal = document.getElementById('sqlModal');
        if (event.target === modal) {
            closeModal();
        }
    };
    <?php endif; ?>

    // Валидация формы входа
    document.getElementById('loginForm')?.addEventListener('submit', function(e) {
        const captchaInputs = document.querySelectorAll('.captcha-grid input[type="hidden"]');
        let captchaFilled = true;
        
        captchaInputs.forEach(input => {
            if (!input.value) {
                captchaFilled = false;
            }
        });
        
        if (!captchaFilled) {
            e.preventDefault();
            alert('Пожалуйста, соберите капчу полностью!');
            return false;
        }
    });
</script>

</body>
</html>