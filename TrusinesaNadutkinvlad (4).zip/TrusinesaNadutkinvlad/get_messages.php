<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = $_GET['order_id'] ?? null;

if (!$order_id) {
    exit;
}

// Получение сообщений
try {
    $stmt = $pdo->prepare("
        SELECT m.*, u.username, u.role
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.order_id = ?
        ORDER BY m.sent_at ASC
    ");
    $stmt->execute([$order_id]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $messages = [];
}

if (empty($messages)): ?>
    <div class="no-messages">
        <i class="fas fa-comments"></i>
        <p>Нет сообщений</p>
        <small>Начните общение первым</small>
    </div>
<?php else: ?>
    <?php foreach ($messages as $message): ?>
        <div class="message <?= $message['sender_id'] == $user_id ? 'own-message' : 'other-message' ?>">
            <div class="message-header">
                <span class="sender-name">
                    <?= $message['sender_id'] == $user_id ? 'Вы' : htmlspecialchars($message['username']) ?>
                </span>
                <span class="message-time">
                    <?= date('H:i', strtotime($message['sent_at'])) ?>
                </span>
            </div>
            <div class="message-text">
                <?= nl2br(htmlspecialchars($message['message_text'])) ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>