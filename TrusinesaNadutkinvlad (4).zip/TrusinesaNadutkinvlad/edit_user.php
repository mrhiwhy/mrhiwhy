<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$user_id = $_GET['id'] ?? null;

if (!$user_id) {
    header('Location: user_management.php');
    exit;
}

// Получение данных пользователя
try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               cp.first_name, cp.last_name, cp.phone_number,
               dp.license_number, dp.car_model, dp.car_color, dp.license_plate, dp.is_available
        FROM users u
        LEFT JOIN client_profiles cp ON u.id = cp.user_id
        LEFT JOIN driver_profiles dp ON u.id = dp.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        header('Location: user_management.php');
        exit;
    }
} catch (PDOException $e) {
    die("Ошибка при получении данных пользователя: " . $e->getMessage());
}

$error = '';
$success = '';

// Обработка формы редактирования
if (isset($_POST['update_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone_number = trim($_POST['phone_number']);

    // Смена пароля (опционально)
    $change_password = !empty($_POST['new_password']);
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Валидация
    $errors = [];

    if (empty($username) || empty($email)) {
        $errors[] = "Все обязательные поля должны быть заполнены";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Некорректный формат email";
    }

    if ($change_password) {
        if ($new_password !== $confirm_password) {
            $errors[] = "Пароли не совпадают";
        }
        if (strlen($new_password) < 6) {
            $errors[] = "Пароль должен содержать минимум 6 символов";
        }
    }

    // Проверка уникальности username и email (исключая текущего пользователя)
    $stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
    $stmt->execute([$username, $email, $user_id]);
    if ($stmt->fetch()) {
        $errors[] = "Пользователь с таким логином или email уже существует";
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Обновление основной информации пользователя
            if ($change_password) {
                $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ?, password_hash = ? WHERE id = ?");
                $stmt->execute([$username, $email, $role, $password_hash, $user_id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
                $stmt->execute([$username, $email, $role, $user_id]);
            }

            // Обновление профиля в зависимости от роли
            if ($role === 'client') {
                // Удаляем профиль водителя если был
                $stmt = $pdo->prepare("DELETE FROM driver_profiles WHERE user_id = ?");
                $stmt->execute([$user_id]);
                
                // Обновляем или создаем профиль клиента
                $stmt = $pdo->prepare("
                    INSERT INTO client_profiles (user_id, first_name, last_name, phone_number) 
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE first_name = ?, last_name = ?, phone_number = ?
                ");
                $stmt->execute([$user_id, $first_name, $last_name, $phone_number, $first_name, $last_name, $phone_number]);
                
            } elseif ($role === 'driver') {
                // Удаляем профиль клиента если был
                $stmt = $pdo->prepare("DELETE FROM client_profiles WHERE user_id = ?");
                $stmt->execute([$user_id]);
                
                $license_number = $_POST['license_number'] ?? '';
                $car_model = $_POST['car_model'] ?? '';
                $car_color = $_POST['car_color'] ?? '';
                $license_plate = $_POST['license_plate'] ?? '';
                $is_available = isset($_POST['is_available']) ? 1 : 0;
                
                // Обновляем или создаем профиль водителя
                $stmt = $pdo->prepare("
                    INSERT INTO driver_profiles (user_id, first_name, last_name, phone_number, license_number, car_model, car_color, license_plate, is_available) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE first_name = ?, last_name = ?, phone_number = ?, license_number = ?, car_model = ?, car_color = ?, license_plate = ?, is_available = ?
                ");
                $stmt->execute([
                    $user_id, $first_name, $last_name, $phone_number, $license_number, $car_model, $car_color, $license_plate, $is_available,
                    $first_name, $last_name, $phone_number, $license_number, $car_model, $car_color, $license_plate, $is_available
                ]);
            } else {
                // Администратор - удаляем оба профиля
                $stmt = $pdo->prepare("DELETE FROM client_profiles WHERE user_id = ?");
                $stmt->execute([$user_id]);
                $stmt = $pdo->prepare("DELETE FROM driver_profiles WHERE user_id = ?");
                $stmt->execute([$user_id]);
            }

            $pdo->commit();
            $success = "Данные пользователя успешно обновлены!";
            
            // Обновляем данные пользователя для отображения
            $stmt = $pdo->prepare("
                SELECT u.*, 
                       cp.first_name, cp.last_name, cp.phone_number,
                       dp.license_number, dp.car_model, dp.car_color, dp.license_plate, dp.is_available
                FROM users u
                LEFT JOIN client_profiles cp ON u.id = cp.user_id
                LEFT JOIN driver_profiles dp ON u.id = dp.user_id
                WHERE u.id = ?
            ");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Ошибка при обновлении пользователя: " . $e->getMessage();
        }
    }

    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать пользователя - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <?php include 'favicon.php'; ?>
</head>
<body>
<!-- Контейнер для снега -->
<div class="snow-container" id="snowContainer"></div>
<!-- Кнопка "Назад" -->
<a href="user_management.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <h1>Редактировать пользователя</h1>
        <div class="user-header">
            <h2><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h2>
            <span class="user-id">ID: <?= $user['id'] ?></span>
        </div>

        <?php if ($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" class="user-form">
                <div class="form-section">
                    <h3><i class="fas fa-user-circle"></i> Основная информация</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username">Логин *</label>
                            <input type="text" id="username" name="username" 
                                   value="<?= htmlspecialchars($user['username']) ?>" 
                                   required placeholder="Введите логин">
                        </div>

                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" 
                                   value="<?= htmlspecialchars($user['email']) ?>" 
                                   required placeholder="email@example.com">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="role">Роль пользователя *</label>
                        <select id="role" name="role" required onchange="toggleDriverFields()">
                            <option value="client" <?= $user['role'] === 'client' ? 'selected' : '' ?>>Клиент</option>
                            <option value="driver" <?= $user['role'] === 'driver' ? 'selected' : '' ?>>Водитель</option>
                            <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Администратор</option>
                        </select>
                    </div>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-id-card"></i> Личная информация</h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">Имя *</label>
                            <input type="text" id="first_name" name="first_name" 
                                   value="<?= htmlspecialchars($user['first_name'] ?? '') ?>" 
                                   required placeholder="Введите имя">
                        </div>

                        <div class="form-group">
                            <label for="last_name">Фамилия *</label>
                            <input type="text" id="last_name" name="last_name" 
                                   value="<?= htmlspecialchars($user['last_name'] ?? '') ?>" 
                                   required placeholder="Введите фамилию">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="phone_number">Телефон *</label>
                        <input type="text" id="phone_number" name="phone_number" 
                               value="<?= htmlspecialchars($user['phone_number'] ?? '') ?>" 
                               required placeholder="+7 (XXX) XXX-XX-XX">
                    </div>
                </div>

                <!-- Поля для водителя -->
                <div id="driver_fields" class="form-section" style="<?= $user['role'] === 'driver' ? '' : 'display: none;' ?>">
                    <h3><i class="fas fa-car"></i> Информация для водителя</h3>
                    
                    <div class="form-group">
                        <label for="license_number">Номер водительского удостоверения *</label>
                        <input type="text" id="license_number" name="license_number" 
                               value="<?= htmlspecialchars($user['license_number'] ?? '') ?>" 
                               placeholder="Серия и номер" <?= $user['role'] === 'driver' ? 'required' : '' ?>>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="car_model">Модель автомобиля *</label>
                            <input type="text" id="car_model" name="car_model" 
                                   value="<?= htmlspecialchars($user['car_model'] ?? '') ?>" 
                                   placeholder="Например: Toyota Camry" <?= $user['role'] === 'driver' ? 'required' : '' ?>>
                        </div>

                        <div class="form-group">
                            <label for="car_color">Цвет автомобиля *</label>
                            <input type="text" id="car_color" name="car_color" 
                                   value="<?= htmlspecialchars($user['car_color'] ?? '') ?>" 
                                   placeholder="Например: Белый" <?= $user['role'] === 'driver' ? 'required' : '' ?>>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="license_plate">Государственный номер *</label>
                            <input type="text" id="license_plate" name="license_plate" 
                                   value="<?= htmlspecialchars($user['license_plate'] ?? '') ?>" 
                                   placeholder="Например: А123БВ77" <?= $user['role'] === 'driver' ? 'required' : '' ?>>
                        </div>

                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="is_available" value="1" 
                                       <?= $user['is_available'] ? 'checked' : '' ?>>
                                <span class="checkmark"></span>
                                Доступен для заказов
                            </label>
                            <small>Определяет, может ли водитель принимать новые заказы</small>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h3><i class="fas fa-lock"></i> Смена пароля</h3>
                    <div class="password-note">
                        <i class="fas fa-info-circle"></i>
                        <span>Оставьте поля пустыми, если не хотите менять пароль</span>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="new_password">Новый пароль</label>
                            <input type="password" id="new_password" name="new_password" 
                                   placeholder="Минимум 6 символов">
                        </div>

                        <div class="form-group">
                            <label for="confirm_password">Подтверждение пароля</label>
                            <input type="password" id="confirm_password" name="confirm_password" 
                                   placeholder="Повторите новый пароль">
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" name="update_user" class="submit-button">
                        <i class="fas fa-save"></i> Сохранить изменения
                    </button>
                    <a href="user_management.php" class="cancel-button">Отмена</a>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.user-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);
}

.user-header h2 {
    margin: 0;
    color: var(--text-color);
}

.user-id {
    background: var(--color);
    color: white;
    padding: 5px 10px;
    border-radius: 15px;
    font-size: 0.9em;
    font-weight: bold;
}

.form-container {
    max-width: 800px;
    margin: 0 auto;
}

.user-form {
    background: var(--input-bg);
    padding: 30px;
    border-radius: 10px;
}

.form-section {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);
}

.form-section:last-of-type {
    border-bottom: none;
}

.form-section h3 {
    margin-bottom: 20px;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.password-note {
    background: var(--main-bg-color);
    padding: 10px 15px;
    border-radius: 5px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.9em;
}

.password-note i {
    color: var(--color);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: var(--text-color);
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background: var(--main-bg-color);
    color: var(--text-color);
    font-size: 14px;
    transition: border-color 0.3s ease;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--color);
}

.form-group small {
    display: block;
    margin-top: 5px;
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.8em;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    font-weight: normal;
}

.checkbox-label input[type="checkbox"] {
    width: auto;
    margin: 0;
}

.form-actions {
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid var(--border-color);
}

.submit-button {
    background: var(--color);
    color: white;
    padding: 15px 30px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.submit-button:hover {
    background: var(--color);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.cancel-button {
    display: inline-block;
    padding: 15px 30px;
    margin-left: 15px;
    background: var(--main-bg-color);
    color: var(--text-color);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.cancel-button:hover {
    background: var(--border-color);
    transform: translateY(-2px);
}

.error-message {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.success-message {
    background: #27ae60;
    color: white;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }
    
    .user-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    
    .form-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    
    .cancel-button {
        margin-left: 0;
    }
}
</style>
<script src="snow.js"></script>
<script>
function toggleDriverFields() {
    const role = document.getElementById('role').value;
    const driverFields = document.getElementById('driver_fields');
    const driverInputs = driverFields.querySelectorAll('input[type="text"]');
    
    if (role === 'driver') {
        driverFields.style.display = 'block';
        // Делаем поля обязательными для водителя
        driverInputs.forEach(input => input.required = true);
    } else {
        driverFields.style.display = 'none';
        // Убираем обязательность полей
        driverInputs.forEach(input => input.required = false);
    }
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    // Маска для телефона
    const phoneInput = document.getElementById('phone_number');
    phoneInput.addEventListener('input', function(e) {
        let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
        e.target.value = '+7' + (x[2] ? ' (' + x[2] : '') + (x[3] ? ') ' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
    });

    // Валидация паролей
    const password = document.getElementById('new_password');
    const confirmPassword = document.getElementById('confirm_password');
    
    function validatePassword() {
        if (password.value !== confirmPassword.value) {
            confirmPassword.setCustomValidity("Пароли не совпадают");
        } else {
            confirmPassword.setCustomValidity('');
        }
    }
    
    password.addEventListener('change', validatePassword);
    confirmPassword.addEventListener('keyup', validatePassword);
});

// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});
</script>

</body>
</html>