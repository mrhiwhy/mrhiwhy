<?php
session_start();
require_once 'db_connect.php';

// Проверка авторизации и роли администратора
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Симулятор перевозок - Такси-Сервис</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" crossorigin="anonymous"/>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="лампа.css">
    <link rel="stylesheet" href="back.css">
    <style>
        .simulator-container {
            background: var(--input-bg);
            border-radius: 10px;
            padding: 0;
            margin: 20px 0;
            overflow: hidden;
        }
        
        .simulator-header {
            background: var(--color);
            color: white;
            padding: 25px;
            text-align: center;
        }
        
        .validation-panel {
            background: var(--main-bg-color);
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .validation-form {
            display: flex;
            gap: 15px;
            align-items: start;
            flex-wrap: wrap;
        }
        
        .input-group {
            flex: 1;
            min-width: 300px;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: var(--text-color);
        }
        
        .input-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--border-color);
            border-radius: 5px;
            background: var(--input-bg);
            color: var(--text-color);
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: var(--color);
        }
        
        .validate-btn {
            background: var(--color);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 25px;
        }
        
        .validate-btn:hover {
            background: var(--color);
            transform: translateY(-2px);
        }
        
        .validate-btn:disabled {
            background: var(--border-color);
            cursor: not-allowed;
            transform: none;
        }
        
        .validation-result {
            margin-top: 15px;
            padding: 15px;
            border-radius: 5px;
            display: none;
        }
        
        .validation-result.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            display: block;
        }
        
        .validation-result.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            display: block;
        }
        
        .validation-result.warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
            display: block;
        }
        
        .simulator-frame {
            width: 100%;
            height: 70vh;
            border: none;
            background: white;
        }
        
        .simulator-info {
            padding: 25px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .info-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .info-card {
            background: var(--main-bg-color);
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--color);
        }
        
        .controls {
            padding: 20px;
            background: var(--main-bg-color);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .control-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: var(--color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .control-button:hover {
            background: var(--color);
            transform: translateY(-2px);
        }
        
        .stats-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .stat-item {
            background: var(--main-bg-color);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5em;
            font-weight: bold;
            color: var(--color);
        }
        
        .recent-validations {
            background: var(--input-bg);
            padding: 25px;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .validation-history {
            margin-top: 15px;
        }
        
        .validation-item {
            padding: 10px 15px;
            margin: 5px 0;
            border-radius: 5px;
            border-left: 4px solid;
        }
        
        .validation-item.success {
            background: #d4edda;
            border-left-color: #28a745;
        }
        
        .validation-item.error {
            background: #f8d7da;
            border-left-color: #dc3545;
        }
        
        .validation-item.warning {
            background: #fff3cd;
            border-left-color: #ffc107;
        }
    </style>
    <?php include 'favicon.php'; ?>
</head>
<body>

<!-- Кнопка "Назад" -->
<a href="admin_dashboard.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Назад
</a>

<div id="container">
    <!-- Лампочка -->
    <svg class="bulbs" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="300 0 79 483">
        <!-- SVG код лампочки -->
    </svg>

    <div class="container">
        <div class="simulator-container">
            <div class="simulator-header">
                <h1><i class="fas fa-truck-loading"></i> Симулятор перевозок</h1>
                <p>Моделирование логистических процессов и оптимизация маршрутов</p>
            </div>
            
            <!-- Панель валидации ФИО -->
            <div class="validation-panel">
                <h3><i class="fas fa-user-check"></i> Валидация данных из симулятора</h3>
                <p>Введите ФИО для проверки перед внесением в систему</p>
                
                <div class="validation-form">
                    <div class="input-group">
                        <label for="fullnameInput">ФИО из симулятора:</label>
                        <input 
                            type="text" 
                            id="fullnameInput" 
                            placeholder="Например: Иванов Иван Иванович"
                            oninput="validateOnType()"
                        >
                        <small style="color: var(--text-color); opacity: 0.7; display: block; margin-top: 5px;">
                            Разрешены: русские/английские буквы, пробелы, дефисы, точки
                        </small>
                    </div>
                    
                    <button class="validate-btn" onclick="validateFullName()" id="validateBtn">
                        <i class="fas fa-check-circle"></i> Проверить ФИО
                    </button>
                </div>
                
                <div id="validationResult" class="validation-result"></div>
            </div>
            
            <div class="simulator-info">
                <h2><i class="fas fa-info-circle"></i> Правила валидации ФИО</h2>
                <div class="info-cards">
                    <div class="info-card">
                        <h3><i class="fas fa-check"></i> Разрешенные символы</h3>
                        <p>Русские и английские буквы, пробелы, дефисы (-), точки (.), апострофы (')</p>
                    </div>
                    <div class="info-card">
                        <h3><i class="fas fa-ban"></i> Запрещенные символы</h3>
                        <p>Цифры, специальные символы (@, #, $, %, &, *, и т.д.), эмодзи</p>
                    </div>
                    <div class="info-card">
                        <h3><i class="fas fa-ruler"></i> Требования к формату</h3>
                        <p>Минимум 2 слова, каждое слово от 2 символов, максимальная длина 100 символов</p>
                    </div>
                </div>
            </div>
            
            <div class="controls">
                <a href="http://prb.sylas.ru/TransferSimulator/fullName" target="_blank" class="control-button">
                    <i class="fas fa-external-link-alt"></i> Открыть в новом окне
                </a>
                <button onclick="refreshSimulator()" class="control-button" style="background: #3498db;">
                    <i class="fas fa-sync-alt"></i> Обновить симулятор
                </button>
                <button onclick="clearValidation()" class="control-button" style="background: #6c757d;">
                    <i class="fas fa-broom"></i> Очистить форму
                </button>
            </div>
            
            <!-- Основной фрейм с симулятором -->
            <iframe 
                src="http://prb.sylas.ru/TransferSimulator/fullName" 
                class="simulator-frame"
                id="simulatorFrame"
                title="Симулятор перевозок"
                allowfullscreen>
            </iframe>
        </div>
        
        <!-- История валидаций -->
        <div class="recent-validations">
            <h2><i class="fas fa-history"></i> История проверок</h2>
            <div id="validationHistory" class="validation-history">
                <p style="text-align: center; color: var(--text-color); opacity: 0.7;">
                    Здесь будет отображаться история проверенных ФИО
                </p>
            </div>
        </div>
    </div>
</div>

<script>
// Массив для хранения истории валидаций
let validationHistory = [];

// Функция валидации ФИО
async function validateFullName() {
    const fullnameInput = document.getElementById('fullnameInput');
    const validationResult = document.getElementById('validationResult');
    const validateBtn = document.getElementById('validateBtn');
    
    const fullname = fullnameInput.value.trim();
    
    if (!fullname) {
        showValidationResult('error', 'Введите ФИО для проверки');
        return;
    }
    
    // Блокируем кнопку на время запроса
    validateBtn.disabled = true;
    validateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Проверка...';
    
    try {
        const response = await fetch('validate_fullname.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ fullname: fullname })
        });
        
        const result = await response.json();
        
        // Показываем результат
        showValidationResult(result.type, result.message);
        
        // Добавляем в историю
        if (result.valid) {
            addToValidationHistory(fullname, result.type, result.message, result.cleaned_name);
        } else {
            addToValidationHistory(fullname, result.type, result.message);
        }
        
    } catch (error) {
        showValidationResult('error', 'Ошибка при проверке ФИО: ' + error.message);
    } finally {
        // Разблокируем кнопку
        validateBtn.disabled = false;
        validateBtn.innerHTML = '<i class="fas fa-check-circle"></i> Проверить ФИО';
    }
}

// Функция для отображения результата валидации
function showValidationResult(type, message) {
    const validationResult = document.getElementById('validationResult');
    
    validationResult.className = 'validation-result ' + type;
    validationResult.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${getIconByType(type)}"></i>
            <div>
                <strong>${getTitleByType(type)}</strong>
                <div>${message}</div>
            </div>
        </div>
    `;
    
    validationResult.style.display = 'block';
    
    // Автоскрытие успешных сообщений через 5 секунд
    if (type === 'success') {
        setTimeout(() => {
            validationResult.style.display = 'none';
        }, 5000);
    }
}

// Функция для добавления в историю
function addToValidationHistory(fullname, type, message, cleanedName = null) {
    const historyItem = {
        id: Date.now(),
        original: fullname,
        cleaned: cleanedName || fullname,
        type: type,
        message: message,
        timestamp: new Date().toLocaleTimeString()
    };
    
    validationHistory.unshift(historyItem); // Добавляем в начало
    
    // Ограничиваем историю 10 последними записями
    if (validationHistory.length > 10) {
        validationHistory = validationHistory.slice(0, 10);
    }
    
    updateValidationHistoryDisplay();
}

// Функция для обновления отображения истории
function updateValidationHistoryDisplay() {
    const historyContainer = document.getElementById('validationHistory');
    
    if (validationHistory.length === 0) {
        historyContainer.innerHTML = `
            <p style="text-align: center; color: var(--text-color); opacity: 0.7;">
                Здесь будет отображаться история проверенных ФИО
            </p>
        `;
        return;
    }
    
    historyContainer.innerHTML = validationHistory.map(item => `
        <div class="validation-item ${item.type}">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                    <strong>${item.cleaned}</strong>
                    ${item.original !== item.cleaned ? 
                        `<br><small>Исходно: ${item.original}</small>` : ''
                    }
                    <div style="margin-top: 5px; font-size: 0.9em;">${item.message}</div>
                </div>
                <div style="text-align: right; font-size: 0.8em; opacity: 0.7;">
                    ${item.timestamp}
                </div>
            </div>
        </div>
    `).join('');
}

// Вспомогательные функции
function getIconByType(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'warning': 'exclamation-triangle'
    };
    return icons[type] || 'info-circle';
}

function getTitleByType(type) {
    const titles = {
        'success': 'Успешно',
        'error': 'Ошибка',
        'warning': 'Предупреждение'
    };
    return titles[type] || 'Информация';
}

// Функция валидации при вводе (с задержкой)
let typingTimer;
function validateOnType() {
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
        const fullname = document.getElementById('fullnameInput').value.trim();
        if (fullname.length > 1) {
            validateFullName();
        }
    }, 1000);
}

// Функция очистки формы
function clearValidation() {
    document.getElementById('fullnameInput').value = '';
    document.getElementById('validationResult').style.display = 'none';
    document.getElementById('validationResult').className = 'validation-result';
}

// Остальные функции управления
function refreshSimulator() {
    const frame = document.getElementById('simulatorFrame');
    frame.src = frame.src;
    showNotification('Симулятор обновлен', 'success');
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#27ae60' : '#3498db'};
        color: white;
        border-radius: 5px;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
    `;
    
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check' : 'info'}-circle"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Скрипт лампочки
let clickCount = 0;
const maxClicks = 10;

function toggleBulb(bulb) {
    clickCount++;
    if (clickCount >= maxClicks) {
        const svgBulb = document.querySelector('.bulbs');
        svgBulb.style.display = 'none';
        document.body.classList.remove('light-theme');
        bulb.classList.remove('on');
        localStorage.setItem('theme', 'dark');
        bulb.style.pointerEvents = 'none';
        return;
    }

    bulb.classList.toggle('on');
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
}

// Восстановление темы
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    const bulbElement = document.querySelector('.bulb');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if(bulbElement) bulbElement.classList.add('on');
    } else {
        document.body.classList.remove('light-theme');
        if(bulbElement) bulbElement.classList.remove('on');
    }
});

// Добавляем стили для анимаций
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);
</script>

</body>
</html>