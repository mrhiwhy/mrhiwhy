<?php
// favicon.php
echo '<link rel="icon" type="image/x-icon" href="ico.jpg">';
?>